

// 获取 ID 列表
// var info = com.tencent.assistant.ScriptRunner.getTaskInfo();
// console.log("获取到 ID info: " + info);
// map.forEach(function(key, value) {
//     console.log("Key: " + key + ", Value: " + value);
// });
// var ids = map.get("task_id");
// // 遍历处理
// ids.forEach(function(id) {
//     console.log("处理 ID: " + id);
//     // 在这里编写具体操作，比如根据 ID 执行任务
// });

// 获取任务信息
// var taskInfo = com.tencent.assistant.ScriptRunner.getTaskInfo();
// console.log("获取到任务信息: " + taskInfo);

// console.log("获取到任务 ID: " + taskInfo.ids);
// console.log("获取到任务名称: " + taskInfo.task_name);

// console.log("获取到任务参数: " +  taskInfo.task_desc);


// var manager = com.tencent.assistant.TaskExecutorManager.getInstance();
// var userIds = manager.getTargetUserIds();
// console.log("获取到用户 ID: " + userIds);
// var checkCount =0;
// while (checkCount++ < 10) {
//     let current = currentActivity();
//     console.log("当前页面: " + current);
//     sleep(1000);
// }

// app.startActivity({
//     packageName: "com.tencent.mm",
//     className: "com.tencent.mm.plugin.webview.ui.tools.fts.MMFTSSOSHomeWebViewUI",
// });

//保存图片到指定目录，方便调试调试(先保存整个项目到客户端，然后在客户端执行)
// let imgPrivateChat = images.read('./img/search.jpg');
// console.log("目标图标",imgPrivateChat)
// let canvasPrivate = new Canvas(imgPrivateChat);
// let imagePrivate = canvasPrivate.toImage();
// images.save(imagePrivate, '/sdcard/search.jpg');








