// 获取 ID 列表
// var info = com.tencent.assistant.ScriptRunner.getTaskInfo();
// console.log("获取到 ID info: " + info);
// map.forEach(function(key, value) {
//     console.log("Key: " + key + ", Value: " + value);
// });
// var ids = map.get("task_id");
// // 遍历处理
// ids.forEach(function(id) {
//     console.log("处理 ID: " + id);
//     // 在这里编写具体操作，比如根据 ID 执行任务
// });


// 获取任务信息
// var taskInfo = com.tencent.assistant.ScriptRunner.getTaskInfo();
// console.log("获取到任务信息: " + taskInfo);

// console.log("获取到任务 ID: " + taskInfo.ids);
// console.log("获取到任务名称: " + taskInfo.task_name);

// console.log("获取到任务参数: " +  taskInfo.task_desc);


// var manager = com.tencent.assistant.TaskExecutorManager.getInstance();
// var userIds = manager.getTargetUserIds();
// console.log("获取到用户 ID: " + userIds);
// var checkCount =0;
// while (checkCount++ < 10) {
//     let current = currentActivity();
//     console.log("当前页面: " + current);
//     sleep(1000);
// }

// app.startActivity({
//     packageName: "com.tencent.mm",
//     className: "com.tencent.mm.plugin.webview.ui.tools.fts.MMFTSSOSHomeWebViewUI",
// });

//保存图片到指定目录，方便调试调试(先保存整个项目到客户端，然后在客户端执行)
// let imgPrivateChat = images.read('./img/search.jpg');
// console.log("目标图标",imgPrivateChat)
// let canvasPrivate = new Canvas(imgPrivateChat);
// let imagePrivate = canvasPrivate.toImage();
// images.save(imagePrivate, '/sdcard/search.jpg');

// 单位转换工具
// const UnitConverter = {
//     dpToPx: function(dp) {
//         let metrics = context.getResources().getDisplayMetrics();
//         return Math.round(dp * metrics.density);
//     },
//     spToPx: function(sp) {
//         let metrics = context.getResources().getDisplayMetrics();
//         return Math.round(sp * metrics.scaledDensity);
//     }
// };

// // 使用示例
// console.log("3dp →", UnitConverter.dpToPx(3), "px");
// console.log("3sp →", UnitConverter.spToPx(3), "px");


// function getAllChildren(node) {
//     let children = new java.util.ArrayList();
//     if (node == null) return children;
//     for (let i = 0; i < node.childCount(); i++) {
//         let child = node.child(i);
//         children.add(child); // 添加直接子节点
//         children.addAll(getAllChildren(child)); // 递归添加嵌套子节点
//     }
//     return children;
// }
// console.log(`xxxxxxxxxx`);
// // 使用示例
// // text("重答").findOne();
// // auto.refreshRootNode() 
// let rootNode = auto.rootInActiveWindow;
// console.log("目标节点数量：", rootNode);
// // let root = className("WebView").findOne().parent();
// // console.log(`${tag}节点树: ${root.dumpHierarchy()}`);
// rootNode.scrollForward() 
// let allChildren = getAllChildren(rootNode);
// console.log("所有子节点数量：", allChildren.size());
// var content = `\n\n=== 问题： ===\n获取时间：\n\n`;
// allChildren.forEach(node => {
//     //获取最新的文本
//     var text = node.getText() || node.getContentDescription();
//     if (text && text.toString().trim().length != 0) {
//         // if (text.toString().includes("手游巴士")) {
//         //     while(node.getParent() != null) {
//         //         node = node.getParent();
//         //         console.log(`=======父节点：${node.getClassName()} ${node.getText()} ${node.getContentDescription()}`);
//         //     }
//         // }
//         content += `== ${node.getClassName()} `+ text + "\n";
//     }
// });

// content += "\n";  // 添加空行分隔不同问题
// console.log(content);


// let clipboardText = getClip();
// log("剪贴板内容：", clipboardText);

// 注册剪贴板监听器
var clip = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE);
// clip.addPrimaryClipChangedListener(() => {
//     let item = clip.getPrimaryClip().getItemAt(0);
//     let text = item.coerceToText(context);
//     log("剪贴板更新：", text);
// });

// 手动触发一次读取
// let currentText = clip.getPrimaryClip().getItemAt(0).getText();
// log("当前内容：", currentText);




// launch("com.tencent.gamehelper.accessibilityservice"); 
// sleep(2000);
// let clipboardText = getClip();
// console.log("剪贴板内容：", clipboardText);
// launch("com.tencent.mm"); 
// sleep(2000);




// function clickCopy() {
//     var isSuccess = tools.clickImage("./img/copy.png",
//         {
//             limit_x: [0.7, 0.9], limit_y: [0.7, 0.9],
//             continueOnError: true, timeout: 5000
//         });
//     if (!isSuccess) {
//         console.log("没有找到微信复制按钮,尝试节点点击");
//         var node = findWithTimeout(id("pil"), 2000);
//         if (node == null) {
//             return false
//         }
//         console.log("node------", node);
//         click(node.bounds().centerX(), node.bounds().centerY());
//         return true;
//     }
//     sleep(1000);
//     return isSuccess;
// }

// function findWithTimeout(selector, timeout = 2000) {
//     let deadline = Date.now() + timeout;
//     do {
//         let node = selector.findOne();
//         if (node) return node;
//         sleep(300);
//     } while (Date.now() < deadline);
//     return null;
// }

// function launchWechat() {
//     let intent = new Intent();
//     intent.setClassName(
//         "com.tencent.mm",
//         "com.tencent.mm.ui.LauncherUI"
//     );
//     intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//     context.startActivity(intent);
//     intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//     sleep(2000)
//     tools.clickText("微信", { limit_x: [0, 0.5], limit_y: [0.5, 1], continueOnError: true, timeout: 3000 });
// }

// var tools = require('./core_api.js');
// requestScreenCapture();
// launchWechat();
// var copyResult = clickCopy();
// if (copyResult) {
//     launch("com.tencent.gamehelper.accessibilityservice");
//     sleep(1000);
//     let clipboardText = getClip();
//     console.log("剪贴板内容：", clipboardText);
//     launchWechat();
//     sleep(1000);
//     if (clipboardText != null && clipboardText != undefined) {
//        console.log("剪贴板内容：", clipboardText);
//     }

// }

// launch("com.tencent.gamehelper.accessibilityservice");
// console.log("启动辅助服务");
requestScreenCapture();
var result = tools.clickText("AI搜", { limit_x: [0.35, 0.65], continueOnError: true });
    if (!result) {
        console.log("没有找到AI搜按钮,简化搜索");
        tools.clickText("搜", { limit_x: [0.35, 0.65], limit_y: [0.11, 0.9], continueOnError: true });
    }
    //增加下一级页面校验容错，避免跳转不了
    var checkResult = tools.findText("问AI", { limit_x: [0.7, 1], timeout: 5000 });
    if (checkResult == null) {
        console.log("没有找到问AI按钮,继续尝试点击AI搜索");
        tools.clickText("索", { limit_x: [0.35, 0.65], limit_y: [0.11, 0.9] });
    }