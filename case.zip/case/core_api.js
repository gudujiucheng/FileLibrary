// 动作方向枚举类型
const DirectionType = Object.freeze({
    UP: 1,
    DOWN: 2,
    LEFT: 3,
    RIGHT: 4
});
const Tool = {
    // 任务队列相关====================开始==========================

    //▲▲▲▲▲▲▲▲▲▲新增的机器人通知模块▲▲▲▲▲▲▲▲▲▲
    sendToBot: function (content) {
        let finalContent = `${device.brand} ${device.model} 安卓版本：${device.release}\n\n${content}`;
        let webhookUrl = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=acc77533-a9cc-45b7-a63c-117a9125f544";


        let payload = {
            msgtype: "markdown",
            markdown: {
                content: finalContent.replace(/\n/g, '\n\n')
            }
        };

        // 调试输出
        console.log("准备发送的数据:", JSON.stringify(payload, null, 2));

        // 增强型请求
        let response = http.postJson(webhookUrl, payload, {
            headers: {
                'Content-Type': 'application/json; charset=utf-8'
            },
            timeout: 10000,
            ignoreSSL: true
        });
        if (response && response.statusCode === 200) {
            let result = response.body.json();
            console.log("企微API响应:", JSON.stringify(result, null, 2));

            if (result.errcode === 0) {
                console.log("✅ 报告已成功发送至企微机器人");
            } else {
                throw new Error(`API错误: [${result.errcode}] ${result.errmsg}`);
            }
        } else {
            let status = response ? response.statusCode : "无响应";
            throw new Error(`HTTP异常状态码: ${status}`);
        }
    },

    task: function (config) {
        // 私有状态封装
        const state = {
            stats: {},
            queue: [],
            currentUserId: null,
            startTime: Date.now()
        };
        const manager = com.tencent.assistant.TaskExecutorManager.getInstance();
        // 初始化统计系统（闭包保护）
        (function init() {
            config.userIds = manager.getTargetUserIds();

            //转换类型
            if (!Array.isArray(config.userIds)) {
                const userIdArray = Array.from(config.userIds);
                config.userIds = userIdArray;
            }
            if (config.userIds.length === 0) {
                throw new Error("❌ 参数异常：userIds必须是非空数组，请检查配置");
            }

            console.log("🚀 任务开始执行，目标账户：" + config.userIds);

            //等待辅助服务开启 & 申请录屏权限 & 尝试自动授予录屏权限
            _cleanupMulProcess();
            auto.waitFor()//如果辅助服务未启动  会在在无障碍服务启动后继续运行.
            //部分手机可能不管用（有些系统隐藏了控件），不管用的时候，就需要手动点击一下
            console.log("版本号device.sdkInt：", device.sdkInt)
            if (device.sdkInt > 28) {
                //子线程并行执行任务，等待截屏权限申请并同意
                threads.start(function () {
                    packageName('com.android.systemui').text('立即开始').waitFor();
                    text('立即开始').click();
                });
            }
            requestScreenCapture();
            // 初始化统计数据
            config.userIds.forEach(userId => {
                state.stats[userId] = {
                    attempts: 0,
                    isNeedRetry: true,
                    description: "",
                    success: false,
                    noTarget: false,
                    otherInfo: new Map(),
                    errors: []
                };
            });
        })();

        //▼▼▼▼▼▼▼▼▼▼新增的报告生成模块▼▼▼▼▼▼▼▼▼▼
        function _generateReportContent() {
            let totalUsers = config.userIds.length;
            let successCount = Object.values(state.stats).filter(s => s.success).length;
            let noTaskCount = Object.values(state.stats).filter(s => s.noTarget).length;
            let successRate = (successCount / totalUsers * 100).toFixed(2);

            let mdContent = `## ⚡️ 企微任务执行报告\n\n`;
            mdContent += `**总用户数:** ${totalUsers}\n`;
            mdContent += `**用户列表:** ${config.userIds}\n`;
            mdContent += `**成功数:** ${successCount}（含无任务用户${noTaskCount}个）\n`;
            mdContent += `**成功率:** ${successRate}%\n\n`;
            const userIds = Object.keys(state.stats);
            if (successCount === totalUsers) {
                mdContent += `**执行结果:** 全部成功\n\n`;
            } else {
                mdContent += `### 📊 失败明细\n`;
                userIds.forEach(userId => {
                    let stat = state.stats[userId.toString()];
                    console.log("stat:", stat);
                    if (!stat.success) {
                        let errors = stat.errors.map(e => `\n${e}`).join('') || "无";
                        mdContent += `**用户ID:** \`${userId}\` \`${Tool.formatMap(stat.otherInfo)}\` `;
                        mdContent += `**执行次数:** ${stat.attempts + 1}次 `;
                        mdContent += `**错误描述:** ${errors}\n\n`;
                    }
                });
            }
            let isHasAppendNoTargetDesc = false;
            userIds.forEach(userId => {
                let stat = state.stats[userId.toString()];
                if (stat.noTarget) {
                    if (!isHasAppendNoTargetDesc) {
                        mdContent += "### 📊 未发现需要执行的任务\n";
                        isHasAppendNoTargetDesc = true;
                    }
                    mdContent += `>用户ID: \`${userId}\`  ${Tool.formatMap(stat.otherInfo)}未发现可执行的任务\n`;
                }
            });
            mdContent += `**完成时间:** ${new Date().toLocaleString()},累计耗时${((Date.now() - state.startTime) / 1000).toFixed(2)}秒\n`;
            return mdContent;
        }


        return {
            execute: function (businessLogic) {
                try {
                    state.queue = config.userIds.slice();

                    while (state.queue.length) {
                        state.currentUserId = state.queue.shift();
                        let userStat = state.stats[state.currentUserId];
                        manager.updateChildTaskStatus(state.currentUserId,userStat.otherInfo.get("name")|| "",
                            com.tencent.assistant.model.ChildTaskStatus.RUNNING,
                            userStat.attempts,
                            "任务执行中");

                        try {
                            _launchMulApp(state.currentUserId, userStat);
                            businessLogic(state.currentUserId, userStat);
                            var errorMsg = `✅ 用户${state.currentUserId} 任务执行结果：${userStat.description}`;
                            console.log(errorMsg);
                            var status = userStat.noTarget ?
                                com.tencent.assistant.model.ChildTaskStatus.NO_TASK :
                                com.tencent.assistant.model.ChildTaskStatus.SUCCESS;
                            manager.updateChildTaskStatus(state.currentUserId,userStat.otherInfo.get("name")|| "",
                                status,
                                userStat.attempts + 1,
                                errorMsg);
                        } catch (e) {
                            _handleTaskError(e, userStat);
                        } finally {
                            _cleanupMulProcess();
                        }
                    }
                    manager.onTaskCompleted();
                    // 发送报告到企微机器人
                    Tool.sendToBot(_generateReportContent());
                    exit();
                } catch (e) {
                    Tool.sendToBot(`❌ 任务执行异常: ${e.message}`);
                    exit();
                }
            }
        };

        // 清理多开的进程
        function _cleanupMulProcess() {
            console.log(`🧹 清理多开进程,当前用户：${state.currentUserId}`);
            app.startActivity({
                packageName: "com.tencent.mulapp",
                className: "com.tencent.da.AdbCommandActivity",
                extras: { cmd: "killAll" }
            });
            sleep(3000);
        }

        function _launchMulApp(userId, userStat) {
            app.startActivity({
                packageName: "com.tencent.mulapp",
                className: "com.tencent.da.AdbCommandActivity",
                extras: {
                    cmd: "start",
                    userId: userId.toString(),
                    packageName: config.packageName,
                    activityName: config.activityName
                }
            });

            let checkCount = 0;
            while (checkCount++ < 10) {
                let current = currentActivity();
                console.log(`当前Activity: ${current}`);
                // 检查是否在未登录页面集合中
                if (config.unLoginPages && config.unLoginPages.some(page => current.includes(page))) {
                    //没有登录态的不用重试
                    userStat.isNeedRetry = false;
                    throw new Error("用户未登录 [页面校验]");
                }
                if (config.unLoginTexts) {
                    let unLoginInfoResult = Tool.findAllByTexts(config.unLoginTexts);
                    if (unLoginInfoResult && unLoginInfoResult.length > 0) {
                        //没有登录态的不用重试
                        userStat.attempts = config.maxRetries
                        throw new Error("用户未登录 [文本校验]");
                    }
                }

                if (config.targetPages && config.targetPages.some(page => current.includes(page))) {
                    console.log(`✅ 用户 ${userId} 已成功启动 [页面校验]`);
                    return;
                }
                if (config.targetTexts) {
                    let successInfoResult = Tool.findAllByTexts(config.targetTexts);
                    if (successInfoResult && successInfoResult.length > 0) {
                        console.log(`✅ 用户 ${userId} 已成功启动 [文本校验]`);
                        return;
                    }
                }

                sleep(1000);
            }
            throw new Error("应用启动超时");
        }

        function _handleTaskError(error, userStat) {
            // 错误信息标准化处理
            let errorMessage = (error instanceof Error ? error.message : String(error)).replace(/\n/g, ' ');

            // 获取完整的堆栈信息（兼容非Error对象的情况）
            let fullStack = (error instanceof Error && error.stack)
                ? error.stack
                : `Non-Error Object: ${JSON.stringify(error)}`;

            // 增强的错误日志输出
            console.log([
                `❌ 用户 ${state.currentUserId} 失败:`,
                `┌ 错误类型: ${error.name || 'UnknownError'}`,
                `├ 错误信息: ${errorMessage}`,
                `└ 堆栈跟踪:`
            ].join('\n'));

            // 格式化输出堆栈信息（保留原始换行格式）
            fullStack.split('\n').forEach((line, index) => {
                console.log(`   ${index === 0 ? '└─' : '   '} ${line}`);
            });

            // 记录用户错误统计（保留原始格式）
            var errorMsg = `>第${userStat.attempts + 1}次: [${error.name || 'Error'}] ${errorMessage}`;
            userStat.errors.push(errorMsg);
            manager.updateChildTaskStatus(state.currentUserId,userStat.otherInfo.get("name")|| "",
                com.tencent.assistant.model.ChildTaskStatus.FAILED,
                userStat.attempts + 1,
                errorMsg);

            // 带指数退避的重试机制
            if (userStat.isNeedRetry && userStat.attempts < config.maxRetries) {
                userStat.attempts++;
                console.log(`↩️ 用户 ${state.currentUserId},任务失败，加入重试队列`);
                state.queue.push(state.currentUserId);
            }
        }
    },


    // 任务队列相关====================结束==========================


    // 公共方法====================开始==========================
    getAllChildren: function (node) {
        let children = new java.util.ArrayList();
        if (node == null) return children;
        for (let i = 0; i < node.childCount(); i++) {
            let child = node.child(i);
            children.add(child); // 添加直接子节点
            children.addAll(Tool.getAllChildren(child)); // 递归添加嵌套子节点
        }
        return children;
    },
    dpToPx: function (dp) {
        let metrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * metrics.density);
    },
    spToPx: function (sp) {
        let metrics = context.getResources().getDisplayMetrics();
        return Math.round(sp * metrics.scaledDensity);
    },
    formatMap: function (map) {
        if (!map?.size) return "";
        const entries = Array.from(map, ([k, v]) => `${k}: ${v}`).join(' | ');
        return `\`${entries}\``;
    },

    getFormattedDate: function () {
        const now = new Date();

        // 获取月份并补零（注意月份从0开始计数）
        const month = String(now.getMonth() + 1).padStart(2, '0');

        // 获取日期并补零
        const day = String(now.getDate()).padStart(2, '0');

        return `${month}月${day}日`;
    },

    queryInstallCount: function () {
        // 定义内容提供者 URI
        let uri = android.net.Uri.parse("content://com.tencent.multiapp/installWWorkCount");

        // 获取 ContentResolver
        let resolver = context.getContentResolver();

        try {
            // 执行查询
            let cursor = resolver.query(uri, null, null, null, null);

            // 处理查询结果
            if (cursor) {
                let results = [];
                let columnIndex = cursor.getColumnIndex("installWWorkCount");

                while (cursor.moveToNext()) {
                    // 读取整型数据
                    let value = cursor.getInt(columnIndex);
                    results.push(value);
                    log("查询到安装次数:", value);
                }

                cursor.close();
                return results;
            } else {
                toast("未查询到数据");
                return [];
            }
        } catch (e) {
            console.error("查询失败:", e);
            toast("查询失败，请检查权限");
            return null;
        }
    },

    /**
     * 获取完整节点路径（包含包名的完整类名）
     * @param {AccessibilityNode} node 目标节点
     * @returns {string|null} 示例：//android.widget.FrameLayout[3]/android.widget.LinearLayout[1]
     */
    _getFullViewPath: function (node) {
        if (!node) return null;

        const pathSegments = [];
        let currentNode = node;
        let depth = 0; // 防止循环引用
        while (currentNode && depth++ < 50) {
            // 获取完整类名（保留包名）
            let className = currentNode.getClassName()?.toString() || 'Unknown';

            // 计算在父节点中的位置索引
            let index = Tool._getClassIndex(currentNode);

            pathSegments.unshift(`${className}[${index}]`);

            // 向上遍历父节点
            let parent = currentNode.getParent();
            if (!parent || parent === currentNode) break;
            currentNode = parent;
        }

        return '//' + pathSegments.join('/');
    },

    /**
     * 计算同类控件在父节点中的出现次数（从1开始）
     * @private
     */
    _getClassIndex: function (node) {
        const parent = node.getParent();
        if (!parent) return -1; // 根节点默认为-1 //FIXME 这里还有异常需要fix

        let count = 0;
        const targetClass = node.getClassName()?.toString();

        // 遍历父节点的所有子节点
        const childCount = parent.getChildCount();
        for (let i = 0; i < childCount; i++) {
            let child = parent.getChild(i);
            if (!child) continue;

            // 统计同类控件数量
            let childClass = child.getClassName()?.toString();
            if (childClass === targetClass) {
                count++;
            }

            // 找到当前节点时停止计数
            if (child.equals(node)) {
                return count; // 返回当前计数（从1开始）
            }
        }

        return -1; // 未找到时默认返回1
    },
    // 格式化节点结果
    _transformToTargetObject: function (text, desc, rect, node) {
        const centerX = Math.floor((rect.left + rect.right) / 2);
        const centerY = Math.floor((rect.top + rect.bottom) / 2);
        var style = "default"
        if (text) {
            style = "text"
        } else if (desc) {
            style = "desc"
        }
        return {
            label: text || desc,//目标文本
            style: style,//节点内容类型
            centerX: centerX,//x中心点
            centerY: centerY,//y中心点
            relative: {//中心点 相对坐标
                x: (centerX / device.width).toFixed(3),
                y: (centerY / device.height).toFixed(3)
            },
            rect,
            node: node
        };
    },
    // 目标位置计算（与文本查找完全一致）
    _calculateTargetPos: function (matchResult, targetPos) {
        const centerX = matchResult.point.x + matchResult.templateSize.width * targetPos[0];
        const centerY = matchResult.point.y + matchResult.templateSize.height * targetPos[1];
        return { x: centerX, y: centerY };
    },

    //根据限制的相对坐标，计算实际的绝对坐标范围
    _getAreaBounds: function (options) {
        const { limit_x = [0, 1], limit_y = [0, 1] } = options;
        return {
            x: [Math.floor(limit_x[0] * device.width), Math.ceil(limit_x[1] * device.width)],
            y: [Math.floor(limit_y[0] * device.height), Math.ceil(limit_y[1] * device.height)]
        };
    },

    //过滤不在区域内的节点（OCR和CV是直接截取区域图，节点是获取所有节点后再过滤）
    _filterByBounds: function (node, options) {
        const safeBounds = Tool._getAreaBounds(options);
        let rect = new android.graphics.Rect();
        node.getBoundsInScreen(rect);
        // console.log(`==Node bounds: left=${rect.left}, right=${rect.right}, top=${rect.top}, bottom=${rect.bottom}`);
        // console.log(`==Limit bounds: x[0]=${safeBounds.x[0]}, x[1]=${safeBounds.x[1]}, y[0]=${safeBounds.y[0]}, y[1]=${safeBounds.y[1]}`);
        return rect.left >= safeBounds.x[0] && rect.right <= safeBounds.x[1] &&
            rect.top >= safeBounds.y[0] && rect.bottom <= safeBounds.y[1];
    },

    _onError: function (errorMessage, options = {}) {
        // 参数解析（默认抛出异常）
        const { continueOnError = false } = options;
        console.log(`-->>${errorMessage}`);
        if (!continueOnError) {
            throw new Error(`${errorMessage}`);
        }
    },
    // 公共方法：获取屏幕区域限制参数
    _getScreenRegion: function (options = {}) {
        // 获取全屏截图用于计算
        const fullScreen = images.captureScreen();
        const screenWidth = fullScreen.getWidth();
        const screenHeight = fullScreen.getHeight();

        // 处理坐标范围参数
        const limit_x = options.limit_x || [0, 1];
        const limit_y = options.limit_y || [0, 1];

        // 计算实际像素范围（自动排序+边界保护）
        const calcRange = (ratioRange, maxValue) => {
            const sorted = Array.from(ratioRange).sort((a, b) => a - b);
            return [
                Math.max(0, Math.floor(sorted[0] * maxValue)),
                Math.min(maxValue, Math.ceil(sorted[1] * maxValue))
            ];
        };

        // 获取有效像素范围
        const [x1, x2] = calcRange(limit_x, screenWidth);
        const [y1, y2] = calcRange(limit_y, screenHeight);

        // 返回裁剪后的图像和原始屏幕尺寸
        return {
            croppedImg: images.clip(fullScreen, x1, y1, x2 - x1, y2 - y1),
            screenSize: { width: screenWidth, height: screenHeight },
            regionOffset: { x: x1, y: y1 } // 区域偏移量用于坐标转换
        };
    },

    // 公用超时处理函数
    _waitUntilFound: function (action, options) {
        const timeout = options.timeout || 10000;
        const interval = options.interval || 1000;
        const continueOnError = options.continueOnError;
        const startTime = Date.now();

        while (Date.now() - startTime < timeout) {
            var result = action();
            if (result) return result;
            sleep(interval);
        }
        const errorMsg = "操作超时 (" + timeout + "ms)";
        if (!continueOnError) throw new Error(errorMsg);
        console.warn(errorMsg);
        return null;//方便外部统一判断
    },

    // 公共方法====================结束==========================


    // 核心操作api====================开始==========================

    /**
     * 滚动查找文本
     * 配置项:
     * - each_distance: 单次滚动比例 (默认0.3)
     * - max_scroll_times: 最大滚动次数 (默认10)
     * - direction: 滚动方向 (默认UP)
     * - scroll_start_pos: 起始位置比例 (默认[0.5,0.5])
     * - continueOnError: 未找到时是否抛出异常 (默认false)
     */
    scrollUntilFindText: function (targetText, options = {}) {
        const {
            each_distance = 0.3,
            max_scroll_times = 10,
            direction = DirectionType.UP,
            scroll_start_pos = [0.5, 0.5],
            continueOnError = false,
            onScroll = null//回调函数
        } = options;
        console.info(`[ScrollSearch] 开始搜索文本 "${targetText}"，配置：${JSON.stringify(options)}`);
        // 失败统计
        let scrollCount = 0;

        while (scrollCount < max_scroll_times) {
            console.verbose(`[ScrollSearch] 第 ${scrollCount + 1}/${max_scroll_times} 次查找`);
            // 执行滚动后回调,先回调给外部，在找文本，避免内部找到文本直接结束了
            if (typeof onScroll === 'function') {
                try {
                    onScroll({
                        currentScroll: scrollCount + 1,   // 当前已滚动次数
                        maxScrollTimes: max_scroll_times, // 最大允许滚动次数
                        direction: direction,        // 当前滚动方向
                        searchText: targetText       // 要查找的目标文本
                    });
                } catch (e) {
                    console.error(`滚动回调执行出错: ${e}`);
                }
            }
            // 先尝试查找文本
            var result = Tool.findText(targetText, {
                continueOnError: true,
                limit_x: [0, 1],
                limit_y: [0, 1],
                timeout: 1000
            });



            if (result != null) {
                console.log(`✅ 在第 ${scrollCount + 1} 次滚动后找到文本 "${targetText}"`);
                return Object.assign({}, result, { scroll_times: scrollCount + 1 });
            }

            // 执行滚动操作
            Tool.scroll(direction, {
                eachDistance: each_distance,
                scrollTimes: 1,
                scrollStartPos: scroll_start_pos,
                interval: 800 // 固定间隔确保内容加载
            });

            scrollCount++;

            sleep(1000); // 等待内容稳定
        }

        // 达到最大滚动次数处理
        const errorMsg = `滚动 ${max_scroll_times} 次后仍未找到 "${targetText}"`;
        console.error(errorMsg);
        if (!continueOnError) throw new Error(errorMsg);
        return { success: false, message: errorMsg };
    },

    // 改造后的查找文本方法
    findText: function (text, options) {
        options = options || {};
        var timeout = options.timeout;
        delete options.timeout; // 移除超时参数
        // 创建新对象合并参数
        var modifiedOptions = Object.assign({}, options, {
            continueOnError: true//轮询查找中的，单次查找不抛异常
        });

        //说明：无论是点击文本还是输入文字，都是先找到文本，然后再操作，所以统一在这里超时轮询逻辑即可
        return Tool._waitUntilFound(function () {
            return Tool._findTextCore(text, modifiedOptions);
        }, {
            timeout: timeout,
            interval: options.interval,
            continueOnError: options.continueOnError
        });
    },

    /**
     * 增强版节点批量查找
     * @param {string|array} targetTexts 目标文本（支持模糊匹配）
     * @param {object} options 配置项
     *   - id: 节点资源ID（如"com.example:id/login_btn"）
     *   - xpath: 简化版XPath语法（如"//Button[@text='确定']"）
     *   - limit_x: 水平搜索范围比例 [start,end]
     *   - limit_y: 垂直搜索范围比例 [start,end]
     */
    _findAllNodesByTexts: function (targetTexts, options) {
        options = options || {};
        console.info(`[NodeBatchSearch] 开始批量查找 ${targetTexts.join(',')}`);
        // 查找系统节点
        const systemNodes = Tool._traverseSystemWindows(targetTexts, options);
        if (systemNodes.length === 0) {
            return [];
        }
        console.verbose(`[NodeBatchSearch] 原始系统节点数: ${systemNodes.length}`);

        // 去重处理
        const uniqueKeys = {};
        const uniqueNodes = [];
        for (var i = 0; i < systemNodes.length; i++) {
            var node = systemNodes[i]; // 修正变量名错误
            var key = node.getViewIdResourceName() + "|" + node.getClassName() + "@" + node.hashCode();
            if (!uniqueKeys[key]) {
                uniqueKeys[key] = true;
                var rect = new android.graphics.Rect();
                node.getBoundsInScreen(rect)
                var result = Tool._transformToTargetObject(node.getText(), node.getContentDescription(), rect, node);
                // 记录节点详情
                console.log(`[节点详情] ${key} 
                文本: ${result.label}
                可见: ${node.isVisibleToUser()}
                相对坐标: ${result.relative.x},${result.relative.y}`);
                uniqueNodes.push(result);
            }

        }
        console.info(`[NodeBatchSearch] 完成批量查找，共找到 ${uniqueNodes.length} 个节点`);
        return uniqueNodes;
    },

    _traverseNode: function (node, callback) {
        if (!node) return;
        callback(node);

        for (var i = 0; i < node.getChildCount(); i++) {
            var child = node.getChild(i);
            if (child) Tool._traverseNode(child, callback);
        }

    },

    //收集当前屏幕上可见的所有节点
    _collectAllVisibleNodes: function (options) {
        const nodes = [];
        auto.windows.forEach(window => {
            Tool._traverseNode(window.root, node => {
                if (node && node.isVisibleToUser() && Tool._filterByBounds(node, options)) {
                    nodes.push(node);
                }
            });
        });
        console.info(`[_collectAllVisibleNodes] 限定区域内，当前页面收集到 ${nodes.length} 个可见节点`);
        return nodes;
    },
    //收集当前屏幕上可见的所有节点


    /**
     * 获取所有带有文本的node节点
     * @param limit_x  limit_y 限制区域
     * @returns {*[]}
     */
    getAllHasTextNodes: function (options) {
        if (options == null) {
            options = { limit_x: [0, 1], limit_y: [0, 1] };
        } else {
            // 用逻辑或 || 实现：如果不存在则用默认值
            options.limit_x = options.limit_x || [0, 1];
            options.limit_y = options.limit_y || [0, 1];
        }
        const nodes = [];
        auto.windows.forEach(window => {
            Tool._traverseNode(window.root, node => {
                let text = node.getText();
                let desc = node.getContentDescription();
                if (node && node.isVisibleToUser()
                    && ((text && text.toString().length > 0) || (desc && desc.toString().length > 0))
                    && Tool._filterByBounds(node, options)) {
                    let rect = new android.graphics.Rect();
                    node.getBoundsInScreen(rect)
                    //转换成统一对象
                    nodes.push(Tool._transformToTargetObject(node.getText(), node.getContentDescription(), rect, node));
                }
            });
        });
        console.info(`[getAllHasTextNodes] 限定区域内，当前页面收集到 ${nodes.length} 个可见节点`);
        return nodes;
    },

    /**
     * 获取限制区域内的文本
     * @param options
     * @returns {*[]}
     */
    getAllTextsByOcr: function (options) {
        if (options == null) {
            options = { limit_x: [0, 1], limit_y: [0, 1] };
        } else {
            // 用逻辑或 || 实现：如果不存在则用默认值
            options.limit_x = options.limit_x || [0, 1];
            options.limit_y = options.limit_y || [0, 1];
        }
        // 获取区域限制后的图像
        const { croppedImg, screenSize, regionOffset } = Tool._getScreenRegion(options);
        // OCR识别
        const results = ocr.paddle.detect(croppedImg, {
            useSlim: false,
            cpuThreadNum: 4
        });

        // 坐标转换方法
        const adjustCoordinates = (rect) => ({
            left: rect.left + regionOffset.x,
            top: rect.top + regionOffset.y,
            right: rect.right + regionOffset.x,
            bottom: rect.bottom + regionOffset.y
        });

        // 处理识别结果（多文本匹配）
        const formatResult = [];
        // 转换标准对象
        for (var ocrItem of results) {
            formatResult.push(Tool._transformToTargetObject(ocrItem.label, null, adjustCoordinates(ocrItem.bounds), null));
        }
        return formatResult;
    },


    _traverseSystemWindows: function (targetTexts, options) {
        targetTexts = Array.isArray(targetTexts) ? targetTexts : [targetTexts];
        const viewId = options.viewId || null;
        const viewPath = options.viewPath || null;
        const nodes = [];
        let finish = false; // Flag to indicate if a match is found
        const allNodes = Tool._collectAllVisibleNodes(options);
        let matchedNode;
        if (viewId) {
            console.verbose(`[NodeFind] 通过 viewId:${viewId} 查找节点`);
            matchedNode = allNodes.find(node => {
                // 1. ID匹配优先
                if (viewId && node.getViewIdResourceName() === viewId) {
                    return true;
                }
                return false;
            });
            if (matchedNode) {
                console.log(`✅ viewId匹配成功：${viewId}`);
                return [matchedNode];
            }

        }
        if (viewPath) {
            console.verbose(`[NodeFind] 通过 viewPath:${viewPath} 查找节点`);
            matchedNode = allNodes.find(node => {
                let xpath = Tool._getFullViewPath(node);
                // 2. Path匹配   这里传递的viewPath，最好顶级那个去掉，不要太长（目前顶级的获取不太对，暂未定位到原因）
                if (viewPath && xpath.endsWith(viewPath)) {
                    return true;
                }
            });

            if (matchedNode) {
                console.log(`✅ viewPath匹配成功：${viewPath}`);
                return [matchedNode];
            }
        }
        // 2. 文本匹配兜底
        allNodes.forEach(node => {
            let text = node.getText();
            let desc = node.getContentDescription();
            if (targetTexts == null) {
                finish = true; // Set flag to true
                console.log(`参数错误 targetTexts为空，直接返回`);
                return;
            }

            for (let target of targetTexts) {

                if ((text !== null && text !== undefined && text.toString().includes(target))
                    || (desc !== null && desc !== undefined && desc.toString().includes(target))) {
                    // Boundary filtering logic
                    if (!Tool._filterByBounds(node, options)) {
                        console.verbose(`[边界过滤] 节点 text:${text} desc:${desc} 超出限制区域,进行排除`);
                        continue;
                    }
                    console.log(`✅ 文本匹配成功 text:${text}  desc:${desc}`);
                    nodes.push(node);
                    matchFound = true; // Set flag to true
                    return;
                }
            }

        });


        return nodes;
    },


    /**
     * 增强文字查找
     * @param {string} text 目标文本
     * @param {object} options 配置项
     *   - limit_x: 水平搜索范围比例 [start,end] (默认全屏)
     *   - limit_y: 垂直搜索范围比例 [start,end] (默认全屏)
     *   - continueOnError: 未找到时是否抛出异常 (默认false)
     * @returns {MatchResult|null} 匹配结果
     */
    _findTextCore: function (text, options = {}) {
        console.info(`[_findTextCore] 开始查找文本 "${text}"，配置：${JSON.stringify(options)}`);
        const { continueOnError = false } = options;
        // 创建新对象合并参数
        const modifiedOptions = Object.assign({}, options, {
            continueOnError: true//轮询查找中的，单次查找不抛异常
        });
        const filtered = Tool.findAllByTexts(text, modifiedOptions)

        // 找到结果时返回
        if (filtered && filtered.length > 0) {
            return filtered[0];
        }

        // 未找到时的处理逻辑
        const errorMessage = `轮询查找中...[_findTextCore] 未找到文本: ${text} (搜索区域: x=${JSON.stringify(options.limit_x || '全屏')}, y=${JSON.stringify(options.limit_y || '全屏')})`;
        Tool._onError(errorMessage, options);

        return null;
    },

    //查找所有匹配的节点，本方法找不到场景下不会抛出异常，由外部调用者控制是否需要抛出异常
    findAllByTexts: function (targetTexts, options = {}) {
        // 参数标准化（支持字符串和数组输入）
        targetTexts = Array.isArray(targetTexts) ? targetTexts : [targetTexts];
        console.info(`[findAllByTexts] 开始查找文本 "${targetTexts}"，配置：${JSON.stringify(options)}`);
        if (options.isFindByNode !== false) { // 默认 true
            const nodeResults = Tool._findAllNodesByTexts(targetTexts, options);
            if (nodeResults && nodeResults.length > 0) {
                console.log(`findAllByTexts [NodeFind] 找到 ${nodeResults.length} 个节点匹配项`)
                return nodeResults;
            } else {
                console.log(`findAllByTexts [NodeFind] 没有找到文本 "${targetTexts}"的匹配项节点，准备OCR查找`)
            }
        }
        // 获取区域限制后的图像
        const { croppedImg, screenSize, regionOffset } = Tool._getScreenRegion(options);

        // OCR识别
        const results = ocr.paddle.detect(croppedImg, {
            useSlim: false,
            cpuThreadNum: 4
        });

        // 坐标转换方法
        const adjustCoordinates = (rect) => ({
            left: rect.left + regionOffset.x,
            top: rect.top + regionOffset.y,
            right: rect.right + regionOffset.x,
            bottom: rect.bottom + regionOffset.y
        });

        // 处理识别结果（多文本匹配）
        const filtered = [];
        // 遍历所有OCR识别结果
        for (var ocrItem of results) {
            if (options.showDetailLog) {
                console.log(`===========[findAllByTexts] OCR识别结果: ${ocrItem.label}`);
            }
            // 遍历每个目标文本
            for (var targetText of targetTexts) {
                // 检查当前OCR结果是否包含该目标文本
                if (ocrItem.label.includes(targetText)) {
                    // 将匹配结果添加到数组
                    filtered.push(Tool._transformToTargetObject(targetText, null, adjustCoordinates(ocrItem.bounds), null));
                }
            }
        }

        console.log(`findAllByTexts [ocrFind] 在区域[${JSON.stringify(options)}] 找到 ${filtered.length} 个"${targetTexts}"匹配项`);
        filtered.forEach((it, index) => {
            console.log(`  ${index + 1}: 绝对[${it.centerX},${it.centerY}] 相对[${it.relative.x},${it.relative.y}] "${it.label}"`);
        });
        // 找到结果时返回
        console.log(`[findAllByTexts] 在区域[${JSON.stringify(options)}] 找到 ${filtered.length} 个"${targetTexts}"匹配项`);
        return filtered;
    },


    clickText: function (text, options = {}) {
        console.info(`[Click] 开始点击文本 "${text}"，配置：${JSON.stringify(options)}`);
        options = options || {};
        const result = Tool.findText(text, Object.assign({}, options, {
            continueOnError: true
        }));

        if (result) {
            console.log(`文本 "${text} " success , 点击坐标 (${result.relative.x},${result.relative.y})`);
            if (result.node) {
                //为了更精准，这里针对node节点，使用实时坐标点击
                const rect = new android.graphics.Rect();
                result.node.getBoundsInScreen(rect);
                console.log(`[clickText] 获取最新Node节点点击坐标 (${rect.centerX()},${rect.centerY()}),原坐标(${result.centerX},${result.centerY})`);
                click(rect.centerX(), rect.centerY());
            } else {
                console.log(`[clickText] OCR 点击相对坐标 (${result.relative.x},${result.relative.y}),原坐标(${result.centerX},${result.centerY})`);
                click(result.centerX, result.centerY);
            }

            //基于节点查找的,延迟放低一些
            sleep(result.node ? 2000 : 500)
            return true;
        }

        const errorMsg = '[clickText]"' + text + '" 失败';
        Tool._onError(errorMsg, options);
        return false;
    },


    // 核心滚动方法
    scroll: function (direction, options = {}) {
        const {
            eachDistance = 0.1,//每次滚动的距离 默认0.1 表示10%
            scrollTimes = 1,//滚动的次数，默认1次
            scrollStartPos = [0.5, 0.5],//滚动起始位置，默认中间位置
            interval = 500,//两次滚动之间的时间间隔(单位是：毫秒)
            duration = 500//滚动时长（注意：单位是：毫秒）
        } = options;

        // 获取屏幕尺寸
        const { width: screenWidth, height: screenHeight } = device;

        // 计算起始点绝对坐标
        const [startXPercent, startYPercent] = scrollStartPos;
        const startX = screenWidth * startXPercent;
        const startY = screenHeight * startYPercent;

        // 根据方向计算滑动距离
        let delta;
        switch (direction) {
            case DirectionType.UP:
            case DirectionType.DOWN:
                delta = screenHeight * eachDistance;
                break;
            case DirectionType.LEFT:
            case DirectionType.RIGHT:
                delta = screenWidth * eachDistance;
                break;
            default:
                throw new Error('Invalid scroll direction');
        }

        // 执行多次滑动
        for (let i = 0; i < scrollTimes; i++) {
            let endX = startX;
            let endY = startY;

            // 计算滑动终点坐标
            switch (direction) {
                case DirectionType.UP:
                    endY = Math.max(0, startY - delta);
                    break;
                case DirectionType.DOWN:
                    endY = Math.min(screenHeight, startY + delta);
                    break;
                case DirectionType.LEFT:
                    endX = Math.max(0, startX - delta);
                    break;
                case DirectionType.RIGHT:
                    endX = Math.min(screenWidth, startX + delta);
                    break;
            }

            // Auto.js原生滑动操作
            swipe(startX, startY, endX, endY, duration);

            // 非最后一次滑动才等待间隔
            if (i < scrollTimes - 1) {
                sleep(interval);
            }
        }
    },

    scrollUp: function (options = {}) {
        Tool.scroll(DirectionType.UP, options);
    },

    scrollDown: function (options = {}) {
        Tool.scroll(DirectionType.DOWN, options);
    },

    scrollLeft: function (options = {}) {
        Tool.scroll(DirectionType.LEFT, options);
    },

    scrollRight: function (options = {}) {
        Tool.scroll(DirectionType.RIGHT, options);
    },

    // 改造后的图像查找方法
    findImage: function (templatePath, options) {
        options = options || {};
        const timeout = options.timeout;
        delete options.timeout;
        // 创建新对象合并参数
        const modifiedOptions = Object.assign({}, options, {
            continueOnError: true//轮询查找中的，单次查找不抛异常
        });
        //上层如果要使用图片相关逻辑，都统一调用这个入口，这样可以统一处理超时轮询逻辑
        return Tool._waitUntilFound(function () {
            return Tool._findImageCore(templatePath, modifiedOptions);
        }, {
            timeout: timeout,
            interval: options.interval,
            continueOnError: options.continueOnError,
        });
    },

    /**
     * 增强版图像查找
     * @param {string} templatePath 模板路径
     * @param {object} options 配置项
     *   - limit_x: 水平搜索范围比例 [start,end] (默认全屏)
     *   - limit_y: 垂直搜索范围比例 [start,end] (默认全屏)
     *   - targetPos: 目标点击位置比例 [x,y] (相对于模板区域)
     *   - minScale: 最小缩放比例 (默认0.5)
     *   - maxScale: 最大缩放比例 (默认2.0)
     *   - scaleStep: 缩放步长 (默认0.1)
     *   - threshold: 匹配阈值 (默认0.6)
     *   - continueOnError: 未找到时是否抛出异常 (默认false)
     * @returns {MatchResult|null} 匹配结果
     */
    _findImageCore: function (templatePath, options = {}) {
        const config = Object.assign({
            limit_x: [0, 1],
            limit_y: [0, 1],
            targetPos: [0.5, 0.5],
            minScale: 0.5,
            maxScale: 2.0,
            scaleStep: 0.1,
            threshold: 0.6,
            continueOnError: false
        }, options);
        console.info(`[_findImageCore] 开始搜索图像 ${templatePath}，参数：${JSON.stringify(options)}`);
        let bestMatch = null;
        const viewId = options.viewId || null;
        const viewPath = options.viewPath || null;
        if (options.isFindByNode !== false && (viewId || viewPath)) { //有传递xpath 或者 id 的情况下，优先使用节点查找
            const nodeResults = Tool._findAllNodesByTexts(null, options);//尝试通过id或者xpath来查找节点
            if (nodeResults && nodeResults.length > 0) {
                console.log(`_findImageCore [NodeFind] 找到 ${nodeResults.length} 个节点匹配项`)
                let targetResult = nodeResults[0];

            } else {
                console.log(`_findImageCore [NodeFind] 没有找到图像viewId："${viewId}" viewPath："${viewPath}"的匹配项节点，准备CV查找`)
            }
        }


        let template = images.read(templatePath);
        let { croppedImg, screenSize, regionOffset } = Tool._getScreenRegion(config);
        let screen = croppedImg;
        if (screen == null) {
            let errorMsg = `[_findImageCore] 获取屏幕截图失败，请允许录屏权限`;
            if (!config.continueOnError) {
                throw new Error(errorMsg);
            }
            console.warn(errorMsg);
            return null;
        }
        if (template == null) {
            let errMsg = `[_findImageCore] 未能成功读取目标图，请检查图片是否存在`;
            Tool._onError(errMsg, options);
            return null;
        }

        // 浮点数精度处理
        for (let scale = config.minScale; scale <= config.maxScale + 0.0001;
            scale = parseFloat((scale + config.scaleStep).toFixed(2))) {
            var scaledTemplate = images.scale(template, scale, scale);

            // 尺寸校验
            if (scaledTemplate.width > screen.width || scaledTemplate.height > screen.height) {
                scaledTemplate.recycle();
                continue;
            }

            // 执行匹配
            var result = images.matchTemplate(screen, scaledTemplate, {
                threshold: config.threshold,
                max: 1
            });

            // 更新最佳匹配
            if (result.matches.length > 0) {
                var currentMatch = result.matches[0];
                if (!bestMatch || currentMatch.similarity > bestMatch.similarity) {
                    var globalPoint = {
                        x: currentMatch.point.x + regionOffset.x,
                        y: currentMatch.point.y + regionOffset.y
                    };

                    bestMatch = {
                        point: globalPoint,
                        similarity: currentMatch.similarity,
                        templateSize: {
                            width: scaledTemplate.width,
                            height: scaledTemplate.height
                        },
                        relative: {
                            x: globalPoint.x / screenSize.width,
                            y: globalPoint.y / screenSize.height
                        }
                    };
                }
            }
            scaledTemplate.recycle();
        }

        // 资源回收
        template.recycle();
        screen.recycle();

        // 结果处理
        if (bestMatch) {
            console.info(`[_findImageCore] 找到最佳匹配（相似度 ${(bestMatch.similarity * 100).toFixed(1)}%）`);
            var target = Tool._calculateTargetPos(bestMatch, config.targetPos);

            // 创建一个 bestMatch 的浅拷贝，并添加或覆盖属性
            var beatResult = Object.assign({}, bestMatch, {
                targetPoint: target,
                targetRelative: {
                    x: target.x / screenSize.width,
                    y: target.y / screenSize.height
                }
            });

            console.log(`================[_findImageCore] 最佳匹配坐标:`, beatResult);

            return beatResult;
        }

        const errorMsgResult = `[_findImageCore]未找到图像: ${templatePath} (搜索范围: x=${config.limit_x}, y=${config.limit_y})`;
        Tool._onError(errorMsgResult, options);
        return null;
    },


    clickImage: function (templatePath, options) {
        options = options || {};

        const result = Tool.findImage(templatePath, Object.assign({}, options, {
            continueOnError: true//轮询查找中的，单次查找不抛异常
        }));
        if (result) {
            click(result.targetPoint.x, result.targetPoint.y);
            return true;
        }
        const errorMsg = '[clickImage]"' + templatePath + '" 失败,未找到目标图标';
        Tool._onError(errorMsg, options);
        return false;
    },


    /**
     * 智能文本输入函数
     * @param {string} targetClickText 需要点击的目标文本（如"发消息"按钮）
     * @param {string} inputText 需要输入的文本内容
     * @param {object} options 配置项
     *   - limit_x: 水平搜索范围比例 [start,end] (默认全屏)
     *   - limit_y: 垂直搜索范围比例 [start,end] (默认全屏)
     *   - timeout: 查找目标超时时间（默认10000ms）
     *   - checkPaste: 是否验证粘贴成功（默认true）
     */
    inputText: function (targetClickText, inputText, options = {}) {
        // 参数解析（默认抛出异常）
        const { continueOnError = false, tryPos = null } = options;


        // 设置剪贴板内容
        setClip(inputText);
        console.log(`📋 已设置剪贴板内容: "${inputText}"`);

        // 查找目标位置
        const targetResult = Tool.findText(targetClickText, options);

        if (!targetResult || targetResult.centerX === undefined || targetResult.centerY === undefined) {
            Tool._onError(`[inputText]找不到目标文本: ${targetClickText}`, options);
            if (tryPos == null) {
                return;
            } else {
                console.log(`[inputText]找不到目标文本, 尝试使用指定坐标点击`);
                targetResult = {
                    centerX: Math.floor(tryPos[0] * device.width),
                    centerY: Math.floor(tryPos[1] * device.height)
                };
            }

        }
        console.log(`✅ 定位到目标位置: [${targetResult.centerX},${targetResult.centerY}]`);


        // 长按触发菜单
        press(targetResult.centerX, targetResult.centerY, 1500);
        console.log("🖱️ 已执行长按操作");
        sleep(500);//等待弹窗渲染

        // 点击粘贴按钮（多语言兼容）
        const allPastResults = Tool.findAllByTexts(["粘贴", "Paste"]);
        if (allPastResults && allPastResults.length > 0) {
            // 优先选择 style 为 "text" 的结果
            let textResult = allPastResults.find(result => result.style === "text");

            if (textResult) {
                //这个text优先是因为有些粘贴窗的父类 desc也是粘贴
                console.log("准备点击匹配的结果 text命中优先:", textResult.label);
            } else {
                // 如果没有 style 为 "text" 的结果，选择第一个结果
                textResult = allPastResults[0];
                console.log("准备点击匹配的结果（其他）:", textResult.label);
            }

            if (textResult.rect) {
                console.log("尝试使用起始点坐标，点击粘贴")
                click(textResult.rect.left + Tool.dpToPx(3), textResult.centerY);
            } else {
                console.log("尝试使用中心点坐标，点击粘贴")
                click(textResult.centerX - Tool.dpToPx(5), textResult.centerY);
            }
            return true;
        } else {
            Tool._onError(`[inputText] 找不到粘贴/Paste按钮`, options);
        }
        return false;

    },
}
// 导出 Tool 对象(必须要这样导出)
module.exports = Tool;

// auto.waitFor()
// requestScreenCapture();
// Tool.findText("出你的", { limit_y: [0.1, 0.3], timeout: 5000 ,showDetailLog: true});