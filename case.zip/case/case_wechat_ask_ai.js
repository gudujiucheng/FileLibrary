// 导入 Tool 类
var tools = require('./core_api.js');
const preStr = "穿越火线手游";
const outputFilePath = context.getFilesDir() + "/ai_responses.txt";
let { length, filtered } = getNeedRunQuestion();
if (filtered.length === 0) {
    onCompleted(`${length}个问题已经处理完毕,请点击case_share_wechat_ask_ai_result任务分享结果`);
}
auto.waitFor()
requestScreenCapture();
let questionCounter = 0;
const PAUSE_STRATEGY = {
    minQuestions: 3,
    maxQuestions: 6,
    minPause: 2 * 60 * 1000,  // 2分钟
    maxPause: 5 * 60 * 1000   // 3分钟
};
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function smartSleep() {
    // 基础延迟叠加策略检查
    if(questionCounter >= getRandomInt(PAUSE_STRATEGY.minQuestions, PAUSE_STRATEGY.maxQuestions)) {
        const pauseTime = getRandomInt(PAUSE_STRATEGY.minPause, PAUSE_STRATEGY.maxPause);
        console.log(`已完成${questionCounter}个问题，随机暂停${pauseTime/1000}秒`);
        sleep(pauseTime);
        questionCounter = 0;
    }
}
var retryCount = 0;
while (retryCount++ < 5) {
    try {
        let { filtered } = getNeedRunQuestion();
        console.log("待处理问题:", filtered);
        if (filtered.length === 0) {
            break;
        }
        launchWechat();
        checkMainPage();
        clickSearch();
        clickAISearch();
        let index = 0;
        filtered.forEach(question => {
            questionCounter++;
            pasteQuestion(question);
            waitAnswer();
            scrollToPageBottom();
            tools.scrollUp({ eachDistance: 0.5});
            let webNode = className("android.webkit.WebView").findOne();
            if (webNode == null) {
                throw new Error("没有找到WebView节点");
            }
            let allChildren = tools.getAllChildren(webNode);
            let currentTime = new Date().toLocaleString();
            // 创建要写入的内容
            let content = `\n\n=== 问题：${question} ===\n获取时间：[${currentTime}]\n\n`;
            let lastTop = -1;
            allChildren.forEach(node => {
                let text = node.getText() || node.getContentDescription();
                if(text && text.toString().includes("服务繁忙")) {
                    console.log("服务繁忙，退出");
                    let successList = getSuccessQuestions();
                    tools.sendToBot("服务繁忙，退出执行,已处理问题数量：" + successList.size);
                    engines.myEngine().forceStop();

                }
                if (text && text.toString().trim().length != 0) {
                    let rect = new android.graphics.Rect();
                    node.getBoundsInScreen(rect);
                    if (rect.top == lastTop) {
                        content += text
                    } else {
                        content += text + "\n";
                    }
                    lastTop = rect.top;
                }

            });

            content += "\n";  // 添加空行分隔不同问题
            // var copyResult = clickCopy();
            // if (copyResult) {
            //     launch("com.tencent.gamehelper.accessibilityservice");
            //     sleep(1000);
            //     let clipboardText = getClip();
            //     console.log("剪贴板内容：", clipboardText);
            //     //清空剪贴板
            //     setClip("");
            //     launchWechat();
            //     sleep(1000);
            //     if (clipboardText != null && clipboardText != undefined) {
            //         content += "++++复制的回答开始++++\n" + clipboardText + "++++复制的回答结束++++\n";
            //     }


            // }


            saveResult(content);
            smartSleep();
            const isLast = (index === filtered.length - 1);
            if (!isLast) {
                console.log("不是最后一个问题，尝试返回");
                back();
            }
            index++;
           
        }
        );
        let hasSuccessQuestions = getSuccessQuestions();
        let successCount = hasSuccessQuestions.size;
        onCompleted(`所有问题已处理完毕,累计成功处理 ${successCount} 个问题，请点击case_share_wechat_ask_ai_result任务分享结果`);
    } catch (e) {
        console.log("出现异常,继续重试中", e);
    }
}

if (retryCount >= 5) {
    tools.sendToBot(`❌ 问ai 任务执行异常, 重试次数超过${retryCount}次，退出,请稍后继续点击case_wechat_ask_ai任务重试`);
    console.log("重试次数超过5次，退出");
    engines.myEngine().forceStop();
}


//---------------------------------以下为工具函数---------------------------------
function saveResult(content) {
    try {
        console.log("📝 回答内容：", content);
        // 追加写入文件
        files.append(outputFilePath, content);
        console.log(`已保存回答到：${outputFilePath}`);
    } catch (e) {
        console.error("文件写入失败：", e);
    }
}

// 新增文件读取函数（需放置在脚本开头）
function readQuestionsFromFile() {
    const filePath = files.join(engines.myEngine().cwd(), "./config/ai_questions.txt");
    console.log("📂 问题文件路径:", filePath);

    try {
        if (!files.exists(filePath)) {
            console.error("问题文件不存在，将使用内置问题");
            return [];
        }

        const content = files.read(filePath)
            .split("\n")
            .filter(line => {
                // 过滤注释和空行（支持#开头的注释）
                const trimmed = line.trim();
                return trimmed && !trimmed.startsWith("#");
            })
            .map(line => `${preStr}${line.trim()}`);

        console.log("📝 从文件读取到", content.length, "个有效问题");
        return content;
    } catch (e) {
        console.error("文件读取失败:", e);
        return [];
    }
}


function getSuccessQuestions() {
    const processed = new Set();
    try {
        if (files.exists(outputFilePath)) {
            const content = files.read(outputFilePath);
            // 使用正则匹配已处理问题 [2,6](@ref)
            const regex = /^=== 问题：(.*?) ===/gm;
            let match;
            while ((match = regex.exec(content)) !== null) {
                var question = match[1].trim();
                processed.add(question);
                console.log(`已处理过的问题：${question}`);
            }
        }
    } catch (e) {
        console.error("读取历史文件失败，将处理所有问题", e);
    }
    return processed;
}


function getNeedRunQuestion() {
    files.ensureDir(outputFilePath);
    let questions = readQuestionsFromFile();
    let questionsLength = questions.length; // 原始问题数量

    if (questionsLength === 0) {
        let msg = "没有读取到有效问题，请检查配置文件";
        console.log(msg);
        onCompleted(msg);
        return { length: 0, filtered: [] }; // 异常时返回空结构[7](@ref)
    }

    let hasSuccessQuestions = getSuccessQuestions();
    let filteredQuestions = questions.filter(q => !hasSuccessQuestions.has(q));

    // 返回对象包含两个参数
    return {
        length: questionsLength,  // 原问题总数
        filtered: filteredQuestions  // 过滤后问题列表
    };
}


function onCompleted(msg) {
    toast(msg);
    tools.sendToBot(msg);
    engines.myEngine().forceStop();
}

function launchWechat() {
    let intent = new Intent();
    intent.setClassName(
        "com.tencent.mm",
        "com.tencent.mm.ui.LauncherUI"
    );
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    context.startActivity(intent);
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    sleep(2000)
    tools.clickText("微信", { limit_x: [0, 0.5], limit_y: [0.5, 1], continueOnError: true, timeout: 3000 });
}

function checkMainPage() {
    let i = 0;
    while (i < 10) {
        var current = currentActivity();
        console.log("当前页面: " + current);
        if (tools.findText("通讯", {
            limit_y: [0.8, 1],
            continueOnError: true,
            timeout: 2000,
            showDetailLog: true
        })) {
            launchSuccess = true;
            console.log("启动微信成功");
            return;
        }
        i++;
        sleep(1000);
        back();
    }
    console.log("启动微信失败");
    throw new Error("启动微信失败");
}

function clickSearch() {
    var isSuccess = tools.clickImage("./img/search.png",
        {
            limit_x: [0.7, 0.9], limit_y: [0, 0.1],
            continueOnError: true, timeout: 5000
        });
    if (!isSuccess) {
        isSuccess = tools.clickImage("./img/search_black.png",
            {
                limit_x: [0.7, 0.9], limit_y: [0, 0.1],
                continueOnError: true, timeout: 5000
            });
    }
    if (!isSuccess) {
        throw new Error("没有找到微信搜索按钮");
    }
}

function clickCopy() {
    var isSuccess = tools.clickImage("./img/copy.png",
        {
            limit_x: [0.7, 0.9], limit_y: [0.7, 0.9],
            continueOnError: true, timeout: 5000
        });
    if (!isSuccess) {
        console.log("没有找到微信复制按钮,尝试节点点击");
        var node = findWithTimeout(id("pil"), 2000);
        if (node == null) {
            return false
        }
        console.log("node------", node);
        click(node.bounds().centerX(), node.bounds().centerY());
        return true;
    }
    sleep(1000);
    return isSuccess;
}

function findWithTimeout(selector, timeout = 2000) {
    let deadline = Date.now() + timeout;
    do {
        let node = selector.findOne();
        if (node) return node;
        sleep(300);
    } while (Date.now() < deadline);
    return null;
}

function clickAISearch() {
    var result = tools.clickText("AI搜", { limit_x: [0.35, 0.65], continueOnError: true, showDetailLog: true });
    if (!result) {
        console.log("没有找到AI搜按钮,简化搜索");
        tools.clickText("搜", { limit_x: [0.35, 0.65], limit_y: [0.11, 0.9], continueOnError: true });
    }
    //增加下一级页面校验容错，避免跳转不了
    var checkResult = tools.findText("出你的", { limit_y: [0.1, 0.3], timeout: 5000, showDetailLog: true });
    if (checkResult == null) {
        console.log("没有找到提出你的输入框,继续尝试点击AI搜索");
        tools.clickText("索", { limit_x: [0.35, 0.65], limit_y: [0.11, 0.9] });
    }
    return { result, checkResult };
}

function pasteQuestion(question) {
    tools.clickText("出你的", { continueOnError: true, timeout: 2000 });
    tools.inputText("出你的", question, { showDetailLog: true, tryPos: [0.3, 0.2], continueOnError: true, });
    var inPasteSuccess = tools.findText(preStr, { continueOnError: true, timeout: 2000, limit_y: [0, 0.3] });
    console.log("校验是否复制成功", inPasteSuccess);
    var i = 0;
    while (inPasteSuccess == null && i < 4) {
        console.log("尝试粘贴问题");
        tools.inputText("出你的", question, { showDetailLog: true, tryPos: [0.3, 0.2] });
        inPasteSuccess = tools.findText(preStr, { continueOnError: true, timeout: 2000, limit_y: [0, 0.3] });
        if (inPasteSuccess) {
            break;
        }
        i++;
        sleep(1000);
    }
}

function waitAnswer() {
    var result = tools.clickText("问AI", { continueOnError: true ,timeout: 3000});
    if (!result) {
        tools.clickText("问", { limit_x: [0.7, 1] });
    }
    console.log("等待回答完成...");
    //循环等待直到回答完毕
    let checkTimes = 0;
    while (true) {
        // 检查是否满足退出条件
        let hasContinue = tools.findText("继续", {
            limit_y: [0.8, 1],
            timeout: 2000,
            continueOnError: true,
            showDetailLog: true

        });
        let hasAskAI = tools.findText("问A", {
            limit_y: [0.8, 1],
            timeout: 2000,
            continueOnError: true,
            showDetailLog: true
        });

        // 如果找到目标文本或超限则退出循环
        if ((hasContinue != null && hasContinue != undefined)
            || (hasAskAI != null && hasAskAI != undefined)
            || checkTimes > 30) {
            console.log(`检测到回答完成 检测次数${checkTimes} 次 或者找到继续提问按钮 ${hasContinue} 或者找到问AI按钮 ${hasAskAI}`);
            if (hasContinue) {
                console.log(`检测到继续提问：${hasContinue.label}`);
            }
            if (hasAskAI) {
                console.log(`检测到问AI：${hasAskAI.label}`);
            }
            break;
        }

        // 未找到目标文本则继续循环
        checkTimes++;
        sleep(1000);
    }
}

function scrollToPageBottom() {
    tools.scrollUntilFindText("重答", {
        max_scroll_times: 100,
        each_distance: 0.7,
        scroll_start_pos: [0.5, 0.8],
        onScroll: ({ currentScroll, maxScrollTimes }) => {
            console.log(`-----已完成 ${currentScroll} 次滚动（共尝试 ${maxScrollTimes} 次）`);
            // var hasRefrence = tools.clickText("篇参考资料", { continueOnError: true, timeout: 1000, });
            // if (hasRefrence) {
            //     console.log("发现参考资料，尝试展开");
            // }
        }
    });
}



