// 导入 Tool 类
var tools = require('./core_api.js');
const preStr = "穿越火线手游";
const outputFilePath = context.getFilesDir() + "/ai_responses.txt";
let filteredQuestions = getNeedRunQuestion();
auto.waitFor()
requestScreenCapture();
var retryCount = 0;
while (retryCount++ < 5) {
    try {
        filteredQuestions = getNeedRunQuestion();
        console.log("待处理问题:", filteredQuestions);
        app.launchApp("微信");
        sleep(2000)
        tools.clickText("微信", { limit_x: [0, 0.5], limit_y: [0.5, 1], continueOnError: true, timeout: 3000 });
        var i = 0;
        var launchSuccess = false;
        //回退到首页
        while (i < 10) {
            var current = currentActivity();
            console.log("当前页面: " + current);
            if (tools.findText("通讯录", {
                limit_x: [0, 0.5],
                limit_y: [0.8, 1],
                continueOnError: true,
                timeout: 2000
            })) {
                launchSuccess = true;
                console.log("启动微信成功");
                break;
            }
            i++;
            sleep(1000);
            back();
        }

        if (!launchSuccess) {
            console.log("启动微信失败");
            throw new Error("启动微信失败");
        }

        var isSuccess = tools.clickImage("./img/search.png",
            {
                limit_x: [0.7, 0.9], limit_y: [0, 0.1],
                continueOnError: true, timeout: 5000
            });
        if (!isSuccess) {
            console.log("没有找到微信添加按钮,尝试节点点击");
            var node = id("meb").findOne();
            console.log("node------", node);
            click(node.bounds().centerX(), node.bounds().centerY());
        }
        sleep(1000);

        var result = tools.clickText("AI搜", { limit_x: [0.35, 0.65], continueOnError: true });
        if (!result) {
            console.log("没有找到AI搜按钮,简化搜索");
            tools.clickText("搜", { limit_x: [0.35, 0.65], limit_y: [0.11, 0.9], continueOnError: true });
        }
        //增加下一级页面校验容错，避免跳转不了
        var checkResult = tools.findText("问AI", { limit_x: [0.7, 1], timeout: 5000 });
        if (checkResult == null) {
            console.log("没有找到问AI按钮,继续尝试点击AI搜索");
            tools.clickText("索", { limit_x: [0.35, 0.65], limit_y: [0.11, 0.9] });
        }

        filteredQuestions.forEach(question => {
            tools.clickText("出你的", { continueOnError: true, timeout: 2000 });
            tools.inputText("出你的", question, { showDetailLog: true, tryPos: [0.3, 0.2], continueOnError: true, });
            var inPasteSuccess = tools.findText(preStr, { continueOnError: true, timeout: 2000, limit_y: [0, 0.3] });
            console.log("校验是否复制成功", inPasteSuccess);
            var i = 0;
            while (inPasteSuccess == null && i < 4) {
                console.log("尝试粘贴问题");
                tools.inputText("出你的", question, { showDetailLog: true, tryPos: [0.3, 0.2] });
                inPasteSuccess = tools.findText(preStr, { continueOnError: true, timeout: 2000, limit_y: [0, 0.3] });
                if (inPasteSuccess) {
                    break;
                }
                i++;
                sleep(1000);
            }

            tools.clickText("问AI");
            var checkTimes = 0;
            console.log("等待回答完成...");
            //循环等待直到回答完毕
            while (tools.findText("继续提问", { limit_y: [0.8, 1], timeout: 2000, continueOnError: true }) != null
                || tools.findText("问AI", { limit_y: [0.8, 1], timeout: 2000, continueOnError: true }) != null
                || checkTimes++ > 30) {
                break;
            }
            console.log(`开始滚动收集回答,已检测测试:${checkTimes}`);
            var uniqueNodes = new Set();
            var uniqueNodeKeys = new Set();
            tools.scrollUntilFindText("重答", {
                max_scroll_times: 100,
                onScroll: ({ currentScroll, maxScrollTimes }) => {
                    console.log(`-----已完成 ${currentScroll} 次滚动（共尝试 ${maxScrollTimes} 次）`);
                    var nodes = tools.getAllHasTextNodes({ limit_y: [0.1, 0.9] });
                    nodes.forEach(node => {
                        var key = `${node.node.hashCode()}`;
                        if (!uniqueNodeKeys.has(key)) {
                            uniqueNodes.add(node);
                            uniqueNodeKeys.add(key);
                        }
                    });
                }
            });
            var currentTime = new Date().toLocaleString();
            // 创建要写入的内容
            var content = `\n\n=== 问题：${question} ===\n获取时间：[${currentTime}]\n\n`;
            let lastTop = -1;
            uniqueNodes.forEach(node => {
                //获取最新的文本
                node.label = node.node.text() || node.node.contentDescription();
                console.log(`${node.label}`);
                console.log("node---------------->>>>", node);
                let rect = new android.graphics.Rect();
                node.node.getBoundsInScreen(rect);
                //y坐标相同，说明在同一行
                if (rect.top === lastTop) {
                    content += node.label
                } else {
                    content += node.label + "\n";
                }
                lastTop = rect.top;
            });

            content += "\n";  // 添加空行分隔不同问题

            try {
                // 追加写入文件
                files.append(outputFilePath, content);
                console.log(`已保存回答到：${outputFilePath}`);
            } catch (e) {
                console.error("文件写入失败：", e);
            }
            back();
        }
        );
        let hasSuccessQuestions = getSuccessQuestions();
        var successCount = hasSuccessQuestions.size();
        var msg = `所有问题已处理完毕,累计成功处理 ${successCount} 个问题，请点击case_share_wechat_ask_ai_result任务分享结果`
        toast(msg);
        tools.sendToBot(msg);
        sleep(2000);
        exit();
    } catch (e) {
        console.log("出现异常,继续重试中", e);
    }
}

if (retryCount >= 5) {
    tools.sendToBot(`❌ 问ai 任务执行异常, 重试次数超过${retryCount}次，退出,请稍后继续点击case_wechat_ask_ai任务重试`);
    console.log("重试次数超过5次，退出");
    exit();
}


//---------------------------------以下为工具函数---------------------------------

// 新增文件读取函数（需放置在脚本开头）
function readQuestionsFromFile() {
    const filePath = files.join(engines.myEngine().cwd(), "./config/ai_questions.txt");
    console.log("📂 问题文件路径:", filePath);

    try {
        if (!files.exists(filePath)) {
            console.error("问题文件不存在，将使用内置问题");
            return [];
        }

        const content = files.read(filePath)
            .split("\n")
            .filter(line => {
                // 过滤注释和空行（支持#开头的注释）
                const trimmed = line.trim();
                return trimmed && !trimmed.startsWith("#");
            })
            .map(line => `${preStr}${line.trim()}`);

        console.log("📝 从文件读取到", content.length, "个有效问题");
        return content;
    } catch (e) {
        console.error("文件读取失败:", e);
        return [];
    }
}


function getSuccessQuestions() {
    const processed = new Set();
    try {
        if (files.exists(outputFilePath)) {
            const content = files.read(outputFilePath);
            // 使用正则匹配已处理问题 [2,6](@ref)
            const regex = /^=== 问题：(.*?) ===/gm;
            let match;
            while ((match = regex.exec(content)) !== null) {
                var question = match[1].trim();
                processed.add(question);
                console.log(`已处理过的问题：${question}`);
            }
        }
    } catch (e) {
        console.error("读取历史文件失败，将处理所有问题", e);
    }
    return processed;
}


function getNeedRunQuestion() {
    // 写入前创建父目录
    files.ensureDir(outputFilePath);
    // 修改原questions定义部分
    let questions = readQuestionsFromFile();
    if (questions.length === 0) {
        var msg = "没有读取到有效问题，请检查配置文件";
        console.log(msg);
        toast(msg);
        exit();
    }
    // 过滤已处理问题
    let hasSuccessQuestions = getSuccessQuestions();
    let filteredQuestions = questions.filter(q => !hasSuccessQuestions.has(q));


    if (filteredQuestions.length === 0) {
        var msg = `所有问题已处理完毕,累计成功处理 ${hasSuccessQuestions.size} 个问题，请点击case_share_wechat_ask_ai_result任务分享结果`
        console.log(msg);
        toast(msg);
        tools.sendToBot(msg);
        exit();
    }
    return filteredQuestions;
}





