
// 导入 Tool 类 
var tools = require('./core_api.js');
try {
    const preStr = "穿越火线手游";
    const outputFilePath = context.getFilesDir() + "/ai_responses.txt";
    // 写入前创建父目录
    files.ensureDir(outputFilePath);

    // 修改原questions定义部分
    var questions = readQuestionsFromFile();
    if (questions.length === 0) {
        var msg = "没有读取到有效问题，请检查配置文件";
        console.log(msg);
        toast(msg);
        exit();
    }
    // 过滤已处理问题
    const processed = getProcessedQuestions();
    const filteredQuestions = questions.filter(q => !processed.has(q));


    if (filteredQuestions.length === 0) {
        var msg = "所有问题都已处理，无需再次处理";
        console.log(msg);
        toast(msg);
        exit();
    }

    console.log("待处理问题:", filteredQuestions);
    auto.waitFor()
    requestScreenCapture();
    app.launchApp("微信");
    sleep(2000)
    tools.clickText("微信", { limit_x: [0, 0.5], limit_y: [0.5, 1], continueOnError: true, timeout: 3000 });
    var i = 0;
    var launchSuccess = false;
    //回退到首页
    while (i < 10) {
        var current = currentActivity();
        console.log("当前页面: " + current);
        if (tools.findText("通讯录", { limit_x: [0, 0.5], limit_y: [0.8, 1], continueOnError: true, timeout: 2000 })) {
            launchSuccess = true;
            console.log("启动微信成功");
            break;
        }
        i++;
        sleep(1000);
        back();
    }

    if (!launchSuccess) {
        console.log("启动微信失败");
        throw new Error("启动微信失败");
    }



    let imgPrivateChat = images.read('./img/search.png');
    console.log("===========目标图标", imgPrivateChat)
    var isSuccess = tools.clickImage("./img/search.png",
        {
            limit_x: [0.7, 0.9], limit_y: [0, 0.1],
            continueOnError: true, timeout: 5000
        });
    if (!isSuccess) {
        console.log("没有找到微信添加按钮,尝试节点点击");
        var node = id("meb").findOne();
        console.log("node------", node);
        click(node.bounds().centerX(), node.bounds().centerY());
    }

    tools.clickText("AI搜");


    filteredQuestions.forEach(question => {
        tools.clickText("出你的", { continueOnError: true, timeout: 2000 });
        tools.inputText("出你的", question, { showDetailLog: true, tryPos: [0.3, 0.2], continueOnError: true, });
        var inPasteSuccess = tools.findText(preStr, { continueOnError: true, timeout: 2000, limit_y: [0, 0.3] });
        console.log("inPasteSuccess", inPasteSuccess);
        var i = 0;
        while (inPasteSuccess == null && i < 4) {
            console.log("尝试粘贴问题");
            tools.inputText("出你的", question, { showDetailLog: true, tryPos: [0.3, 0.2] });
            inPasteSuccess = tools.findText(preStr, { continueOnError: true, timeout: 2000, limit_y: [0, 0.3] });
            if (inPasteSuccess) {
                break;
            }
            i++;
            sleep(1000);
        }

        tools.clickText("问AI");
        sleep(7000);
        var uniqueNodes = new Set();
        var uniqueNodeKeys = new Set();
        tools.scrollUntilFindText("重答", {
            max_scroll_times: 100,
            onScroll: ({ currentScroll, maxScrollTimes }) => {
                console.log(`-----已完成 ${currentScroll} 次滚动（共尝试 ${maxScrollTimes} 次）`);
                var nodes = tools.getAllHasTextNodes({ limit_y: [0.1, 0.9] });
                nodes.forEach(node => {
                    var key = `${node.node.hashCode()}_${node.label}`;
                    if (!uniqueNodeKeys.has(key)) {
                        uniqueNodes.add(node);
                        uniqueNodeKeys.add(key);
                    }
                });
            }
        });

        // 创建要写入的内容
        var content = `=== 问题：${question} ===\n`;
        uniqueNodes.forEach(node => {
            console.log(`${node.label}`);
            console.log("node---------------->>>>", node);
            content += node.label + "\n";  // 将每个label添加到内容中
        });
        content += "\n";  // 添加空行分隔不同问题

        try {
            // 追加写入文件
            files.append(outputFilePath, content);
            console.log(`已保存回答到：${outputFilePath}`);
        } catch (e) {
            console.error("文件写入失败：", e);
        }
        back();
    }
    );
    toast("所有问题已处理完毕");
    sleep(2000);
} catch (e) {
    console.log("出现异常", e);
    toast("出现异常，继续任务请重试");
}






// 新增文件读取函数（需放置在脚本开头）
function readQuestionsFromFile() {
    const filePath = files.join(engines.myEngine().cwd(), "./config/ai_questions.txt");
    console.log("📂 问题文件路径:", filePath);

    try {
        if (!files.exists(filePath)) {
            console.error("问题文件不存在，将使用内置问题");
            return [];
        }

        const content = files.read(filePath)
            .split("\n")
            .filter(line => {
                // 过滤注释和空行（支持#开头的注释）
                const trimmed = line.trim();
                return trimmed && !trimmed.startsWith("#");
            })
            .map(line => `${preStr}${line.trim()}`);

        console.log("📝 从文件读取到", content.length, "个有效问题");
        return content;
    } catch (e) {
        console.error("文件读取失败:", e);
        return [];
    }
}



function getProcessedQuestions() {
    const processed = new Set();
    try {
        if (files.exists(outputFilePath)) {
            const content = files.read(outputFilePath);
            // 使用正则匹配已处理问题 [2,6](@ref)
            const regex = /^=== 问题：(.*?) ===/gm;
            let match;
            while ((match = regex.exec(content)) !== null) {
                var question = match[1].trim();
                processed.add(question);
                console.log(`已处理过的问题：${question}`);
            }
        }
    } catch (e) {
        console.error("读取历史文件失败，将处理所有问题", e);
    }
    return processed;
}





