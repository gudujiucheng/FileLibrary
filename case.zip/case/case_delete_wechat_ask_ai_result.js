function deleteResponseFile() {
    const outputFilePath = context.getFilesDir() + "/ai_responses.txt";
    
    try {
        if(files.exists(outputFilePath)) {
            files.remove(outputFilePath);
            console.log("🗑️ 文件删除成功");
            return true;
        }
        console.log("⚠️ 文件不存在，无需删除");
        return false;
    } catch(e) {
        console.error("删除失败:", e);
        return false;
    }
}

// 调用示例
deleteResponseFile();