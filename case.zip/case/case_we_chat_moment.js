// 导入 Tool 类 
var tools = require('./Tool.js');
tools.initServiceAndTryAllowRecordScreen();
//启动企业微信
var result = app.startActivity({
    packageName: "com.tencent.mulapp",
    className: "com.tencent.da.AdbCommandActivity",
    extras: {
        cmd: "start",
        userId: "1",
        packageName: "com.tencent.wework",
        activityName: "com.tencent.wework.launch.LaunchSplashActivity"
    }
});
console.log("启动结果-----------------",result)
sleep(5000);
tools.clickText("工作台");
tools.clickText("客户朋友圈");
tools.clickText("去发表");
// tools.clickText("发表",{limit_x: [0.7, 1]});//是否需要限制坐标
console.log("执行成功")