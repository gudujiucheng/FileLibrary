// 导入核心类 
var core = require('./core_api.js');
// 定义任务
const wechatTask = core.task({
    packageName: "com.tencent.wework",//要启动的应用包名
    activityName: "com.tencent.wework.launch.LaunchSplashActivity",//要启动的应用Activity
    totalUsers: 3,//启动用户数
    maxRetries: 2//最大重试次数
});

wechatTask.execute(function (userId) {
    // 业务逻辑
    core.clickText("工作台");
    core.clickText("客户朋友圈");
    core.clickText("去发表");
});