// 导入核心类 
var core = require('./core_api.js');
const wechatTask = core.task({
    packageName: "com.tencent.wework",
    activityName: "com.tencent.wework.launch.LaunchSplashActivity",
    targetPages: ["WwMainActivity"], // 可选，用于校验app是否正常启动
    targetTexts: ["工作台"],//可选，用于校验app是否正常启动
    unLoginPages: ["LoginWxAuthActivity", "PrivatePolicyDialog"], //可选，用于校验app是否正常启动
    unLoginTexts: ["已阅读并同意", "手机号登录", "微信登录", "隐私保护指引"], //可选，用于校验app是否正常启动
    maxRetries: 1//失败重试次数
});

//发朋友圈
wechatTask.execute(function (userId, userStat) {
    let mineResult = core.clickText("我", {limit_x: [0.8, 1], limit_y: [0.9, 1], continueOnError: true, timeout: 2000});
    if (mineResult) {
        let nameResult = core.getAllHasTextNodes({limit_y: [0.2, 0.3]})
        if (nameResult.length === 0) {
            console.log("没有找到昵称文本");
        } else {
            let nickItem = null;
            nameResult.forEach(item => {
                    if (nickItem == null) {
                        nickItem = item;
                    } else {
                        //避免扫描到对外名片文字
                        nickItem = (!item.label.toString().includes('对外名片') && item.centerY > nickItem.centerY) ? item : nickItem;
                    }

                }
            );
            console.log("目标昵称：" + nickItem.label);
            userStat.otherInfo.set("name", nickItem?.label || "default");
        }

    } else {
        console.log("没有找到'我'按钮,尝试滑动侧边栏获取用户信息");
        // 业务逻辑步骤
        core.scrollRight({eachDistance: 1, duration: 300, scrollStartPos: [0.1, 0.5]});
        //获取文本 node方式，如果满足不了可结合OCR方式
        let nameResult = core.getAllHasTextNodes({limit_y: [0.06, 0.16], limit_x: [0.1, 0.8]})
        if (nameResult.length === 0) {
            console.log("没有找到昵称文本");
        } else {
            let nickItem = null;
            nameResult.forEach(item => {
                    if (nickItem == null) {
                        nickItem = item;
                    } else {
                        nickItem = item.centerY < nickItem.centerY ? item : nickItem;
                    }

                }
            );

            console.log("目标昵称：" + nickItem.label);
            userStat.otherInfo.set("name", nickItem?.label || "default");
        }
        core.scrollLeft({eachDistance: 1, duration: 300, scrollStartPos: [0.9, 0.5]});
    }


    core.clickText("工作台");
    core.clickText("客户朋友圈");
    let findSubmitResult = core.clickText("去发表", {continueOnError: true});
    //针对有个人主页，且没有去发表按钮的情况，进行正常终止（这种属于类型2的企微）
    if (mineResult && !findSubmitResult) {
        console.log("没有找到'去发表'按钮,中断流程");
        userStat.noTarget = true;
        userStat.success = true;
        return;

    }
    let dateStr = core.getFormattedDate();
    // dateStr = "03月14日";
    let result = core.findAllByTexts(dateStr);
    if (result.length > 0) {
        let maxY = 0;
        result.forEach(item => {
            item.relative.y > maxY ? maxY = item.relative.y : null;
        });
        if (maxY <= 0) {
            throw new Error(`${dateStr}日期 异常纵坐标:${maxY}`);
        }
        let submits = core.findAllByTexts("发表", {limit_y: [0, maxY], limit_x: [0.7, 1], continueOnError: true});
        if (submits.length > 0) {
            submits.forEach(submit => {
                console.log("找到的发表按钮", submit.relative);
                click(submit.centerX, submit.centerY);
                sleep(20000);
            });
        } else {
            throw new Error("没有找到'发表'按钮");
        }

    } else {

        userStat.description = `没有找到${dateStr}节点`;
        console.log(`${userStat.description}`);
        //没有命中目标（不属于失败，比如没有需要发布的朋友圈情况）
        userStat.noTarget = true;
        userStat.success = true;
        return;
    }
    userStat.success = true;
    userStat.description = `执行成功,发布了${result.length}条数据`;
    console.log(`${userStat.description}`);
});

