// 导入 Tool 类 
var tools = require('./core_api.js');
tools.initServiceAndTryAllowRecordScreen();
app.launchApp("小红书");
tools.clickText("我",{limit_y: [0.9, 1],});
tools.clickText("关注",{limit_y: [0.2, 0.4],limit_x: [0, 0.15],});
tools.clickText("面包人");
tools.clickText("发私信");
tools.inputText("发消息","你好呀！");

