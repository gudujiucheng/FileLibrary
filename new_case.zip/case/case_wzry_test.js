requestScreenCapture();
app.launchApp("王者荣耀"); // 启动王者荣耀游戏
const core = require('./api/core_api.js');
auto.waitFor();
core.findAnyTargetText(["开始游戏", "换区", "始游戏"], {
    limit_x: [0.3, 0.7],
    limit_y: [0.5, 0.9],
    timeout: 20000,
    continueOnError: true,
    showDetailLog: true,
    isFindByNode: false
})
// 尝试更大的查找区域和更长的超时时间
core.clickAnyTargetText(["开始游戏", "开始游", "始游戏"], {
    limit_x: [0.3, 0.7],
    limit_y: [0.5, 0.9],
    timeout: 30000,
    showDetailLog: true,
    isFindByNode: false
})
sleep(1000)
//消失广告弹窗
back();
sleep(1000)
core.clickAnyImage(["./img/wzry_close_ad.png", "./img/wzry_close_ad_small.png", "./img/wzry_close_ad_mid.png"], {
    timeout: 5000, continueOnError: true
});

core.clickAnyTargetText(["取消"], {
    timeout: 2000,
    continueOnError: true,
    isFindByNode: false
})
//点击联系人
core.clickAnyImage(["./img/constants.png", "./img/constants_little.png"], {
    limit_x: [0.7, 0.9], limit_y: [0.03, 0.1], timeout: 5000
});

core.clickAnyTargetText(["找朋友", "找朋", "朋友"], { limit_x: [0, 0.2], limit_y: [0.4, 0.9], isFindByNode: false });

core.clickAnyTargetText(["请输入您要查找的玩家名", "请输入", "的玩家名", "找的玩"], { limit_x: [0.5, 1], limit_y: [0, 0.4], isFindByNode: false });
keyword = "哈哈哈"
setClip(keyword);
print("执行长按操作");
core.longPress(0.5, 0.95, 2000);
core.clickPasteText({ timeout: 4000 });
core.clickAnyTargetText("确定", { limit_x: [0.85, 1], limit_y: [0.8, 1] });
// result = core.clickAnyTargetText(["搜索", "搜", "索"], { limit_x: [0.7, 1], limit_y: [0.2, 0.4], isFindByNode: false, showDetailLog: true, continueOnError: true });
// if (result) {
//     console.log("点击搜索成功")
// } else {
//     console.log("点击搜索失败，尝试通过其他文字定位点击")
    core.clickAnyTargetText(["重置", "重", "置"],
        {
            limit_x: [0.7, 1], limit_y: [0.2, 0.4],
            offset: [0, 0.1],  // [x偏移, y偏移]
            isFindByNode: false,
            showDetailLog: true
        });
// }

core.clickAnyTargetText([keyword],
    {
        limit_x: [0, 0.5], limit_y: [0.4, 1], isFindByNode: false,
        showDetailLog: true, continueOnError: true
    });

core.scrollUntilFindAnyTargetText(["主页", "主", "页"], {
    limit_x: [0, 0.2], limit_y: [0.1, 0.3], isFindByNode: false,
    direction: core.DirectionType.DOWN,
    scroll_start_pos: [0.07, 0.5],
});

core.clickAnyTargetText(["主页", "主", "页"], { limit_x: [0, 0.2], limit_y: [0.1, 0.3], isFindByNode: false });
texts = core.getAllTextsByOcr()
console.log("texts", texts)

// 显示OCR结果弹窗
console.log("显示OCR识别结果弹窗...");
core.showOcrResultsDialog(texts);


// core.inputText(["输入关键字进行搜索", "关键字", "输入关键", "进行"], "哈哈哈", {limit_x: [0.6, 1], limit_y: [0, 0.3]});
// core.clickText("搜索", {limit_x: [0.85, 1], limit_y: [0, 0.3]});