// 导入 Tool 类
var core = require('./api/core_api.js');


// 抓取年份
const publishYear = 2025;

// KOL内容处理配置
const kolContentConfig = {
    "王者峡谷挖掘机": ["posts"],
    "王者好物": ["news"],
    "老刘备": ["news"],
    "极光AuR": ["news"],
    "娜娜": ["news"],
    "指尖上的王者": ["news"],
    "可儿游戏说": ["news"],           // 只处理帖子
    "张大仙": ["news"],           // 只处理资讯
    "两袖空空R": ["news"],  
    "王者荣耀": ["news"],
    // 可以继续添加更多KOL配置
};

auto.waitFor();
requestScreenCapture();

// 添加文件路径常量
const listOutputDirPath = context.cacheDir + "/list";
const processedKolFilePath = context.cacheDir + "/kolnames.txt";

// --- 日志模块 ---
const logDirPath = files.join(context.cacheDir, "logs");

function _getLogFilePath() {
    let date = new Date();
    let year = date.getFullYear().toString();
    let month = (date.getMonth() + 1).toString().padStart(2, '0');
    let day = date.getDate().toString().padStart(2, '0');
    return files.join(logDirPath, `${year}${month}${day}.log`);
}

function _appendToLog(level, args) {
    try {
        const logPath = _getLogFilePath();
        files.ensureDir(logDirPath);
        const timestamp = new Date().toLocaleString('sv'); // YYYY-MM-DD HH:mm:ss
        // 将所有参数拼接成一个字符串
        const message = Array.prototype.slice.call(args).map(String).join(' ');
        const logEntry = `[${timestamp}] [${level}] ${message}\n`;
        files.append(logPath, logEntry);
    } catch(e) {
        // 如果日志系统本身失败，使用原始console打印，避免无限循环
        console.error("写入日志文件失败: ", e);
    }
}

function logInfo() {
    console.log.apply(console, arguments);
    _appendToLog('INFO', arguments);
}

function logError() {
    console.error.apply(console, arguments);
    _appendToLog('ERROR', arguments);
}
// --- 日志模块结束 ---


// --- 全局变量 ---
var db = null;


// --- 初始化函数 ---

/**
 * @description 创建一个目录，如果它不存在的话。
 * @param {string} path - 要创建的目录路径。
 */
function ensureDirExists(path) {
    try {
        let dir = new java.io.File(path);
        if (!dir.exists()) {
            let success = dir.mkdirs();
            if (success) {
                // 首次创建目录时，使用console.log避免循环调用日志
                console.log(`目录创建成功: ${path}`);
            } else {
                console.error(`目录创建失败: ${path}`);
            }
        }
    } catch (e) {
        console.error(`创建目录出错: ${path}`, e);
    }
}

/**
 * @description 执行脚本的所有初始化操作，包括创建目录、设置数据库和迁移旧数据。
 */
function initializeScript() {
    logInfo("--- 开始初始化脚本 ---");

    // 1. 确保所有需要的目录都存在
    ensureDirExists(logDirPath);
    ensureDirExists(listOutputDirPath);

    // 2. 初始化数据库
    const dbPath = context.cacheDir + "/processed_titles.db";
    db = sqlite.open(dbPath);
    db.execSQL("CREATE TABLE IF NOT EXISTS processed_titles (id INTEGER PRIMARY KEY AUTOINCREMENT, kol_name TEXT, section_type TEXT, title TEXT, UNIQUE(kol_name, section_type, title));");
    logInfo("数据库初始化完成。");

    // 3. 迁移旧的.txt标题文件到数据库
    // migrateTxtTitlesToDb();

    logInfo("--- 初始化完成 ---");
}


/**
 * @description 检查指定的标题是否已经在数据库中存在
 * @param {string} kolName - KOL的名称
 * @param {string} title - 文章标题
 * @param {string} sectionType - 内容类型 ('posts' 或 'news')
 * @returns {boolean} - 如果存在则返回true，否则返回false
 */
function isTitleProcessed(kolName, title, sectionType) {
    if (!title || !kolName || !sectionType) {
        return false;
    }
    let cursor = db.rawQuery("SELECT id FROM processed_titles WHERE kol_name = ? AND title = ? AND section_type = ?", [kolName, title, sectionType]);
    let exists = cursor.moveToFirst();
    cursor.close();
    return exists;
}

/**
 * @description 将新处理的标题添加到数据库中
 * @param {string} kolName - KOL的名称
 * @param {string} title - 文章标题
 * @param {string} sectionType - 内容类型 ('posts' 或 'news')
 */
function addProcessedTitle(kolName, title, sectionType) {
    if (!title || !kolName || !sectionType) {
        return;
    }
    try {
        // 使用 INSERT OR IGNORE 语句，如果记录已存在（基于UNIQUE约束），则静默忽略
        db.execSQL("INSERT OR IGNORE INTO processed_titles (kol_name, section_type, title) VALUES (?, ?, ?)", [kolName, sectionType, title]);
        logInfo(`[DB] 已将标题存入数据库: -- ${kolName} (${sectionType}) --: ${title}`);
    } catch (e) {
        logError(`[DB] 数据库插入失败: -- ${kolName} (${sectionType}) --: ${title}`, e);
    }
}

/**
 * @description 将 list 目录下所有符合 {kol}_{sectionType}.txt 格式的旧版标题文件迁移到数据库中。
 *              为了防止重复迁移，成功处理后的文件会被重命名为 .migrated 后缀。
 */
function migrateTxtTitlesToDb() {
    logInfo("--- 开始扫描并迁移旧版 .txt 标题文件到数据库 ---");
    let totalMigratedCount = 0;
    let totalFilesCount = 0;
    try {
        let allFiles = files.listDir(listOutputDirPath);
        logInfo(`allFiles: ${allFiles.length}`);

        for (let fileName of allFiles) {
            if (!fileName.endsWith(".txt")) {
                logInfo(`不是标题文件: ${fileName}，跳过`);
                continue;
            }

            totalFilesCount++;
            let nameInfos = fileName.replace(".txt", "").split("_");
            let kolName = nameInfos[0];
            let sectionType = nameInfos.length > 1 ? nameInfos[1].toLowerCase() : "news";
            let filePath = files.join(listOutputDirPath, fileName);
                
            logInfo(`正在处理文件: ${filePath}`);

            // 读取文件中的所有标题
            let titles = files.read(filePath).split('\n');
            let migratedCount = 0;

            // 遍历每一个标题并写入数据库
            for (let title of titles) {
                if (title.length > 0) { // 确保标题不为空
                    addProcessedTitle(kolName, title, sectionType);
                    migratedCount++;
                }
            }

            logInfo(`从 ${fileName} 成功迁移了 ${migratedCount}/${titles.length} 个标题。`);
            totalMigratedCount += migratedCount;
            // 迁移完成后，重命名文件以防止重复处理
            try {
                let result = files.rename(filePath, filePath + ".migrated");
                logInfo(`已将 ${fileName} 重命名为 ${fileName}.migrated, result: ${result}`);
            } catch (renameError) {
                logError(`重命名文件失败: ${fileName}`, renameError);
            }
        }        
    } catch (e) {
        logError("迁移 .txt 标题文件时发生错误: ", e);
    }

    logInfo(`共处理了 ${totalFilesCount} 个文件。`);
    logInfo(`共迁移了 ${totalMigratedCount} 个标题。`);
    logInfo("--- 标题文件迁移检查完成 ---");
}

// 获取当前日期，格式为YYYYMMDD
function getDateString() {
    let date = new Date();
    let year = date.getFullYear().toString();
    let month = (date.getMonth() + 1).toString().padStart(2, '0');
    let day = date.getDate().toString().padStart(2, '0');
    return year + month + day;
}

// 保存JSON内容
function saveJsonContent(kolName, contentItem, sectionType) {
    try {
        // 构建文件名：KOL名称_内容类型_YYYYMMDD.json
        const fileName = `${kolName}_${sectionType}_${getDateString()}.json`;
        const filePath = files.join(listOutputDirPath, fileName);
        
        // 确保目录存在
        ensureDirExists(listOutputDirPath);
        
        // 读取现有内容（如果存在）
        let existingContent = [];
        if (files.exists(filePath)) {
            try {
                let fileContent = files.read(filePath);
                if (fileContent && fileContent.trim()) {
                    existingContent = JSON.parse(fileContent);
                }
            } catch (e) {
                logInfo(`读取现有JSON文件失败：${filePath}`);
                logError("error:", e);
            }
        }
        
        // 添加新内容
        existingContent.push(contentItem);
        
        // 保存JSON文件
        let jsonString = JSON.stringify(existingContent, null, 2);
        files.write(filePath, jsonString);
        logInfo(`已保存帖子JSON内容到：${filePath}`);
    } catch (e) {
        logError(`KOL：${kolName} sectionType：${sectionType} 帖子JSON处理失败：`, e);
    }
}

// 应用启动和导航相关函数
function launchWzry() {
    launch("com.tencent.gamehelper.smoba");
    sleep(2000);
}

function checkMainPage() {
    let i = 0;
    while (i < 10) {
        var current = currentActivity();
        logInfo("当前页面: " + current);
        let target = core.findAnyTargetText(["首页", "聊天", "社区", "我"], {
            limit_y: [0.8, 1], continueOnError: true, timeout: 2000,
        });
        if (target != null && target.length > 0) {
            logInfo("启动王者营地成功");
            return true;
        }
        i++;
        sleep(1000);
        back();
    }
    logError("启动王者营地失败");
    throw new Error("启动王者营地失败");
}

function navigateToFollowingList() {
    // 点击"我"标签
    core.clickText("我", {
        limit_y: [0.8, 1], timeout: 2000,
    });

    // 点击"关注"按钮
    core.clickText("关注", {
        limit_y: [0.2, 0.4], timeout: 2000,
    });
}

// 页面检查和返回相关函数
function checkAndReturnToFollowingListPage() {
    let retryCount = 0;
    while (retryCount < 3) {
        let pages = core.findAnyTargetText(["权限设置", "所有关注", "权限设", "互相关注"], {
            limit_y: [0, 0.2], timeout: 2000, continueOnError: true
        });
        if (pages && pages.length > 0) {
            logInfo(`页面正确，无需回退`);
            return true;
        }
        logInfo(`尝试回退到上一级页面 (第${retryCount + 1}次尝试)`);
        back();
        sleep(2000);
        retryCount++;
    }
    return false;
}

function checkAndReturnToUserMainPage() {
    let retryCount = 0;
    while (retryCount < 3) {
        let pages = core.findAnyTargetText(["她的发布", "她的订阅", "他的发布", "他的订阅", "的发布"], {
            continueOnError: true, timeout: 2000,
        });
        if (pages && pages.length > 0) {
            logInfo(`checkAndReturnToUserMainPage 页面正确，无需回退`);
            return true;
        }
        logInfo(`checkAndReturnToUserMainPage 尝试回退到上一级页面 (第${retryCount + 1}次尝试)`);
        back();
        sleep(2000);
        retryCount++;
    }
    return false;
}

function getTitleFromNode(nodeLabel, sectionType) {
    if (!nodeLabel) {
        return "";
    }
    let title = nodeLabel.toString();
    if (sectionType === "posts") {
        title = title.split(" ")[0];
    }
    return title;
}

// 内容处理相关函数
function associateTargetWithTextNode(target, textNodes) {
    let filteredNodes = textNodes.filter(node => node.label !== "已关注");
    let nodeDiffs = filteredNodes.map(node => ({
        node: node,
        diff: Math.abs(node.relative.y - target.relative.y)
    }));
    nodeDiffs.sort((a, b) => a.diff - b.diff);
    return nodeDiffs.length > 0 && nodeDiffs[0].diff < 0.05 ? nodeDiffs[0].node : null;
}

function collectContentFromPage(associatedNode) {
    let allContent = "";
    // let currentTime = new Date().toLocaleString();
    // allContent = `\n本篇获取时间：[${currentTime}]\n`;
    let lastTop = -1;

    core.scrollUntilFindAnyTargetText(
        ["条评论", "按热度", "按时间"],
        { continueOnError: true, timeout: 5000, max_scroll_times: 20 }
    );

    let webNode = className("android.webkit.WebView").findOne();
    let allChildren = (webNode != null) ? core.getAllChildren(webNode) : core.getAllHasTextNodes();
    

    if (!allChildren || allChildren.length === 0) {
        return allContent + "未成功获取文章内容";
    }

    // 按y坐标排序
    // 按y坐标排序
    allChildren.sort((a, b) => {
        if (!a || !b) return 0;
        let rectA = new android.graphics.Rect();
        let rectB = new android.graphics.Rect();
        a.getBoundsInScreen(rectA);
        b.getBoundsInScreen(rectB);
        return rectA.top - rectB.top;
    });

    for (let i = 0; i < allChildren.length; i++) {
        let node = allChildren[i];
        if (node != null) {
            // console.log(`node: ${node.getClassName()}`);
            let text = node.getText() || node.getContentDescription();
            if (text && text.toString().includes("条评论")) {
                break;
            }
            if (text && text.toString().trim().length != 0 && node.getClassName() != "android.widget.Image") {
                let rect = new android.graphics.Rect();
                node.getBoundsInScreen(rect);
                allContent += (rect.top == lastTop) ? text : text + "\n";
                lastTop = rect.top;
            }
        }
    }

    return allContent;
}

function processContentSection(sectionType, viewId, offsetX, associatedNode, processedLabels, kolName) {
    let isSectionExists = core.clickByViewId(viewId, {
        limit_x: sectionType === "posts" ? [0.25, 0.6] : [0.5, 1],
        continueOnError: true,
        timeout: 1000
    });

    if (!isSectionExists) return;

    sleep(2000);

    let isEmpty = core.findAnyTargetText(["召唤师还没有发布内容", "还没有发布内容", "还没有发"], {
        limit_x: [0.2, 0.9],
        continueOnError: true
    });

    if (isEmpty && isEmpty.length > 0) {
        logInfo(`=== 用户：${kolName} === 没有发布过${sectionType === "posts" ? "帖子" : "资讯"}`);
        return;
    }

    let scrollDistance = 0.9;
    let startY = 0.88;

    // 用于存储已处理的标题
    let processedTitles = new Set();
    // 用于存储标题和发布时间的映射
    let titleTimeMap = new Map();
    // 标记是否发现底部
    let foundBottom = false;
    // 用于记录当前处理的序号
    let currentIndex = 1;
    // 增量抓取停止标记
    let incrementalStop = false;
    // 用于处理单次运行中（滚动时）的页面内重复，避免重复抓取
    let processedTitlesInRun = new Set(); 

    // 按kol名称读取保存的标题列表
    let titleListPath = listOutputDirPath + "/" + kolName + "_" + sectionType + ".txt";
    let titleList = "";
    if (files.exists(titleListPath)) {
        titleList = files.read(titleListPath);
    }
    if (titleList) {
        processedTitles = new Set(titleList.split("\n"));
    }
    logInfo(`processedTitles from file: ${processedTitles.size}`);

    logInfo(`=== 用户：${kolName} === 获取开始`);

    // 超时日期标记，用来结束循环
    let hasTimeoutDate = false;

    while (true) {
        // 获取当前页面的所有节点
        let nodes = core.getAllNodesByViewId(
            sectionType === "posts" ? "text_content" : "info_title",
            { limit_x: sectionType === "posts" ? [0, 1] : [0, 0.8], limit_y: [0, 0.85] }
        );

        // 将nodes按y坐标排序，y坐标越小越靠上
        nodes.sort((a, b) => a.relative.y - b.relative.y);

        let timeNodes = core.getAllNodesByViewId(sectionType === "posts" ? "desc" : "time_stamp", { continueOnError: true, timeout: 2000 })
        logInfo(`timeNodes: ${timeNodes.length}，nodes: ${nodes.length}`);

        // 每次循环开始时，重置超时日期标记
        hasTimeoutDate = false;

        for (let node of nodes) {
            // 从已获取的timeNodes中查找最接近的时间节点
            let publishTime = "";
            if (timeNodes.length > 0) {
                // 取y坐标最接近的时间节点
                timeNodes.sort((a, b) => Math.abs(a.relative.y - node.relative.y) - Math.abs(b.relative.y - node.relative.y));
                publishTime = timeNodes[0].label || "";
            }
            let title = getTitleFromNode(node.label, sectionType);
            logInfo(`找到发布时间: ${publishTime} - ${title}`);
            if (publishTime && title) {
                titleTimeMap.set(title, publishTime);
            }
        }

        if (nodes.length > 0) {
            // 去重处理
            let uniqueNodes = [];
            
            for (let node of nodes) {
                let title = getTitleFromNode(node.label, sectionType);
                if (!title) {
                    continue; // 跳过无效标题的节点
                }

                // --- 重构后的增量更新核心逻辑 ---

                // 步骤1：检查这个标题是否是本轮运行中已经处理过的
                // (例如，在上一屏的底部看到，滚动后又在这一屏的顶部看到)
                if (processedTitlesInRun.has(title)) {
                    logInfo(`[本轮已处理] 跳过: "${title}"`);
                    continue;
                }

                // 步骤2：如果不是本轮处理过的，再检查它是否是数据库里早就存在的旧数据
                // 如果是，说明我们已经抓取到了和上次的交界处，可以停止了
                if (isTitleProcessed(kolName, title, sectionType)) {
                    logInfo(`[发现旧数据] 增量更新停止抓取新文章: "${title}"`);
                    incrementalStop = true;
                    break; // 中断对当前页面节点的检查
                }

                // 步骤3：如果以上都不是，说明这是一个全新的、需要抓取的标题
                // 检查发布日期是否超时
                let publishTime = titleTimeMap.get(getTitleFromNode(node.label, sectionType)) || "";
                if (publishTime && publishTime.toString().startsWith((publishYear - 1) + "-")) {
                    hasTimeoutDate = true;
                    logInfo(`发现超时日期标记: ${publishTime}`);
                    break;
                }

                logInfo(`[发现新文章] 添加到处理列表: "${title}"`);
                processedTitlesInRun.add(title); // 记录下来，以便在后续滚动中识别
                uniqueNodes.push(node);
            }
            
            if (uniqueNodes.length === 0) {
                logInfo("当前页面所有节点都已处理过，继续滚动");
            } else {
                // 按y坐标从上到下排序
                uniqueNodes.sort((a, b) => a.relative.y - b.relative.y);
                logInfo(`找到${sectionType === "posts" ? "帖子" : "资讯"}节点,逐个处理 (共${uniqueNodes.length}个新节点)`);

                // 处理当前页面的所有节点
                for (let node of uniqueNodes) {
                    let content = tryGetPostContent(node, associatedNode, offsetX, processedLabels);
                    if (!content) {
                        content = tryGetPostContent(node, associatedNode, offsetX, processedLabels);
                        if (!content) {
                            let msg = `第${currentIndex}篇获取${sectionType === "posts" ? "帖子" : "资讯"}失败 - ${getTitleFromNode(node.label, sectionType)}`;    
                            logInfo(msg);
                        }
                    }
                    if (content) {
                        let title = getTitleFromNode(node.label, sectionType);
                        let publishTime = titleTimeMap.get(title) || "";

                        // 保存完整内容到原文件
                        let numberedContent = `第${currentIndex}篇${sectionType === "posts" ? "帖子" : "资讯"}\n${title} - ${publishTime} -: ${content.substring(0, 30)}`;
                        logInfo(numberedContent);
                        
                        // 将新标题记录到数据库
                        addProcessedTitle(kolName, title, sectionType);
                        
                        // 实时保存到JSON文件
                        if (title && kolName) {
                            let contentItem = {
                                name: kolName,
                                title: title,
                                content: content,
                                publish_time: publishTime,
                                create_time: new Date().toISOString()
                            };
                            saveJsonContent(kolName, contentItem, sectionType);
                        }
                        
                        currentIndex++;
                    }
                    checkAndReturnToUserMainPage();
                }
            }

            if (incrementalStop) {
                logInfo(`KOL [${kolName}] 的增量抓取完成，将停止。`);
                break;
            }

            if (hasTimeoutDate) {
                logInfo("已找到超时日期标记，结束循环[2]");
                break;
            }

            // 计算滑动距离
            let firstNode = nodes[0];
            let lastNode = nodes[nodes.length - 1];
            scrollDistance = Math.max((lastNode.relative.y - firstNode.relative.y), 0.6);
            startY = Math.min(Math.max(lastNode.relative.y, 0.6), 0.85);

            // 检查是否到达底部
            let findResult = core.findAnyTargetText(["没有更多了", "没有", "更多"], {
                limit_y: [0.9, 1],
                timeout: 2000,
                continueOnError: true
            });

            if (findResult && findResult.length > 0) {
                if (!foundBottom) {
                    logInfo("发现底部标记，处理完当前页面后结束循环");
                    foundBottom = true;
                } else {
                    logInfo("已处理完最后一页内容，结束循环");
                    break;
                }
            }

            // 如果已经发现底部，不再继续滚动
            if (!foundBottom) {
                // 执行滑动
                core.scrollUp({
                    eachDistance: scrollDistance,
                    scrollStartPos: [0.5, startY],
                    max_scroll_times: 1,
                    duration: 1500
                });
                // 等待页面稳定
                sleep(2000);
            }
        } else {
            logInfo(`未找到${sectionType === "posts" ? "帖子" : "资讯"}节点，尝试向上滚动一点`);
            core.scrollUp({ eachDistance: 0.2 })
        }
    }

    logInfo(`=== 用户：${kolName} === 获取结束`);
    return currentIndex - 1;
}

/**
 * @description 生成并发送一个格式化的Markdown报告给机器人。
 * @param {Map<string, {processTime: string, postCount: number, newsCount: number, totalArticles: number}>} stats - 包含KOL抓取统计数据的Map。
 * @param {number} startTime - 脚本开始执行的时间戳。
 */
function generateAndSendReport(stats, startTime) {
    let totalKols = stats.size;
    let totalArticles = 0;
    stats.forEach(stat => {
        totalArticles += stat.totalArticles;
    });

    let mdContent = `## 📖 王者营地KOL抓取报告\n\n`;
    mdContent += `**抓取KOL总数:** ${totalKols}\n`;
    mdContent += `**抓取文章总数:** ${totalArticles}\n\n`;
    
    if (totalKols > 0) {
        mdContent += `### 📊 抓取明细\n\n`;
        let index = 1;
        stats.forEach((stat, kolName) => {
            mdContent += `${index}. **KOL:** \`${kolName}\`\n`;
            mdContent += `   - **抓取:** 帖子 **${stat.postCount}** 篇, 资讯 **${stat.newsCount}** 篇\n`;
            mdContent += `   - **完成:** ${stat.processTime}\n\n`;
            index++;
        });
    }

    const duration = ((Date.now() - startTime) / 1000).toFixed(2);
    mdContent += `---\n`;
    mdContent += `**报告生成时间:** ${new Date().toLocaleString()}\n`;
    mdContent += `**累计耗时:** ${duration}秒\n`;
    
    logInfo("--- 生成报告内容 ---\n" + mdContent);
    core.sendToBot(mdContent);
}

function tryGetPostContent(targetNode, associatedNode, offsetX, processedLabels) {
    click(targetNode.centerX + offsetX * device.width, targetNode.centerY);
    sleep(2000);

    let checkPageResults = core.findAnyTargetText(["友好评论", "友好评", "友好", "好评论"], {
        continueOnError: true,
        timeout: 20000
    });

    logInfo(`checkPageResults: ${checkPageResults.length}`);

    if (checkPageResults && checkPageResults.length > 0) {
        let content = collectContentFromPage(associatedNode);
        processedLabels.set(associatedNode.label, {
            label: associatedNode.label,
            content: content,
            processTime: new Date().toLocaleString()
        });
        return content;
    }
    sleep(1000);
    return null;
}

// 主流程
function main() {
    const startTime = Date.now();
    try {
        // --- 执行初始化 ---
        initializeScript();

        launchWzry();
        checkMainPage();
        logInfo("王者营地已成功打开");

        sleep(3000);

        navigateToFollowingList();

        let scrollDistance = 0.9;
        let startY = 0.88;
        let itemRetryCount = new Map();
        let lastItemNode = null;
        let processedLabels = new Map();
        let processingStats = new Map();

        while (true) {
            let targets = core.findAllByTexts(["已关注"], {
                limit_x: [0.7, 1], timeout: 2000,
            });
            let allHasTextNodes = core.getAllHasTextNodes();

            if (targets.length === 0) break;

            targets.sort((a, b) => a.relative.y - b.relative.y);
            logInfo(`找到'已关注'按钮,逐个点击 (共${targets.length}个)`);

            let currentLastItem = targets[targets.length - 1];
            if (lastItemNode && currentLastItem && lastItemNode.equals(currentLastItem.node)) {
                logInfo("检测到最后一个节点未变化，已到达底部，结束循环");
                break;
            }
            lastItemNode = currentLastItem.node;

            for (let index = 0; index < targets.length; index++) {
                let item = targets[index];
                let associatedNode = associateTargetWithTextNode(item, allHasTextNodes);
                logInfo(`找到 KOL 信息 -: ${associatedNode.label}`);

                if (!associatedNode) {
                    logInfo(`${index} 未找到关联的文本节点，跳过处理`);
                    continue;
                }

                if (processedLabels.has(associatedNode.label)) {
                    logInfo(`${index} 跳过已处理的标签: ${associatedNode.label}`);
                    continue;
                }

                logInfo(`--------------------------------处理第 ${index + 1}/${targets.length} 个已关注按钮 (y坐标: ${item.relative.y})--------------------------------`);

                let retryCount = itemRetryCount.get(item.label) || 0;
                if (retryCount >= 1) {
                    logInfo(`按钮 ${item.label} 已重试过一次，跳过继续处理`);
                    continue;
                }

                logInfo(`关联到文本节点: ${associatedNode.label} (文本节点 y坐标: ${associatedNode.relative.y} 已关注节点y坐标:${item.relative.y})`);

                click(item.centerX - 0.4 * device.width, item.centerY);
                sleep(2000);

                // 获取KOL配置
                let contentTypes = ["posts", "news"]; // 默认都处理
                let kolName = "";
                for (let name in kolContentConfig) {
                    if (associatedNode.label.toString().indexOf(name) !== -1) {
                        contentTypes = kolContentConfig[name];
                        kolName = name;
                        logInfo(`找到KOL[${kolName}]的配置: ${contentTypes.join(", ")}`);
                        break;
                    }
                }

                // 如果KOL名称未找到，跳过
                if (!kolName || kolName.length === 0) {
                    logInfo(`========== 未找到KOL[${associatedNode.label.replace("\n", "").substring(0, 15)}]的配置，跳过 ==========`);
                    continue;
                }

                // 如果KOL名称已处理过，跳过
                if (files.exists(processedKolFilePath) && files.read(processedKolFilePath).indexOf(kolName) !== -1) {
                    logInfo(`KOL[${kolName}]已处理过，跳过`);
                    continue;
                }

                let postCount = 0;
                let newsCount = 0;

                // 根据配置处理内容
                if (contentTypes.includes("posts")) {
                    logInfo(`>>>>>>>>>>> 处理帖子`);
                    postCount = processContentSection("posts", "third_btn", 0, associatedNode, processedLabels, kolName);
                }
                if (contentTypes.includes("news")) {
                    logInfo(`>>>>>>>>>>> 处理资讯`);
                    newsCount = processContentSection("news", "fourth_btn", 0, associatedNode, processedLabels, kolName);
                }

                // 如果为该KOL抓取到了文章，则记录统计数据
                if (postCount > 0 || newsCount > 0) {
                    processingStats.set(kolName, {
                       processTime: new Date().toLocaleString(),
                       postCount: postCount,
                       newsCount: newsCount,
                       totalArticles: postCount + newsCount
                   });
               }

                // 保存已处理的KOL名称
                // saveProcessedKolName(kolName);

                checkAndReturnToFollowingListPage();
                sleep(1000);

                processedLabels.set(associatedNode.label, {
                    label: associatedNode.label,
                    y: associatedNode.relative.y,
                    processTime: new Date().toLocaleString()
                });
            }

            let firstTarget = targets[0];
            let lastTarget = targets[targets.length - 1];
            scrollDistance = (lastTarget.relative.y - firstTarget.relative.y);
            startY = Math.min(Math.max(lastTarget.relative.y, 0.6), 0.93);

            core.scrollUp({
                eachDistance: scrollDistance,
                scrollStartPos: [0.5, startY],
                max_scroll_times: 1,
                duration: 1500
            });
            sleep(2000);
        }

        logInfo(`--------------------------------处理结果统计--------------------------------`);
        logInfo(`共处理 ${processingStats.size} 个用户`);
        processingStats.forEach((value, key) => {
            logInfo(`用户: ${key}, 文章总数: ${value.totalArticles}, 处理时间: ${value.processTime}`);
        });
        
        generateAndSendReport(processingStats, startTime);

    } catch (e) {
        logError("出现异常:", e);
        core.sendToBot("王者营地：" + e.toString());
    } finally {
        // 确保数据库连接被关闭
        if (db) {
            try {
                db.close();
                logInfo("数据库连接已关闭");
            } catch (e) {
                logError("关闭数据库连接时出错：", e);
            }
        }
    }
}

// 执行主流程
main();