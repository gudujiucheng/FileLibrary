// Base utility functions
const BaseUtils = {
    // Direction type enum
    DirectionType: Object.freeze({
        UP: 1,
        DOWN: 2,
        LEFT: 3,
        RIGHT: 4
    }),

    /**
     * 统一获取屏幕尺寸的方法，处理所有旋转逻辑
     * @param {object} [options={}] - 选项
     * @param {boolean} [options.useLogicalSize=false] - 是否使用设备逻辑尺寸而非物理截图尺寸
     * @returns {{width: number, height: number, source: string}} 屏幕尺寸信息
     */
    getScreenDimensions: function(options = {}) {
        const { useLogicalSize = false } = options;
        if (useLogicalSize) {
            // 使用设备逻辑尺寸（用于UI节点坐标计算）
            const result = {
                width: device.width,
                height: device.height,
                source: "设备逻辑尺寸"
            };
            // console.log(`[屏幕尺寸] ${result.source}: 宽：${result.width}x 高:${result.height}`);
            return result;
        }

        
        // 对于物理截图尺寸，我们不在这里截图，而是基于设备方向计算预期尺寸
        // 使用官方API获取当前屏幕方向
        importClass(android.content.res.Configuration);
        const orientation = context.getResources().getConfiguration().orientation;
        const isDeviceActuallyLandscape = (orientation === Configuration.ORIENTATION_LANDSCAPE);
        
        let width = device.width;
        let height = device.height;
        
        // 根据设备方向调整尺寸（确保返回的是正确方向的尺寸）
        if (isDeviceActuallyLandscape && width < height) {
            // 横屏设备但逻辑尺寸是竖屏格式，需要交换
            [width, height] = [height, width];
        } else if (!isDeviceActuallyLandscape && width > height) {
            // 竖屏设备但逻辑尺寸是横屏格式，需要交换
            [width, height] = [height, width];
        }
        
        const finalResult = {
            width: width,
            height: height,
            source: "基于设备方向的预期尺寸"
        };
        
        console.log(`[屏幕尺寸] ${finalResult.source}: ${finalResult.width}x${finalResult.height}`);
        return finalResult;
    },

    /**
     * 获取Android系统的屏幕旋转角度
     * @returns {number} 旋转角度：0=正常竖屏, 90=向左旋转, 180=倒置, 270=向右旋转
     */
    _getSystemRotationAngle: function() {
        try {
            // 方法1：通过WindowManager获取旋转角度
            importClass(android.view.WindowManager);
            importClass(android.view.Surface);
            const windowManager = context.getSystemService(android.content.Context.WINDOW_SERVICE);
            const display = windowManager.getDefaultDisplay();
            const rotation = display.getRotation();
            
            // Surface.ROTATION_0 = 0, Surface.ROTATION_90 = 1, Surface.ROTATION_180 = 2, Surface.ROTATION_270 = 3
            const rotationMap = {
                0: 0,    // Surface.ROTATION_0 - 正常竖屏
                1: 90,   // Surface.ROTATION_90 - 向左旋转90度（逆时针）
                2: 180,  // Surface.ROTATION_180 - 倒置
                3: 270   // Surface.ROTATION_270 - 向右旋转90度（顺时针）
            };
            
            const angle = rotationMap[rotation] || 0;
            console.log(`[系统旋转] 检测到系统旋转角度: ${angle}度 (原始值: ${rotation})`);
            return angle;
            
        } catch (e) {
            console.warn(`[系统旋转] 获取系统旋转角度失败: ${e.message}，使用默认值0度`);
            return 0;
        }
    },

    // Convert dp to pixels
    dpToPx: function (dp) {
        let metrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * metrics.density);
    },

    // Convert sp to pixels
    spToPx: function (sp) {
        let metrics = context.getResources().getDisplayMetrics();
        return Math.round(sp * metrics.scaledDensity);
    },

    // Format map to string
    formatMap: function (map) {
        if (!map?.size) return "";
        const entries = Array.from(map, ([k, v]) => `${k}: ${v}`).join(' | ');
        return `\`${entries}\``;
    },

    // Get formatted date
    getFormattedDate: function () {
        const now = new Date();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        return `${month}月${day}日`;
    },

    // Query install count
    queryInstallCount: function () {
        let uri = android.net.Uri.parse("content://com.tencent.multiapp/installWWorkCount");
        let resolver = context.getContentResolver();

        try {
            let cursor = resolver.query(uri, null, null, null, null);
            if (cursor) {
                let results = [];
                let columnIndex = cursor.getColumnIndex("installWWorkCount");
                while (cursor.moveToNext()) {
                    let value = cursor.getInt(columnIndex);
                    results.push(value);
                    log("查询到安装次数:", value);
                }
                cursor.close();
                return results;
            } else {
                toast("未查询到数据");
                return [];
            }
        } catch (e) {
            console.error("查询失败:", e);
            toast("查询失败，请检查权限");
            return null;
        }
    },

    // Error handler
    _onError: function (errorMessage, options = {}) {
        const { continueOnError = false } = options;
        console.log(`-->>${errorMessage}`);
        if (!continueOnError) {
            throw new Error(`${errorMessage}`);
        }
    },

    // Wait until found with timeout
    _waitUntilFound: function (action, options) {
        const timeout = options.timeout || 10000;
        const interval = options.interval || 1000;
        const continueOnError = options.continueOnError;
        const startTime = Date.now();

        while (Date.now() - startTime < timeout) {
            var result = action();
            if (result) return result;
            sleep(interval);
        }
        const errorMsg = "操作超时 (" + timeout + "ms)";
        if (!continueOnError) throw new Error(errorMsg);
        console.warn(errorMsg);
        return null;
    },

    // 收集当前屏幕上可见的所有节点
    collectAllVisibleNodes: function (options) {
        const nodes = [];
        auto.windows.forEach(window => {
            this._traverseNode(window.root, node => {
                if (node && node.isVisibleToUser() && this.filterByBounds(node, options)) {
                    nodes.push(node);
                }
            });
        });
        console.info(`[collectAllVisibleNodes] 限定区域内，当前页面收集到 ${nodes.length} 个可见节点`);
        return nodes;
    },

    _traverseNode: function (node, callback) {
        if (!node) return;
        // 若回调返回true则终止本层递归
        if (callback(node) === true) {
            console.log(`[NodeTraverse] 找到目标节点,终止递归`);
            return true;
        }

        for (var i = 0; i < node.getChildCount(); i++) {
            var child = node.getChild(i);
            // 若子节点递归返回true则终止循环
            if (child && this._traverseNode(child, callback)) {
                console.log(`[NodeTraverse] 找到目标节点,终止递归`);
                return true;
            }
        }
        return false; // 未找到时返回false
    },

    // Get area bounds
    _getAreaBounds: function (options) {
        const { limit_x = [0, 1], limit_y = [0, 1] } = options;
        // 使用统一的屏幕尺寸获取方法
        const screenDimensions = this.getScreenDimensions({ useLogicalSize: true });
        return {
            x: [Math.floor(limit_x[0] * screenDimensions.width), Math.ceil(limit_x[1] * screenDimensions.width)],
            y: [Math.floor(limit_y[0] * screenDimensions.height), Math.ceil(limit_y[1] * screenDimensions.height)]
        };
    },

    // Filter by bounds
    filterByBounds: function (node, options) {
        const safeBounds = this._getAreaBounds(options);
        let rect = new android.graphics.Rect();
        node.getBoundsInScreen(rect);
        return rect.left >= safeBounds.x[0] && rect.right <= safeBounds.x[1] &&
            rect.top >= safeBounds.y[0] && rect.bottom <= safeBounds.y[1];
    },

    // Get all children
    getAllChildren: function (node) {
        let children = new java.util.ArrayList();
        if (node == null) return children;
        for (let i = 0; i < node.childCount(); i++) {
            let child = node.child(i);
            children.add(child);
            children.addAll(this.getAllChildren(child));
        }
        return children;
    },

    /**
    * 获取完整节点路径（包含包名的完整类名）
    * @param {AccessibilityNode} node 目标节点
    * @returns {string|null} 示例：//android.widget.FrameLayout[3]/android.widget.LinearLayout[1]
    */
    getFullViewPath: function (node) {
        if (!node) return null;

        const pathSegments = [];
        let currentNode = node;
        let depth = 0; // 防止循环引用
        while (currentNode && depth++ < 50) {
            // 获取完整类名（保留包名）
            let className = currentNode.getClassName()?.toString() || 'Unknown';

            // 计算在父节点中的位置索引
            let index = Tool._getClassIndex(currentNode);

            pathSegments.unshift(`${className}[${index}]`);

            // 向上遍历父节点
            let parent = currentNode.getParent();
            if (!parent || parent === currentNode) break;
            currentNode = parent;
        }

        return '//' + pathSegments.join('/');
    },

    /**
     * 获取屏幕指定区域的截图，并自动处理屏幕旋转和内置调试保存功能
     * @param {object} [options={}] - 选项
     * @param {Array<number>} [options.limit_x=[0, 1]] - 截图区域的X轴比例范围
     * @param {Array<number>} [options.limit_y=[0, 1]] - 截图区域的Y轴比例范围
     * @returns {object|null} 包含裁剪后的图像及相关信息的对象，或在失败时返回null
     * @property {Image} croppedImg - 裁剪后的图像对象
     * @property {{width: number, height: number}} screenSize - 屏幕的实际尺寸（修正方向后）
     * @property {{x: number, y: number}} regionOffset - 裁剪区域左上角的坐标偏移
     */
    getScreenRegion: function (options = {}) {
        let captureScreen = images.captureScreen();
        if (!captureScreen) {
            this._onError("截图失败，请检查截图权限！");
            return null;
        }

        // 使用官方API获取当前屏幕方向，更为可靠
        importClass(android.content.res.Configuration);
        const orientation = context.getResources().getConfiguration().orientation;
        const isDeviceActuallyLandscape = (orientation === Configuration.ORIENTATION_LANDSCAPE);

        const imgWidth = captureScreen.getWidth();
        const imgHeight = captureScreen.getHeight();
        const isImageLandscape = imgWidth > imgHeight;

        console.log(`[截图流程] 原始截图尺寸: ${imgWidth}x${imgHeight} (${isImageLandscape ? '横屏' : '竖屏'})`);
        console.log(`[截图流程] 设备方向: ${isDeviceActuallyLandscape ? '横屏' : '竖屏'}`);

        // 如果设备方向和截图方向不一致，说明截图需要旋转以匹配设备方向
        if (isDeviceActuallyLandscape !== isImageLandscape) {
            console.log(`[截图流程] 设备方向(${isDeviceActuallyLandscape ? '横屏' : '竖屏'})与截图方向(${isImageLandscape ? '横屏' : '竖屏'})不一致，执行旋转。`);
            
            // 从Android系统获取真实的屏幕旋转角度
            const rotationAngle = this._getSystemRotationAngle();
            console.log(`[截图流程] 系统旋转角度: ${rotationAngle}度`);
            
            // 根据系统旋转角度计算图像需要的旋转角度
            let imageRotationAngle = 0;
            if (isDeviceActuallyLandscape && !isImageLandscape) {
                // 横屏设备拿到竖屏图像的情况
                switch (rotationAngle) {
                    case 90:   // 设备向左旋转90度（逆时针）
                        imageRotationAngle = -90;  // 图像需要逆时针旋转90度
                        break;
                    case 270:  // 设备向右旋转90度（顺时针）
                        imageRotationAngle = 90;   // 图像需要顺时针旋转90度
                        break;
                    default:
                        imageRotationAngle = -90;  // 默认逆时针旋转90度
                        console.warn(`[截图流程] 未知的系统旋转角度: ${rotationAngle}，使用默认值-90度`);
                }
            } else if (!isDeviceActuallyLandscape && isImageLandscape) {
                // 竖屏设备拿到横屏图像的情况（较少见）
                switch (rotationAngle) {
                    case 0:    // 正常竖屏
                        imageRotationAngle = 90;   // 图像需要顺时针旋转90度
                        break;
                    case 180:  // 倒置竖屏
                        imageRotationAngle = -90;  // 图像需要逆时针旋转90度
                        break;
                    default:
                        imageRotationAngle = 90;   // 默认顺时针旋转90度
                        console.warn(`[截图流程] 未知的系统旋转角度: ${rotationAngle}，使用默认值90度`);
                }
            }
            
            console.log(`[截图流程] 执行图像旋转: ${imageRotationAngle}度 (${imageRotationAngle > 0 ? '顺时针' : '逆时针'})`);
            const rotatedImage = images.rotate(captureScreen, imageRotationAngle);
            
            // 验证旋转结果是否正确
            const rotatedWidth = rotatedImage.getWidth();
            const rotatedHeight = rotatedImage.getHeight();
            const rotatedIsLandscape = rotatedWidth > rotatedHeight;
            
            console.log(`[截图流程] 旋转后尺寸: ${rotatedWidth}x${rotatedHeight} (${rotatedIsLandscape ? '横屏' : '竖屏'})`);
            
            // 检查旋转后的方向是否与设备方向匹配
            if (isDeviceActuallyLandscape === rotatedIsLandscape) {
                console.log(`[截图流程] ✅ 旋转成功，方向已匹配`);
            } else {
                console.error(`[截图流程] ❌ 旋转后方向仍不匹配！这可能是系统旋转角度检测错误`);
                console.error(`[截图流程] 系统角度: ${rotationAngle}度, 应用旋转: ${imageRotationAngle}度`);
            }
            
            // 旋转后，原图需要回收，防止内存泄漏
            captureScreen.recycle();
            captureScreen = rotatedImage;
        }

        const screenWidth = captureScreen.getWidth();
        const screenHeight = captureScreen.getHeight();
        // [调试日志]
        console.log(`[截图流程] 修正后截图尺寸: 宽度=${screenWidth}, 高度=${screenHeight}`);

        const limit_x = options.limit_x || [0, 1];
        const limit_y = options.limit_y || [0, 1];

        const calcRange = (ratioRange, maxValue) => {
            const sorted = Array.from(ratioRange).sort((a, b) => a - b);
            return [
                Math.max(0, Math.floor(sorted[0] * maxValue)),
                Math.min(maxValue, Math.ceil(sorted[1] * maxValue))
            ];
        };

        const [x1, x2] = calcRange(limit_x, screenWidth);
        const [y1, y2] = calcRange(limit_y, screenHeight);

        // [调试日志]
        console.log(`[截图流程] 裁剪参数: limit_x=${JSON.stringify(limit_x)}, limit_y=${JSON.stringify(limit_y)}`);
        console.log(`[截图流程] 计算出裁剪绝对坐标: x=[${x1}, ${x2}], y=[${y1}, ${y2}]`);

        const clipWidth = x2 - x1;
        const clipHeight = y2 - y1;

        if (clipWidth <= 0 || clipHeight <= 0) {
            console.error(`计算出的裁剪区域无效: w=${clipWidth}, h=${clipHeight}`);
            captureScreen.recycle();
            return null;
        }

        const croppedImg = images.clip(captureScreen, x1, y1, clipWidth, clipHeight);
        // 裁剪操作完成后，全屏截图即可回收
        captureScreen.recycle();

        // ----> [内置调试] 弹窗显示裁剪的图片 <----
        if (options.showDebugWindow) {
            try {
                console.log("[调试] 准备弹窗显示裁剪图片...");
                let bitmap = croppedImg.getBitmap();
                let bitmapDrawable = new android.graphics.drawable.BitmapDrawable(context.getResources(), bitmap);

                let window = floaty.window(
                    <frame w="auto" h="auto" gravity="center" bg="#44000000">
                        <vertical bg="#FFFFFF" padding="10">
                            <text text="调试截图预览" textColor="black" textSize="18sp" margin="8" textStyle="bold"/>
                            <img id="debug_image" w="auto" h="auto" maxHeight="400px" maxWidth="300px" scaleType="fitCenter"/>
                            <button id="close_button" text="关闭并继续" style="Widget.AppCompat.Button.Colored" layout_gravity="center"/>
                        </vertical>
                    </frame>
                );

                // Auto.js UI操作需要在UI线程执行
                ui.run(() => {
                    window.debug_image.setImageDrawable(bitmapDrawable);
                    window.close_button.click(() => {
                        window.close();
                    });
                });
                
                // 使用循环等待窗口关闭，实现"卡住"效果
                // 修复：使用更安全的方式检查窗口状态
                let windowClosed = false;
                window.close_button.click(() => {
                    windowClosed = true;
                    window.close();
                });
                
                while(!windowClosed){
                    sleep(200);
                }
                console.log("[调试] 预览窗口已关闭，脚本继续执行。");

            } catch (e) {
                console.error(`[调试] 显示预览窗口失败: ${e}`);
            }
        }
        // <---- [内置调试] 结束 <----

        return {
            croppedImg: croppedImg,
            screenSize: { width: screenWidth, height: screenHeight },
            regionOffset: { x: x1, y: y1 }
        };
    },

    // 核心滚动方法
    scroll: function (direction, options = {}) {
        const {
            eachDistance = 0.1,//每次滚动的距离 默认0.1 表示10%
            scrollTimes = 1,//滚动的次数，默认1次
            scrollStartPos = [0.5, 0.5],//滚动起始位置，默认中间位置
            interval = 500,//两次滚动之间的时间间隔(单位是：毫秒)
            duration = 500//滚动时长（注意：单位是：毫秒）
        } = options;

        // 使用统一的屏幕尺寸获取方法
        const screenDimensions = this.getScreenDimensions({ useLogicalSize: true });
        const { width: screenWidth, height: screenHeight } = screenDimensions;

        // 计算起始点绝对坐标
        const [startXPercent, startYPercent] = scrollStartPos;
        const startX = screenWidth * startXPercent;
        const startY = screenHeight * startYPercent;

        // 根据方向计算滑动距离
        let delta;
        switch (direction) {
            case this.DirectionType.UP:
            case this.DirectionType.DOWN:
                delta = screenHeight * eachDistance;
                break;
            case this.DirectionType.LEFT:
            case this.DirectionType.RIGHT:
                delta = screenWidth * eachDistance;
                break;
            default:
                throw new Error('Invalid scroll direction');
        }

        // 执行多次滑动
        for (let i = 0; i < scrollTimes; i++) {
            let endX = startX;
            let endY = startY;

            // 计算滑动终点坐标
            switch (direction) {
                case this.DirectionType.UP:
                    endY = Math.max(0, startY - delta);
                    break;
                case this.DirectionType.DOWN:
                    endY = Math.min(screenHeight, startY + delta);
                    break;
                case this.DirectionType.LEFT:
                    endX = Math.max(0, startX - delta);
                    break;
                case this.DirectionType.RIGHT:
                    endX = Math.min(screenWidth, startX + delta);
                    break;
            }

            // Auto.js原生滑动操作
            swipe(startX, startY, endX, endY, duration);

            // 非最后一次滑动才等待间隔
            if (i < scrollTimes - 1) {
                sleep(interval);
            }
        }
    },

    scrollUp: function (options = {}) {
        this.scroll(this.DirectionType.UP, options);
    },

    scrollDown: function (options = {}) {
        this.scroll(this.DirectionType.DOWN, options);
    },

    scrollLeft: function (options = {}) {
        this.scroll(this.DirectionType.LEFT, options);
    },

    scrollRight: function (options = {}) {
        this.scroll(this.DirectionType.RIGHT, options);
    },

    /**
     * 长按指定位置，自动处理横竖屏坐标问题
     * @param {number} x - 相对X坐标(0-1)，如0.5表示屏幕横轴中间位置
     * @param {number} y - 相对Y坐标(0-1)，如0.95表示屏幕纵轴95%位置
     * @param {number} [duration=1000] - 长按持续时间（毫秒）
     * @param {object} [options={}] - 选项
     * @param {boolean} [options.useLogicalSize=true] - 是否使用设备逻辑尺寸（默认true，用于UI操作）
     * @returns {boolean} 是否成功执行长按操作
     */
    longPress: function(x, y, duration = 1000, options = {}) {
        const { useLogicalSize = true } = options;
        
        // 使用统一的屏幕尺寸获取方法
        const dimensions = this.getScreenDimensions({ useLogicalSize });
        const targetX = Math.floor(x * dimensions.width);
        const targetY = Math.floor(y * dimensions.height);
        
        console.log(`[长按操作] 相对坐标: (${x}, ${y}) -> 绝对坐标: [${targetX}, ${targetY}] (${dimensions.source})`);
        
        // 验证坐标有效性
        if (targetX < 0 || targetX > dimensions.width || 
            targetY < 0 || targetY > dimensions.height) {
            console.error(`[长按操作] 坐标超出屏幕范围: [${targetX}, ${targetY}], 屏幕尺寸: [${dimensions.width}, ${dimensions.height}]`);
            return false;
        }
        
        try {
            console.log(`[长按操作] 执行长按: 坐标[${targetX}, ${targetY}], 持续时间${duration}ms`);
            press(targetX, targetY, duration);
            return true;
        } catch (error) {
            console.error(`[长按操作] 执行失败: ${error.message}`);
            return false;
        }
    },

    /**
     * 将节点或OCR结果转换为标准化的目标对象
     * @param {string} text - 目标的文本内容
     * @param {string} desc - 目标的描述内容
     * @param {Rect} rect - 目标的边界矩形
     * @param {AccessibilityNodeInfo} node - 无障碍节点（如果适用）
     * @param {{width: number, height: number}} [dimensions] - 可选的尺寸信息，用于OCR结果的坐标计算
     * @returns {object} 标准化的目标对象
     */
    _transformToTargetObject: function (text, desc, rect, node, dimensions) {
        const centerX = Math.floor((rect.left + rect.right) / 2);
        const centerY = Math.floor((rect.top + rect.bottom) / 2);
        var style = "default";
        if (text) {
            style = "text";
        } else if (desc) {
            style = "desc";
        }

        // 确定用于计算相对坐标的屏幕尺寸
        let screenWidth, screenHeight, dimensionSource;
        if (dimensions && dimensions.width && dimensions.height) {
            // 使用传入的截图尺寸（通常用于OCR结果）
            screenWidth = dimensions.width;
            screenHeight = dimensions.height;
            dimensionSource = "传入的截图尺寸";
        } else {
            // 使用统一的屏幕尺寸获取方法
            const screenDimensions = this.getScreenDimensions({ useLogicalSize: true });
            screenWidth = screenDimensions.width;
            screenHeight = screenDimensions.height;
            dimensionSource = screenDimensions.source;
        }

        const relativeX = (centerX / screenWidth).toFixed(3);
        const relativeY = (centerY / screenHeight).toFixed(3);

        // [调试日志] 详细记录坐标转换过程
        console.log(`[坐标转换] 文本:"${text || desc}" | 中心点:[${centerX},${centerY}] | 屏幕尺寸:[${screenWidth}x${screenHeight}](${dimensionSource}) | 相对坐标:[${relativeX},${relativeY}]`);
        
        // 检查相对坐标是否超出正常范围
        if (parseFloat(relativeX) > 1.0 || parseFloat(relativeY) > 1.0) {
            console.warn(`[坐标转换警告] 相对坐标超出范围! 文本:"${text || desc}" 相对坐标:[${relativeX},${relativeY}] 可能存在坐标系不匹配问题`);
        }

        return {
            label: text || desc,
            style: style,
            centerX: centerX,
            centerY: centerY,
            relative: {
                x: relativeX,
                y: relativeY
            },
            rect,
            node: node
        };
    },

    // Get node by view ID
    getNodeByViewId: function (viewId, options) {
        if (options == null) {
            options = { limit_x: [0, 1], limit_y: [0, 1] };
        } else {
            options.limit_x = options.limit_x || [0, 1];
            options.limit_y = options.limit_y || [0, 1];
        }
        return this._waitUntilFound(function () {
            return this._getNodeByViewIdCore(viewId, options);
        }.bind(this), options);
    },

    // Click node by view ID
    clickByViewId: function (viewId, options = {}) {
        const node = this.getNodeByViewId(viewId, options);
        if (!node) {
            const errorMsg = `[clickByViewId] 未找到目标节点: ${viewId}`;
            if (options.continueOnError) {
                console.warn(errorMsg);
                return false;
            }
            throw new Error(errorMsg);
        }

        // Get click coordinates
        const { centerX, centerY } = node;

        // Perform click
        click(centerX, centerY);
        console.log(`[clickByViewId] 点击节点: ${viewId}, 坐标: (${centerX}, ${centerY})`);
        return true;
    },

    // Get all nodes by view ID
    getAllNodesByViewId: function (viewId, options) {
        if (options == null) {
            options = { limit_x: [0, 1], limit_y: [0, 1] };
        } else {
            options.limit_x = options.limit_x || [0, 1];
            options.limit_y = options.limit_y || [0, 1];
        }
        return this._getAllNodesByViewIdCore(viewId, options);
    },

    // Core logic for getting all nodes by view ID
    _getAllNodesByViewIdCore: function (viewId, options) {
        let targetNodes = [];
        auto.windows.forEach(window => {
            this._traverseNode(window.root, node => {
                let currentViewId = node.getViewIdResourceName();
                if (currentViewId && node.isVisibleToUser()
                    && currentViewId.includes(viewId)
                    && this.filterByBounds(node, options)) {
                    let rect = new android.graphics.Rect();
                    node.getBoundsInScreen(rect);
                    console.log(`[getAllNodesByViewId] 找到匹配节点: ${currentViewId}`);
                    targetNodes.push(this._transformToTargetObject(node.getText(), node.getContentDescription(), rect, node));
                }
            });
        });
        if (targetNodes.length > 0) {
            console.log(`[getAllNodesByViewId] 共找到 ${targetNodes.length} 个匹配节点`);
        } else {
            console.info(`[getAllNodesByViewId] 限定区域内，没有找到匹配节点： ${viewId}`);
        }
        return targetNodes;
    },

    // Core logic for getting node by view ID
    _getNodeByViewIdCore: function (viewId, options) {
        let targetNode = null;
        auto.windows.forEach(window => {
            this._traverseNode(window.root, node => {
                let currentViewId = node.getViewIdResourceName();
                if (currentViewId && node.isVisibleToUser()
                    && currentViewId.includes(viewId)
                    && this.filterByBounds(node, options)) {
                    let rect = new android.graphics.Rect();
                    node.getBoundsInScreen(rect);
                    console.log(`[getNodeByViewId] 找到目标节点: ${currentViewId}`);
                    targetNode = this._transformToTargetObject(node.getText(), node.getContentDescription(), rect, node);
                    return true;
                }
            });
        });
        if (targetNode) {
            console.log(`[getNodeByViewId] 找到目标节点: ${targetNode.label}`);
        } else {
            console.info(`[getNodeByViewId] 限定区域内，没有找到目标节点： ${viewId}`);
        }
        return targetNode;
    },
    // Get all visible nodes with text
    getAllVisibleNodesWithText: function () {
        let visibleNodes = [];
        // auto.printWindows();
        auto.windows.forEach(window => {
            this._traverseNode(window.root, node => {
                if (node) {
                    let text = node.getText();
                    let desc = node.getContentDescription();
                    if ((text && text.toString().trim().length > 0) ||
                        (desc && desc.toString().trim().length > 0)) {
                        let rect = new android.graphics.Rect();
                        node.getBoundsInScreen(rect);
                        let nodeInfo = {
                            text: text ? text.toString() : '',
                            description: desc ? desc.toString() : '',
                            bounds: {
                                left: rect.left,
                                top: rect.top,
                                right: rect.right,
                                bottom: rect.bottom
                            },
                            className: node.getClassName()
                        };
                        visibleNodes.push(nodeInfo);
                        console.log(`Found node - Text: "${nodeInfo.text}", Desc: "${nodeInfo.description}", Class: ${nodeInfo.className}`);
                    }
                }
            });
        });
        console.log(`Total visible nodes with text: ${visibleNodes.length}`);
        return visibleNodes;
    },
};

module.exports = BaseUtils;

// BaseUtils.longPress(0.5, 0.95, 2000);