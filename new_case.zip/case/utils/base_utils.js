// Base utility functions
const BaseUtils = {
    // Direction type enum
    DirectionType: Object.freeze({
        UP: 1,
        DOWN: 2,
        LEFT: 3,
        RIGHT: 4
    }),

    // Convert dp to pixels
    dpToPx: function (dp) {
        let metrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * metrics.density);
    },

    // Convert sp to pixels
    spToPx: function (sp) {
        let metrics = context.getResources().getDisplayMetrics();
        return Math.round(sp * metrics.scaledDensity);
    },

    // Format map to string
    formatMap: function (map) {
        if (!map?.size) return "";
        const entries = Array.from(map, ([k, v]) => `${k}: ${v}`).join(' | ');
        return `\`${entries}\``;
    },

    // Get formatted date
    getFormattedDate: function () {
        const now = new Date();
        const month = String(now.getMonth() + 1).padStart(2, '0');
        const day = String(now.getDate()).padStart(2, '0');
        return `${month}月${day}日`;
    },

    // Query install count
    queryInstallCount: function () {
        let uri = android.net.Uri.parse("content://com.tencent.multiapp/installWWorkCount");
        let resolver = context.getContentResolver();

        try {
            let cursor = resolver.query(uri, null, null, null, null);
            if (cursor) {
                let results = [];
                let columnIndex = cursor.getColumnIndex("installWWorkCount");
                while (cursor.moveToNext()) {
                    let value = cursor.getInt(columnIndex);
                    results.push(value);
                    log("查询到安装次数:", value);
                }
                cursor.close();
                return results;
            } else {
                toast("未查询到数据");
                return [];
            }
        } catch (e) {
            console.error("查询失败:", e);
            toast("查询失败，请检查权限");
            return null;
        }
    },

    // Error handler
    _onError: function (errorMessage, options = {}) {
        const { continueOnError = false } = options;
        console.log(`-->>${errorMessage}`);
        if (!continueOnError) {
            throw new Error(`${errorMessage}`);
        }
    },

    // Wait until found with timeout
    _waitUntilFound: function (action, options) {
        const timeout = options.timeout || 10000;
        const interval = options.interval || 1000;
        const continueOnError = options.continueOnError;
        const startTime = Date.now();

        while (Date.now() - startTime < timeout) {
            var result = action();
            if (result) return result;
            sleep(interval);
        }
        const errorMsg = "操作超时 (" + timeout + "ms)";
        if (!continueOnError) throw new Error(errorMsg);
        console.warn(errorMsg);
        return null;
    },

    // 收集当前屏幕上可见的所有节点
    collectAllVisibleNodes: function (options) {
        const nodes = [];
        auto.windows.forEach(window => {
            this._traverseNode(window.root, node => {
                if (node && node.isVisibleToUser() && this.filterByBounds(node, options)) {
                    nodes.push(node);
                }
            });
        });
        console.info(`[collectAllVisibleNodes] 限定区域内，当前页面收集到 ${nodes.length} 个可见节点`);
        return nodes;
    },

    _traverseNode: function (node, callback) {
        if (!node) return;
        // 若回调返回true则终止本层递归
        if (callback(node) === true) {
            console.log(`[NodeTraverse] 找到目标节点,终止递归`);
            return true;
        }

        for (var i = 0; i < node.getChildCount(); i++) {
            var child = node.getChild(i);
            // 若子节点递归返回true则终止循环
            if (child && this._traverseNode(child, callback)) {
                console.log(`[NodeTraverse] 找到目标节点,终止递归`);
                return true;
            }
        }
        return false; // 未找到时返回false
    },

    // Get area bounds
    _getAreaBounds: function (options) {
        const { limit_x = [0, 1], limit_y = [0, 1] } = options;
        return {
            x: [Math.floor(limit_x[0] * device.width), Math.ceil(limit_x[1] * device.width)],
            y: [Math.floor(limit_y[0] * device.height), Math.ceil(limit_y[1] * device.height)]
        };
    },

    // Filter by bounds
    filterByBounds: function (node, options) {
        const safeBounds = this._getAreaBounds(options);
        let rect = new android.graphics.Rect();
        node.getBoundsInScreen(rect);
        return rect.left >= safeBounds.x[0] && rect.right <= safeBounds.x[1] &&
            rect.top >= safeBounds.y[0] && rect.bottom <= safeBounds.y[1];
    },

    // Get all children
    getAllChildren: function (node) {
        let children = new java.util.ArrayList();
        if (node == null) return children;
        for (let i = 0; i < node.childCount(); i++) {
            let child = node.child(i);
            children.add(child);
            children.addAll(this.getAllChildren(child));
        }
        return children;
    },


    /**
    * 获取完整节点路径（包含包名的完整类名）
    * @param {AccessibilityNode} node 目标节点
    * @returns {string|null} 示例：//android.widget.FrameLayout[3]/android.widget.LinearLayout[1]
    */
    getFullViewPath: function (node) {
        if (!node) return null;

        const pathSegments = [];
        let currentNode = node;
        let depth = 0; // 防止循环引用
        while (currentNode && depth++ < 50) {
            // 获取完整类名（保留包名）
            let className = currentNode.getClassName()?.toString() || 'Unknown';

            // 计算在父节点中的位置索引
            let index = Tool._getClassIndex(currentNode);

            pathSegments.unshift(`${className}[${index}]`);

            // 向上遍历父节点
            let parent = currentNode.getParent();
            if (!parent || parent === currentNode) break;
            currentNode = parent;
        }

        return '//' + pathSegments.join('/');
    },

    // 公共方法：获取屏幕区域限制参数
    getScreenRegion: function (options = {}) {
        // 获取全屏截图用于计算
        const fullScreen = images.captureScreen();
        const screenWidth = fullScreen.getWidth();
        const screenHeight = fullScreen.getHeight();

        // 处理坐标范围参数
        const limit_x = options.limit_x || [0, 1];
        const limit_y = options.limit_y || [0, 1];

        // 计算实际像素范围（自动排序+边界保护）
        const calcRange = (ratioRange, maxValue) => {
            const sorted = Array.from(ratioRange).sort((a, b) => a - b);
            return [
                Math.max(0, Math.floor(sorted[0] * maxValue)),
                Math.min(maxValue, Math.ceil(sorted[1] * maxValue))
            ];
        };

        // 获取有效像素范围
        const [x1, x2] = calcRange(limit_x, screenWidth);
        const [y1, y2] = calcRange(limit_y, screenHeight);

        // 返回裁剪后的图像和原始屏幕尺寸
        return {
            croppedImg: images.clip(fullScreen, x1, y1, x2 - x1, y2 - y1),
            screenSize: { width: screenWidth, height: screenHeight },
            regionOffset: { x: x1, y: y1 } // 区域偏移量用于坐标转换
        };
    },

    // 核心滚动方法
    scroll: function (direction, options = {}) {
        const {
            eachDistance = 0.1,//每次滚动的距离 默认0.1 表示10%
            scrollTimes = 1,//滚动的次数，默认1次
            scrollStartPos = [0.5, 0.5],//滚动起始位置，默认中间位置
            interval = 500,//两次滚动之间的时间间隔(单位是：毫秒)
            duration = 500//滚动时长（注意：单位是：毫秒）
        } = options;

        // 获取屏幕尺寸
        const { width: screenWidth, height: screenHeight } = device;

        // 计算起始点绝对坐标
        const [startXPercent, startYPercent] = scrollStartPos;
        const startX = screenWidth * startXPercent;
        const startY = screenHeight * startYPercent;

        // 根据方向计算滑动距离
        let delta;
        switch (direction) {
            case this.DirectionType.UP:
            case this.DirectionType.DOWN:
                delta = screenHeight * eachDistance;
                break;
            case this.DirectionType.LEFT:
            case this.DirectionType.RIGHT:
                delta = screenWidth * eachDistance;
                break;
            default:
                throw new Error('Invalid scroll direction');
        }

        // 执行多次滑动
        for (let i = 0; i < scrollTimes; i++) {
            let endX = startX;
            let endY = startY;

            // 计算滑动终点坐标
            switch (direction) {
                case this.DirectionType.UP:
                    endY = Math.max(0, startY - delta);
                    break;
                case this.DirectionType.DOWN:
                    endY = Math.min(screenHeight, startY + delta);
                    break;
                case this.DirectionType.LEFT:
                    endX = Math.max(0, startX - delta);
                    break;
                case this.DirectionType.RIGHT:
                    endX = Math.min(screenWidth, startX + delta);
                    break;
            }

            // Auto.js原生滑动操作
            swipe(startX, startY, endX, endY, duration);

            // 非最后一次滑动才等待间隔
            if (i < scrollTimes - 1) {
                sleep(interval);
            }
        }
    },

    scrollUp: function (options = {}) {
        this.scroll(this.DirectionType.UP, options);
    },

    scrollDown: function (options = {}) {
        this.scroll(this.DirectionType.DOWN, options);
    },

    scrollLeft: function (options = {}) {
        this.scroll(this.DirectionType.LEFT, options);
    },

    scrollRight: function (options = {}) {
        this.scroll(this.DirectionType.RIGHT, options);
    },

    // Transform node to target object
    _transformToTargetObject: function (text, desc, rect, node) {
        const centerX = Math.floor((rect.left + rect.right) / 2);
        const centerY = Math.floor((rect.top + rect.bottom) / 2);
        var style = "default";
        if (text) {
            style = "text";
        } else if (desc) {
            style = "desc";
        }
        return {
            label: text || desc,
            style: style,
            centerX: centerX,
            centerY: centerY,
            relative: {
                x: (centerX / device.width).toFixed(3),
                y: (centerY / device.height).toFixed(3)
            },
            rect,
            node: node
        };
    },

    // Get node by view ID
    getNodeByViewId: function (viewId, options) {
        if (options == null) {
            options = { limit_x: [0, 1], limit_y: [0, 1] };
        } else {
            options.limit_x = options.limit_x || [0, 1];
            options.limit_y = options.limit_y || [0, 1];
        }
        return this._waitUntilFound(function () {
            return this._getNodeByViewIdCore(viewId, options);
        }.bind(this), options);
    },

    // Click node by view ID
    clickByViewId: function (viewId, options = {}) {
        const node = this.getNodeByViewId(viewId, options);
        if (!node) {
            const errorMsg = `[clickByViewId] 未找到目标节点: ${viewId}`;
            if (options.continueOnError) {
                console.warn(errorMsg);
                return false;
            }
            throw new Error(errorMsg);
        }

        // Get click coordinates
        const { centerX, centerY } = node;

        // Perform click
        click(centerX, centerY);
        console.log(`[clickByViewId] 点击节点: ${viewId}, 坐标: (${centerX}, ${centerY})`);
        return true;
    },

    // Get all nodes by view ID
    getAllNodesByViewId: function (viewId, options) {
        if (options == null) {
            options = { limit_x: [0, 1], limit_y: [0, 1] };
        } else {
            options.limit_x = options.limit_x || [0, 1];
            options.limit_y = options.limit_y || [0, 1];
        }
        return this._getAllNodesByViewIdCore(viewId, options);
    },

    // Core logic for getting all nodes by view ID
    _getAllNodesByViewIdCore: function (viewId, options) {
        let targetNodes = [];
        auto.windows.forEach(window => {
            this._traverseNode(window.root, node => {
                let currentViewId = node.getViewIdResourceName();
                if (currentViewId && node.isVisibleToUser()
                    && currentViewId.includes(viewId)
                    && this.filterByBounds(node, options)) {
                    let rect = new android.graphics.Rect();
                    node.getBoundsInScreen(rect);
                    console.log(`[getAllNodesByViewId] 找到匹配节点: ${currentViewId}`);
                    targetNodes.push(this._transformToTargetObject(node.getText(), node.getContentDescription(), rect, node));
                }
            });
        });
        if (targetNodes.length > 0) {
            console.log(`[getAllNodesByViewId] 共找到 ${targetNodes.length} 个匹配节点`);
        } else {
            console.info(`[getAllNodesByViewId] 限定区域内，没有找到匹配节点： ${viewId}`);
        }
        return targetNodes;
    },

    // Core logic for getting node by view ID
    _getNodeByViewIdCore: function (viewId, options) {
        let targetNode = null;
        auto.windows.forEach(window => {
            this._traverseNode(window.root, node => {
                let currentViewId = node.getViewIdResourceName();
                if (currentViewId && node.isVisibleToUser()
                    && currentViewId.includes(viewId)
                    && this.filterByBounds(node, options)) {
                    let rect = new android.graphics.Rect();
                    node.getBoundsInScreen(rect);
                    console.log(`[getNodeByViewId] 找到目标节点: ${currentViewId}`);
                    targetNode = this._transformToTargetObject(node.getText(), node.getContentDescription(), rect, node);
                    return true;
                }
            });
        });
        if (targetNode) {
            console.log(`[getNodeByViewId] 找到目标节点: ${targetNode.label}`);
        } else {
            console.info(`[getNodeByViewId] 限定区域内，没有找到目标节点： ${viewId}`);
        }
        return targetNode;
    },
    // Get all visible nodes with text
    getAllVisibleNodesWithText: function () {
        let visibleNodes = [];
        // auto.printWindows();
        auto.windows.forEach(window => {
            this._traverseNode(window.root, node => {
                if (node) {
                    let text = node.getText();
                    let desc = node.getContentDescription();
                    if ((text && text.toString().trim().length > 0) ||
                        (desc && desc.toString().trim().length > 0)) {
                        let rect = new android.graphics.Rect();
                        node.getBoundsInScreen(rect);
                        let nodeInfo = {
                            text: text ? text.toString() : '',
                            description: desc ? desc.toString() : '',
                            bounds: {
                                left: rect.left,
                                top: rect.top,
                                right: rect.right,
                                bottom: rect.bottom
                            },
                            className: node.getClassName()
                        };
                        visibleNodes.push(nodeInfo);
                        console.log(`Found node - Text: "${nodeInfo.text}", Desc: "${nodeInfo.description}", Class: ${nodeInfo.className}`);
                    }
                }
            });
        });
        console.log(`Total visible nodes with text: ${visibleNodes.length}`);
        return visibleNodes;
    },
};

module.exports = BaseUtils; 

// BaseUtils.scrollUp({ eachDistance: 0.8, scrollStartPos: [0.5, 0.9], max_scroll_times: 1, duration: 2000 });

// let webNode = className("android.webkit.WebView").findOne();
// // console.log("webNode",webNode)
// // //获取webNode所有的子节点并打印出有文字的子节点
// let allChildren = BaseUtils.getAllChildren(webNode);
// for(let child of allChildren){
//     let text = child.getText() || child.getContentDescription();
//     if(text && text.toString().trim().length != 0){
//         console.log("text",text)
//     }
// }

// BaseUtils.getAllVisibleNodesWithText();


// auto.windows.forEach(window => {
//     BaseUtils._traverseNode(window.root, node => {
//         if (node) {
//             console.log(`-----------Found node - Text: "${node.text}", Desc: "${node.description}", Class: ${node.className}`);
//             console.log(node)
//         }
//     });
// });

