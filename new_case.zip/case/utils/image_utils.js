const BaseUtils = require('./base_utils');

const ImageUtils = {
    // Get screen region with bounds
    _getScreenRegion: function(options = {}) {
        const fullScreen = images.captureScreen();
        const screenWidth = fullScreen.getWidth();
        const screenHeight = fullScreen.getHeight();

        const limit_x = options.limit_x || [0, 1];
        const limit_y = options.limit_y || [0, 1];

        const calcRange = (ratioRange, maxValue) => {
            const sorted = Array.from(ratioRange).sort((a, b) => a - b);
            return [
                Math.max(0, Math.floor(sorted[0] * maxValue)),
                Math.min(maxValue, Math.ceil(sorted[1] * maxValue))
            ];
        };

        const [x1, x2] = calcRange(limit_x, screenWidth);
        const [y1, y2] = calcRange(limit_y, screenHeight);

        return {
            croppedImg: images.clip(fullScreen, x1, y1, x2 - x1, y2 - y1),
            screenSize: {width: screenWidth, height: screenHeight},
            regionOffset: {x: x1, y: y1}
        };
    },

    // Calculate target position
    _calculateTargetPos: function(matchResult, targetPos) {
        const centerX = matchResult.point.x + matchResult.templateSize.width * targetPos[0];
        const centerY = matchResult.point.y + matchResult.templateSize.height * targetPos[1];
        return {x: centerX, y: centerY};
    },

    // Calculate overlap between two regions
    _calculateOverlap: function(a, b) {
        const rectA = {
            x: a.point.x, y: a.point.y,
            width: a.templateSize.width, height: a.templateSize.height
        };
        const rectB = {
            x: b.point.x, y: b.point.y,
            width: b.templateSize.width, height: b.templateSize.height
        };

        const left = Math.max(rectA.x, rectB.x);
        const right = Math.min(rectA.x + rectA.width, rectB.x + rectB.width);
        const top = Math.max(rectA.y, rectB.y);
        const bottom = Math.min(rectA.y + rectA.height, rectB.y + rectB.height);

        if (left >= right || top >= bottom) return 0;

        const intersectionArea = (right - left) * (bottom - top);
        const unionArea = rectA.width * rectA.height + rectB.width * rectB.height - intersectionArea;
        return intersectionArea / unionArea;
    },

    // Find image with core logic
    findImage: function(templatePath, options) {
        options = options || {};
        const timeout = options.timeout;
        delete options.timeout;
        
        const modifiedOptions = Object.assign({}, options, {
            continueOnError: true
        });

        return BaseUtils._waitUntilFound(function() {
            return this._findImageCore(templatePath, modifiedOptions);
        }.bind(this), {
            timeout: timeout,
            interval: options.interval,
            continueOnError: options.continueOnError,
        });
    },

    // Find multiple images with core logic
    findImages: function(templatePaths, options) {
        options = options || {};
        const timeout = options.timeout;
        delete options.timeout;
        
        // Ensure templatePaths is an array
        if (!Array.isArray(templatePaths)) {
            templatePaths = [templatePaths];
        }
        
        const modifiedOptions = Object.assign({}, options, {
            continueOnError: true
        });

        return BaseUtils._waitUntilFound(function() {
            return this._findImagesCore(templatePaths, modifiedOptions);
        }.bind(this), {
            timeout: timeout,
            interval: options.interval,
            continueOnError: options.continueOnError,
        });
    },

    // Core image finding logic for multiple images
    _findImagesCore: function(templatePaths, options = {}) {
        const config = Object.assign({
            limit_x: [0, 1],
            limit_y: [0, 1],
            targetPos: [0.5, 0.5],
            minScale: 0.5,
            maxScale: 2.0,
            scaleStep: 0.1,
            threshold: 0.6,
            continueOnError: false,
            gray: false,
            returnAll: false // If true, return all matches, otherwise return the best match
        }, options);

        console.info(`[_findImagesCore] 开始搜索多个图像，共 ${templatePaths.length} 个，参数：${JSON.stringify(options)}`);
        
        // Get screen region once for all templates
        let {croppedImg, screenSize, regionOffset} = this._getScreenRegion(config);
        let screen = croppedImg;

        if (config.gray && screen) {
            screen = images.grayscale(screen);
        }

        if (!screen) {
            let errorMsg = `[_findImagesCore] 获取屏幕截图失败，请允许录屏权限`;
            if (!config.continueOnError) throw new Error(errorMsg);
            console.warn(errorMsg);
            return null;
        }

        // Store all matches
        let allMatches = [];
        
        // Process each template
        for (let pathIndex = 0; pathIndex < templatePaths.length; pathIndex++) {
            const templatePath = templatePaths[pathIndex];
            console.log(`[_findImagesCore] 处理第 ${pathIndex+1}/${templatePaths.length} 个图像: ${templatePath}`);
            
            let template = images.read(templatePath);
            
            if (config.gray && template) {
                template = images.grayscale(template);
            }

            if (!template) {
                console.warn(`[_findImagesCore] 未能成功读取目标图: ${templatePath}，跳过`);
                continue;
            }

            let bestMatch = null;

            for (let scale = config.minScale; scale <= config.maxScale + 0.0001;
                 scale = parseFloat((scale + config.scaleStep).toFixed(2))) {
                var scaledTemplate = images.scale(template, scale, scale);

                if (scaledTemplate.width > screen.width || scaledTemplate.height > screen.height) {
                    scaledTemplate.recycle();
                    continue;
                }

                var result = images.matchTemplate(screen, scaledTemplate, {
                    threshold: config.threshold,
                    max: 1
                });

                if (result.matches.length > 0) {
                    var currentMatch = result.matches[0];
                    if (!bestMatch || currentMatch.similarity > bestMatch.similarity) {
                        var globalPoint = {
                            x: currentMatch.point.x + regionOffset.x,
                            y: currentMatch.point.y + regionOffset.y
                        };

                        bestMatch = {
                            point: globalPoint,
                            similarity: currentMatch.similarity,
                            templateSize: {
                                width: scaledTemplate.width,
                                height: scaledTemplate.height
                            },
                            relative: {
                                x: globalPoint.x / screenSize.width,
                                y: globalPoint.y / screenSize.height
                            },
                            path: templatePath,
                            scale: scale
                        };
                    }
                }
                scaledTemplate.recycle();
            }

            template.recycle();

            if (bestMatch) {
                console.info(`[_findImagesCore] 找到图像 ${templatePath} 的最佳匹配（相似度 ${(bestMatch.similarity * 100).toFixed(1)}%）`);
                var target = this._calculateTargetPos(bestMatch, config.targetPos);

                var matchResult = Object.assign({}, bestMatch, {
                    targetPoint: target,
                    targetRelative: {
                        x: target.x / screenSize.width,
                        y: target.y / screenSize.height
                    }
                });
                
                allMatches.push(matchResult);
                
                // If we're not returning all matches and we found a good match, we can stop
                if (!config.returnAll && bestMatch.similarity >= config.threshold) {
                    break;
                }
            }
        }

        // Recycle screen image
        screen.recycle();

        if (allMatches.length > 0) {
            // Sort by similarity (highest first)
            allMatches.sort((a, b) => b.similarity - a.similarity);
            
            if (config.returnAll) {
                console.info(`[_findImagesCore] 找到 ${allMatches.length} 个匹配项`);
                return allMatches;
            } else {
                console.info(`[_findImagesCore] 返回最佳匹配（相似度 ${(allMatches[0].similarity * 100).toFixed(1)}%）`);
                return allMatches[0];
            }
        }

        const errorMsgResult = `[_findImagesCore] 未找到任何图像 (搜索范围: x=${config.limit_x}, y=${config.limit_y})`;
        BaseUtils._onError(errorMsgResult, options);
        return null;
    },

    // Core image finding logic (single image)
    _findImageCore: function(templatePath, options = {}) {
        // Use the multi-image function with a single path
        return this._findImagesCore([templatePath], options);
    },

    // Find all images by CV
    findAllImgListByCV: function(templatePath, options = {}) {
        const config = Object.assign({
            limit_x: [0, 1],
            limit_y: [0, 1],
            targetPos: [0.5, 0.5],
            minScale: 0.5,
            maxScale: 2.0,
            scaleStep: 0.1,
            threshold: 0.6,
            continueOnError: false
        }, options);

        console.info(`[findAllImgsByCV] 开始搜索图像 ${templatePath}，参数：${JSON.stringify(options)}`);
        
        let template = images.read(templatePath);
        let {croppedImg, screenSize, regionOffset} = this._getScreenRegion(config);
        let screen = croppedImg;

        if (!screen) {
            let errorMsg = `[findAllImgsByCV] 获取屏幕截图失败，请允许录屏权限`;
            if (!config.continueOnError) throw new Error(errorMsg);
            console.warn(errorMsg);
            return null;
        }

        if (!template) {
            let errMsg = `[findAllImgsByCV] 未能成功读取目标图，请检查图片是否存在`;
            BaseUtils._onError(errMsg, options);
            return null;
        }

        let allMatches = [];

        for (let scale = config.minScale; scale <= config.maxScale + 0.0001;
             scale = parseFloat((scale + config.scaleStep).toFixed(2))) {
            let scaledTemplate = images.scale(template, scale, scale);
            
            if (scaledTemplate.width > screen.width || scaledTemplate.height > screen.height) {
                scaledTemplate.recycle();
                continue;
            }

            let result = images.matchTemplate(screen, scaledTemplate, {
                threshold: config.threshold,
            });

            result.matches.forEach(match => {
                let globalPoint = {
                    x: match.point.x + regionOffset.x,
                    y: match.point.y + regionOffset.y
                };
                allMatches.push({
                    point: globalPoint,
                    similarity: match.similarity,
                    templateSize: {width: scaledTemplate.width, height: scaledTemplate.height},
                    scale: scale,
                    relative: {
                        x: globalPoint.x / screenSize.width,
                        y: globalPoint.y / screenSize.height
                    }
                });
            });
            scaledTemplate.recycle();
        }

        allMatches = allMatches.sort((a, b) => b.similarity - a.similarity)
            .filter((match, index, arr) => {
                for (let i = 0; i < index; i++) {
                    let existing = arr[i];
                    let overlap = this._calculateOverlap(match, existing);
                    if (overlap > config.overlapThreshold) {
                        return false;
                    }
                }
                return true;
            }).slice(0, config.maxMatches);

        template.recycle();
        screen.recycle();

        if (allMatches.length > 0) {
            console.info(`[_findAllImagesCore] 找到 ${allMatches.length} 个匹配项`);
            return allMatches.map(match => {
                return Object.assign({}, match, {
                    targetPoint: this._calculateTargetPos(match, config.targetPos)
                });
            });
        }

        BaseUtils._onError(`未找到图像: ${templatePath}`, options);
        return null;
    },

    // Click image at position
    clickImage: function(templatePath, options) {
        options = options || {};
        const result = this.findImage(templatePath, Object.assign({}, options, {
            continueOnError: true
        }));
        
        if (result) {
            click(result.targetPoint.x, result.targetPoint.y);
            return true;
        }
        
        const errorMsg = '[clickImage]"' + templatePath + '" 失败,未找到目标图标';
        BaseUtils._onError(errorMsg, options);
        return false;
    },
    
    // Click any image from multiple paths
    clickAnyImage: function(templatePaths, options) {
        options = options || {};
        
        // Ensure templatePaths is an array
        if (!Array.isArray(templatePaths)) {
            templatePaths = [templatePaths];
        }
        
        console.info(`[clickAnyImage] 开始尝试点击多个图像中的任意一个，共 ${templatePaths.length} 个图像`);
        
        // Use the optimized findImages function to get the best match
        const result = this.findImages(templatePaths, Object.assign({}, options, {
            continueOnError: true
        }));
        
        if (result) {
            console.log(`[clickAnyImage] 找到并点击图像: ${result.path} 相对坐标: ${result.relative.x},${result.relative.y}`);
            click(result.targetPoint.x, result.targetPoint.y);
            return true;
        }
        
        // If we get here, none of the images were found
        const errorMsg = `[clickAnyImage] 未找到任何目标图像，共尝试了 ${templatePaths.length} 个图像`;
        console.warn(errorMsg);
        BaseUtils._onError(errorMsg, options);
        return false;
    }
};

// For AutoJS compatibility
module.exports = ImageUtils; 