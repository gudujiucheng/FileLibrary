const BaseUtils = require('./base_utils');

const TextUtils = {
    /**
     * 文本匹配模式
     * @enum {string}
     */
    MatchMode: Object.freeze({
        CONTAINS: 'contains', // 包含模式
        EQUALS: 'equals'      // 精确匹配模式
    }),

    // Transform node to target object
    _transformToTargetObject: function (text, desc, rect, node) {
        return BaseUtils._transformToTargetObject(text, desc, rect, node);
    },

    // Get node by view ID
    getNodeByViewId: function (viewId, options) {
        return BaseUtils.getNodeByViewId(viewId, options);
    },

    // Core logic for getting node by view ID
    _getNodeByViewIdCore: function (viewId, options) {
        return BaseUtils._getNodeByViewIdCore(viewId, options);
    },

    // Get all text nodes
    getAllHasTextNodes: function (options) {
        if (options == null) {
            options = { limit_x: [0, 1], limit_y: [0, 1] };
        } else {
            options.limit_x = options.limit_x || [0, 1];
            options.limit_y = options.limit_y || [0, 1];
        }
        const nodes = [];
        auto.windows.forEach(window => {
            BaseUtils._traverseNode(window.root, node => {
                let text = node.getText();
                let desc = node.getContentDescription();
                if (node && node.isVisibleToUser()
                    && ((text && text.toString().length > 0) || (desc && desc.toString().length > 0))
                    && BaseUtils.filterByBounds(node, options)) {
                    let rect = new android.graphics.Rect();
                    node.getBoundsInScreen(rect);
                    nodes.push(this._transformToTargetObject(node.getText(), node.getContentDescription(), rect, node));
                }
            });
        });
        console.info(`[getAllHasTextNodes] 限定区域内，当前页面收集到 ${nodes.length} 个可见节点`);
        return nodes;
    },

    // Get full view path
    _getFullViewPath: function (node) {
        if (!node) return null;

        const pathSegments = [];
        let currentNode = node;
        let depth = 0;
        while (currentNode && depth++ < 50) {
            let className = currentNode.getClassName()?.toString() || 'Unknown';
            let index = this._getClassIndex(currentNode);
            pathSegments.unshift(`${className}[${index}]`);
            let parent = currentNode.getParent();
            if (!parent || parent === currentNode) break;
            currentNode = parent;
        }

        return '//' + pathSegments.join('/');
    },

    // Get class index
    _getClassIndex: function (node) {
        const parent = node.getParent();
        if (!parent) return -1;

        let count = 0;
        const targetClass = node.getClassName()?.toString();
        const childCount = parent.getChildCount();

        for (let i = 0; i < childCount; i++) {
            let child = parent.getChild(i);
            if (!child) continue;

            let childClass = child.getClassName()?.toString();
            if (childClass === targetClass) {
                count++;
            }

            if (child.equals(node)) {
                return count;
            }
        }

        return -1;
    },

    // Get all texts by OCR
    getAllTextsByOcr: function (options) {
        if (options == null) {
            options = { limit_x: [0, 1], limit_y: [0, 1] };
        } else {
            options.limit_x = options.limit_x || [0, 1];
            options.limit_y = options.limit_y || [0, 1];
        }
        const { croppedImg, screenSize, regionOffset } = BaseUtils.getScreenRegion(options);
        const results = ocr.paddle.detect(croppedImg, {
            useSlim: false,
            cpuThreadNum: 4
        });

        const adjustCoordinates = (rect) => ({
            left: rect.left + regionOffset.x,
            top: rect.top + regionOffset.y,
            right: rect.right + regionOffset.x,
            bottom: rect.bottom + regionOffset.y
        });

        const formatResult = [];
        for (var ocrItem of results) {
            formatResult.push(this._transformToTargetObject(ocrItem.label, null, adjustCoordinates(ocrItem.bounds), null));
        }
        return formatResult;
    },

    // Find text
    findText: function (text, options) {
        options = options || {};
        var timeout = options.timeout;
        delete options.timeout;
        var modifiedOptions = Object.assign({}, options, {
            continueOnError: true
        });

        return BaseUtils._waitUntilFound(function () {
            return this._findTextCore(text, modifiedOptions);
        }.bind(this), {
            timeout: timeout,
            interval: options.interval,
            continueOnError: options.continueOnError
        });
    },

    // Core text finding logic
    _findTextCore: function (text, options = {}) {
        console.info(`[_findTextCore] 开始查找文本 "${text}"，配置：${JSON.stringify(options)}`);
        const { continueOnError = false } = options;
        const modifiedOptions = Object.assign({}, options, {
            continueOnError: true
        });
        const filtered = this.findAllByTexts(text, modifiedOptions);

        if (filtered && filtered.length > 0) {
            return filtered[0];
        }

        const errorMessage = `轮询查找中...[_findTextCore] 未找到文本: ${text} (搜索区域: x=${JSON.stringify(options.limit_x || '全屏')}, y=${JSON.stringify(options.limit_y || '全屏')})`;
        BaseUtils._onError(errorMessage, options);

        return null;
    },

    // Find all texts
    findAllByTexts: function (targetTexts, options = {}) {
        targetTexts = Array.isArray(targetTexts) ? targetTexts : [targetTexts];
        const { matchMode = this.MatchMode.CONTAINS } = options; // 使用常量
        console.info(`[findAllByTexts] 开始查找文本 "${targetTexts}"，配置：${JSON.stringify(options)}`);

        if (options.isFindByNode !== false) {
            const nodeResults = this.findAllNodesByTexts(targetTexts, options);
            if (nodeResults && nodeResults.length > 0) {
                console.log(`findAllByTexts [NodeFind] 找到 ${nodeResults.length} 个节点匹配项`);
                return nodeResults;
            } else {
                console.log(`findAllByTexts [NodeFind] 没有找到文本 "${targetTexts}"的匹配项节点，准备OCR查找`);
            }
        }

        const { croppedImg, screenSize, regionOffset } = BaseUtils.getScreenRegion(options);
        const results = ocr.paddle.detect(croppedImg, {
            useSlim: false,
            cpuThreadNum: 4
        });

        const adjustCoordinates = (rect) => ({
            left: rect.left + regionOffset.x,
            top: rect.top + regionOffset.y,
            right: rect.right + regionOffset.x,
            bottom: rect.bottom + regionOffset.y
        });

        const filtered = [];
        for (var ocrItem of results) {
            if (options.showDetailLog) {
                console.log(`===========[findAllByTexts] OCR识别结果: ${ocrItem.label}`);
            }
            for (var targetText of targetTexts) {
                let isMatch = false;
                if (matchMode === this.MatchMode.EQUALS) {
                    isMatch = ocrItem.label === targetText;
                } else { // 默认为 'contains'
                    isMatch = ocrItem.label.includes(targetText);
                }

                if (isMatch) {
                    filtered.push(this._transformToTargetObject(targetText, null, adjustCoordinates(ocrItem.bounds), null));
                }
            }
        }

        console.log(`findAllByTexts [ocrFind] 在区域[${JSON.stringify(options)}] 找到 ${filtered.length} 个"${targetTexts}"匹配项 (模式: ${matchMode})`);
        filtered.forEach((it, index) => {
            console.log(`  ${index + 1}: 绝对[${it.centerX},${it.centerY}] 相对[${it.relative.x},${it.relative.y}] "${it.label}"`);
        });

        return filtered;
    },

    // Click text
    clickText: function (text, options = {}) {
        console.info(`[Click] 开始点击文本 "${text}"，配置：${JSON.stringify(options)}`);
        options = options || {};
        const result = this.findText(text, Object.assign({}, options, {
            continueOnError: true
        }));

        if (result) {
            console.log(`文本 "${text} " success , 点击坐标 (${result.relative.x},${result.relative.y})`);
            if (result.node) {
                const rect = new android.graphics.Rect();
                result.node.getBoundsInScreen(rect);
                console.log(`[clickText] 获取最新Node节点点击坐标 (${rect.centerX()},${rect.centerY()}),原坐标(${result.centerX},${result.centerY})`);
                click(rect.centerX(), rect.centerY());
            } else {
                console.log(`[clickText] OCR 点击相对坐标 (${result.relative.x},${result.relative.y}),原坐标(${result.centerX},${result.centerY})`);
                click(result.centerX, result.centerY);
            }

            sleep(result.node ? 2000 : 500);
            return true;
        }

        const errorMsg = '[clickText]"' + text + '" 失败';
        BaseUtils._onError(errorMsg, options);
        return false;
    },

    // Input text
    inputText: function (targetClickText, inputText, options = {}) {
        const { continueOnError = false, tryPos = null } = options;

        console.log(`🔍 [inputText] 开始输入文本操作，目标: "${targetClickText}", 内容: "${inputText}"`);

        // Convert single text to array if needed
        const targetTexts = Array.isArray(targetClickText) ? targetClickText : [targetClickText];
        console.log(`🔍 开始查找目标文本: ${targetTexts.join(', ')}`);

        let targetResult = this.findAnyTargetText(targetTexts, options);

        if (!targetResult || targetResult.length === 0 || targetResult[0].centerX === undefined || targetResult[0].centerY === undefined) {
            BaseUtils._onError(`[inputText]找不到目标文本: ${targetTexts.join(', ')}`, options);
            if (tryPos == null) {
                return false;
            } else {
                console.log(`[inputText]找不到目标文本, 尝试使用指定坐标点击`);
                targetResult = [{
                    centerX: Math.floor(tryPos[0] * device.width),
                    centerY: Math.floor(tryPos[1] * device.height)
                }];
            }
        }
        console.log(`✅ 定位到目标位置: [${targetResult[0].centerX},${targetResult[0].centerY}]`);

        // 执行长按操作
        press(targetResult[0].centerX, targetResult[0].centerY, 1500);
        console.log("🖱️ 已执行长按操作");
        sleep(500);

        // 使用新封装的粘贴方法
        return this.pasteText(inputText, options);
    },

    // 增强版节点批量查找
    findAllNodesByTexts: function (targetTexts, options) {
        options = options || {};
        console.info(`[NodeBatchSearch] 开始批量查找 ${targetTexts.join(',')}`);
        // 查找系统节点
        const systemNodes = this._traverseSystemWindows(targetTexts, options);
        if (systemNodes.length === 0) {
            return [];
        }
        console.verbose(`[NodeBatchSearch] 原始系统节点数: ${systemNodes.length}`);

        // 去重处理
        const uniqueKeys = {};
        const uniqueNodes = [];
        for (var i = 0; i < systemNodes.length; i++) {
            var node = systemNodes[i]; // 修正变量名错误
            var key = node.getViewIdResourceName() + "|" + node.getClassName() + "@" + node.hashCode();
            if (!uniqueKeys[key]) {
                uniqueKeys[key] = true;
                var rect = new android.graphics.Rect();
                node.getBoundsInScreen(rect);
                var result = this._transformToTargetObject(node.getText(), node.getContentDescription(), rect, node);
                // 记录节点详情
                console.log(`[节点详情] ${key} \n                文本: ${result.label}\n                可见: ${node.isVisibleToUser()}\n                相对坐标: ${result.relative.x},${result.relative.y}`);
                uniqueNodes.push(result);
            }
        }
        console.info(`[NodeBatchSearch] 完成批量查找，共找到 ${uniqueNodes.length} 个节点`);
        return uniqueNodes;
    },
    _traverseSystemWindows: function (targetTexts, options) {
        targetTexts = Array.isArray(targetTexts) ? targetTexts : [targetTexts];
        const { viewId = null, viewPath = null, matchMode = this.MatchMode.CONTAINS } = options;
        const nodes = [];
        const allNodes = BaseUtils.collectAllVisibleNodes(options);
        let matchedNode;

        if (viewId) {
            console.verbose(`[NodeFind] 通过 viewId:${viewId} 查找节点`);
            matchedNode = allNodes.find(node => node.getViewIdResourceName() === viewId);
            if (matchedNode) {
                console.log(`✅ viewId匹配成功：${viewId}`);
                return [matchedNode];
            }
        }

        if (viewPath) {
            console.verbose(`[NodeFind] 通过 viewPath:${viewPath} 查找节点`);
            matchedNode = allNodes.find(node => {
                let xpath = BaseUtils.getFullViewPath(node);
                return xpath && xpath.endsWith(viewPath);
            });
            if (matchedNode) {
                console.log(`✅ viewPath匹配成功：${viewPath}`);
                return [matchedNode];
            }
        }

        // 2. 文本匹配兜底
        allNodes.forEach(node => {
            if (targetTexts == null) {
                console.log(`参数错误 targetTexts为空，直接返回`);
                return;
            }

            let text = node.getText();
            let desc = node.getContentDescription();

            for (let target of targetTexts) {
                let isMatch = false;
                if (matchMode === this.MatchMode.EQUALS) {
                    isMatch = (text !== null && text !== undefined && text.toString() === target)
                           || (desc !== null && desc !== undefined && desc.toString() === target);
                } else { // 默认为 'contains'
                    isMatch = (text !== null && text !== undefined && text.toString().includes(target))
                           || (desc !== null && desc !== undefined && desc.toString().includes(target));
                }

                if (isMatch) {
                    if (!BaseUtils.filterByBounds(node, options)) {
                        console.verbose(`[边界过滤] 节点 text:${text} desc:${desc} 超出限制区域,进行排除`);
                        continue;
                    }
                    console.log(`✅ 文本匹配成功 (模式: ${matchMode}) text:${text}  desc:${desc}`);
                    nodes.push(node);
                    return; // 找到匹配项后，跳出内层循环，处理下一个节点
                }
            }
        });

        return nodes;
    },

    /**
     * 滚动查找任意目标文本
     * 配置项:
     * - each_distance: 单次滚动比例 (默认0.3)
     * - max_scroll_times: 最大滚动次数 (默认10)
     * - direction: 滚动方向 (默认UP)
     * - scroll_start_pos: 起始位置比例 (默认[0.5,0.5])
     * - continueOnError: 未找到时是否抛出异常 (默认false)
     */
    scrollUntilFindAnyTargetText: function (targetTexts, options = {}) {//支持多文本输入
        const {
            each_distance = 0.3,
            max_scroll_times = 10,
            direction = BaseUtils.DirectionType.UP,
            scroll_start_pos = [0.5, 0.5],
            continueOnError = true,
            onScroll = null//回调函数
        } = options;
        console.info(`[ScrollSearch] 开始搜索目标文本 "${targetTexts}"，配置：${JSON.stringify(options)}`);
        // 失败统计
        let scrollCount = 0;

        while (scrollCount < max_scroll_times) {
            console.verbose(`[ScrollSearch] 第 ${scrollCount + 1}/${max_scroll_times} 次查找`);
            // 执行滚动后回调,先回调给外部，在找文本，避免内部找到文本直接结束了
            if (typeof onScroll === 'function') {
                try {
                    onScroll({
                        currentScroll: scrollCount + 1,   // 当前已滚动次数
                        maxScrollTimes: max_scroll_times, // 最大允许滚动次数
                        direction: direction,        // 当前滚动方向
                        searchText: targetTexts       // 要查找的目标文本
                    });
                } catch (e) {
                    console.error(`滚动回调执行出错: ${e}`);
                }
            }
            var modifiedOptions = Object.assign({}, options, {
                continueOnError: true,//轮询查找中的，单次查找不抛异常
                timeout: 1000,//和外部超时时间不一致
            });
            let success = false;
            if (Array.isArray(targetTexts)) {
                let results = this.findAnyTargetText(targetTexts, modifiedOptions);
                success = results && results.length > 0;
            } else {
                let result = this.findText(targetTexts, modifiedOptions);
                success = result != null;
            }


            if (success) {
                console.log(`✅ 在第 ${scrollCount + 1} 次滚动后找到目标文本 "${targetTexts}"`);
                return true
            }

            // 执行滚动操作
            BaseUtils.scroll(direction, {
                eachDistance: each_distance,
                scrollTimes: 1,
                scrollStartPos: scroll_start_pos,
                interval: 800 // 固定间隔确保内容加载
            });

            scrollCount++;

            sleep(1000); // 等待内容稳定
        }

        // 达到最大滚动次数处理
        const errorMsg = `滚动 ${max_scroll_times} 次后仍未找到目标文本 "${targetTexts}"`;
        console.error(errorMsg);
        if (!continueOnError) throw new Error(errorMsg);
        return false;
    },

    // 改造后的查找任意目标文本方法
    findAnyTargetText: function (targetTexts, options) {
        options = options || {};
        var timeout = options.timeout;
        delete options.timeout; // 移除超时参数
        print(`[ScrollSearch] 使用 findAnyTargetText 查找目标文本 "${targetTexts}"，timeout：${timeout}`);
        // 创建新对象合并参数
        var modifiedOptions = Object.assign({}, options, {
            continueOnError: true//轮询查找中的，单次查找不抛异常
        });

        //说明：无论是点击文本还是输入文字，都是先找到文本，然后再操作，所以统一在这里超时轮询逻辑即可
        const foundResult = BaseUtils._waitUntilFound(function () {
            const results = this.findAllByTexts(targetTexts, modifiedOptions);
            // 如果 results 是一个空数组，返回 null 以便 _waitUntilFound 继续轮询
            if (results && results.length > 0) {
                return results;
            }
            return null;
        }.bind(this), {
            timeout: timeout,
            interval: options.interval,
            continueOnError: options.continueOnError
        });

        // 如果 _waitUntilFound 超时返回 null，则返回一个空数组以保持向后兼容
        return foundResult || [];
    },

    // 新增：点击任意目标文本方法
    clickAnyTargetText: function (targetTexts, options = {}) {
        console.info(`[ClickAnyTargetText] 开始尝试点击多个目标文本中的任意一个，共 ${Array.isArray(targetTexts) ? targetTexts.length : 1} 个文本`);
        
        // 确保targetTexts是数组
        if (!Array.isArray(targetTexts)) {
            targetTexts = [targetTexts];
        }
        
        // 使用findAnyTargetText查找任意匹配的文本
        const results = this.findAnyTargetText(targetTexts, Object.assign({}, options, {
            continueOnError: true
        }));
        
        if (results && results.length > 0) {
            const result = results[0]; // 使用第一个匹配结果
            console.log(`[clickAnyTargetText] 找到并点击目标文本: ${result.label}`);
            
            if (result.node) {
                const rect = new android.graphics.Rect();
                result.node.getBoundsInScreen(rect);
                console.log(`[clickAnyTargetText] 获取最新Node节点点击坐标 (${rect.centerX()},${rect.centerY()}),原坐标(${result.centerX},${result.centerY})`);
                click(rect.centerX(), rect.centerY());
            } else {
                console.log(`[clickAnyTargetText] OCR 点击相对坐标 (${result.relative.x},${result.relative.y}),原坐标(${result.centerX},${result.centerY})`);
                click(result.centerX, result.centerY);
            }
            
            sleep(result.node ? 2000 : 500);
            return true;
        }
        
        // 如果没找到任何匹配的文本
        const errorMsg = `[clickAnyTargetText] 未找到任何目标文本，共尝试了 ${targetTexts.length} 个文本`;
        console.warn(errorMsg);
        BaseUtils._onError(errorMsg, options);
        return false;
    },

    // 新增：粘贴文本方法（从inputText中抽取）
    pasteText: function (text, options = {}) {
        const { continueOnError = false } = options;
        
        console.log(`📋 [pasteText] 开始粘贴文本: "${text}"`);
        
        // 设置剪贴板内容
        setClip(text);
        console.log(`📋 已设置剪贴板内容: "${text}"`);
        
        // 查找粘贴按钮
        const allPastResults = this.findAnyTargetText(["粘贴", "Paste"], Object.assign({}, options, {
            continueOnError: true
        }));
        
        if (allPastResults && allPastResults.length > 0) {
            let textResult = allPastResults.find(result => result.style === "text");

            if (textResult) {
                console.log("准备点击匹配的结果 text命中优先:", textResult.label);
            } else {
                textResult = allPastResults[0];
                console.log("准备点击匹配的结果（其他）:", textResult.label);
            }

            if (textResult.rect) {
                console.log("尝试使用起始点坐标，点击粘贴");
                click(textResult.rect.left + BaseUtils.dpToPx(3), textResult.centerY);
            } else {
                console.log("尝试使用中心点坐标，点击粘贴");
                click(textResult.centerX - BaseUtils.dpToPx(5), textResult.centerY);
            }
            
            console.log(`✅ [pasteText] 粘贴操作完成`);
            return true;
        } else {
            const errorMsg = `[pasteText] 找不到粘贴/Paste按钮`;
            console.error(errorMsg);
            BaseUtils._onError(errorMsg, options);
            return false;
        }
    },

};

module.exports = TextUtils; 