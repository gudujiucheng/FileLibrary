const coreApi = require('../api/core_api.js');

const TaskUtils = {
    // 私有状态封装
    _state: {
        stats: {},
        queue: [],
        currentUserId: null,
        startTime: Date.now()
    },

    /**
     * 获取用户特定的配置
     * @param {number} userId 用户ID
     * @returns {object} 用户配置对象
     */
    _getUserConfig: function (userId) {
        console.log(`[DEBUG] 开始获取用户 ${userId} 的配置`);
        console.log(`[DEBUG] 用户ID类型: ${typeof userId}`);
        console.log(`[DEBUG] 用户ID值: ${userId}`);

        // 从manager获取用户配置
        // const manager = com.tencent.assistant.TaskExecutorManager.getInstance();
        // const userConfig = manager.getUserConfig(userId);
        //
        // if (userConfig) {
        //     return userConfig;
        // }

        // 如果没有从manager获取到配置，返回默认配置
        // 这里可以根据不同的userId返回不同的默认配置
        const defaultConfigs = {
        };

        console.log(`[DEBUG] 默认配置列表: ${JSON.stringify(Object.keys(defaultConfigs))}`);
        console.log(`[DEBUG] 用户 ${userId} 的默认配置: ${JSON.stringify(defaultConfigs[userId])}`);

        // 尝试转换用户ID为数字
        const numericUserId = Number(userId);
        console.log(`[DEBUG] 转换后的用户ID类型: ${typeof numericUserId}`);
        console.log(`[DEBUG] 转换后的用户ID值: ${numericUserId}`);

        const config = defaultConfigs[numericUserId] || {
            needAdd: [],
            noRecommend: []
        };

        console.log(`[DEBUG] 最终返回的配置: ${JSON.stringify(config)}`);
        return config;
    },

    /**
     * 发送消息到企业微信机器人
     * @param {string} content 消息内容
     */
    sendToBot: function (content) {
        let finalContent = `${device.brand} ${device.model} ${device.androidId} 安卓版本：${device.release}\n\n${content}`;
        let webhookUrl = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=51cbbe39-892f-4bdb-bb73-ce874578b873";

        let payload = {
            msgtype: "markdown",
            markdown: {
                content: finalContent.replace(/\n/g, '\n\n')
            }
        };

        // 调试输出
        console.log("准备发送的数据:", JSON.stringify(payload, null, 2));

        // 增强型请求
        let response = http.postJson(webhookUrl, payload, {
            headers: {
                'Content-Type': 'application/json; charset=utf-8'
            },
            timeout: 10000,
            ignoreSSL: true
        });
        if (response && response.statusCode === 200) {
            let result = response.body.json();
            console.log("企微API响应:", JSON.stringify(result, null, 2));

            if (result.errcode === 0) {
                console.log("✅ 报告已成功发送至企微机器人");
            } else {
                throw new Error(`API错误: [${result.errcode}] ${result.errmsg}`);
            }
        } else {
            let status = response ? response.statusCode : "无响应";
            throw new Error(`HTTP异常状态码: ${status}`);
        }
    },

    /**
     * 任务执行器
     * @param {object} config 任务配置
     * @returns {object} 任务执行器对象
     */
    task: function (config) {
        const manager = com.tencent.assistant.TaskExecutorManager.getInstance();

        // 初始化统计系统
        (function init() {
            config.userIds = manager.getTargetUserIds();
            // config.userIds = [16];//

            //转换类型
            if (!Array.isArray(config.userIds)) {
                const userIdArray = Array.from(config.userIds);
                config.userIds = userIdArray;
            }
            if (config.userIds.length === 0) {
                throw new Error("❌ 参数异常：userIds必须是非空数组，请检查配置");
            }

            console.log("🚀 任务开始执行，目标账户：" + config.userIds);

            //等待辅助服务开启 & 申请录屏权限 & 尝试自动授予录屏权限
            TaskUtils._cleanupMulProcess();
            auto.waitFor()//如果辅助服务未启动  会在在无障碍服务启动后继续运行.
            //部分手机可能不管用（有些系统隐藏了控件），不管用的时候，就需要手动点击一下
            console.log("版本号device.sdkInt：", device.sdkInt)
            if (device.sdkInt > 28) {
                //子线程并行执行任务，等待截屏权限申请并同意
                threads.start(function () {
                    packageName('com.android.systemui').text('立即开始').waitFor();
                    text('立即开始').click();
                });
            }
            requestScreenCapture();
            // 初始化统计数据
            config.userIds.forEach(userId => {
                TaskUtils._state.stats[userId] = {
                    attempts: 0,
                    isNeedRetry: true,
                    description: "",
                    success: false,
                    noTarget: false,
                    otherInfo: new Map(),
                    errors: []
                };
            });
        })();

        /**
         * 生成任务报告内容
         * @returns {string} Markdown格式的报告内容
         */
        function _generateReportContent() {
            // 如果外部脚本提供了自定义报告生成器，则使用它
            if (config.customReportGenerator && typeof config.customReportGenerator === 'function') {
                console.log('🔄 使用外部自定义报告生成器');
                try {
                    return config.customReportGenerator({
                        stats: TaskUtils._state.stats,
                        userIds: config.userIds,
                        startTime: TaskUtils._state.startTime,
                        formatMap: TaskUtils.formatMap
                    });
                } catch (error) {
                    console.error('❌ 自定义报告生成器执行失败，回退到默认报告:', error.message);
                    // 如果自定义报告生成器出错，回退到默认报告
                }
            }
            
            // 默认报告生成逻辑
            console.log('📋 使用默认报告生成器');
            return _generateDefaultReportContent();
        }

        /**
         * 生成默认的任务报告内容
         * @returns {string} Markdown格式的报告内容
         */
        function _generateDefaultReportContent() {
            let totalUsers = config.userIds.length;
            let successCount = Object.values(TaskUtils._state.stats).filter(s => s.success).length;
            let noTaskCount = Object.values(TaskUtils._state.stats).filter(s => s.noTarget).length;
            let successRate = (successCount / totalUsers * 100).toFixed(2);

            let mdContent = `## ⚡️ 企微任务执行报告\n\n`;
            mdContent += `**总用户数:** ${totalUsers}\n`;
            mdContent += `**用户列表:** ${config.userIds}\n`;
            mdContent += `**成功数:** ${successCount}（含无任务用户${noTaskCount}个）\n`;
            mdContent += `**成功率:** ${successRate}%\n\n`;
            const userIds = Object.keys(TaskUtils._state.stats);
            if (successCount === totalUsers) {
                mdContent += `**执行结果:** 全部成功\n\n`;
            } else {
                mdContent += `### 📊 失败明细\n`;
                userIds.forEach(userId => {
                    let stat = TaskUtils._state.stats[userId.toString()];
                    console.log("stat:", stat);
                    if (!stat.success) {
                        let errors = stat.errors.map(e => `\n${e}`).join('') || "无";
                        mdContent += `**用户ID:** \`${userId}\` \`${TaskUtils.formatMap(stat.otherInfo)}\` `;
                        mdContent += `**执行次数:** ${stat.attempts + 1}次 `;
                        mdContent += `**错误描述:** ${errors}\n\n`;
                    }
                });
            }
            let isHasAppendNoTargetDesc = false;
            userIds.forEach(userId => {
                let stat = TaskUtils._state.stats[userId.toString()];
                if (stat.noTarget) {
                    if (!isHasAppendNoTargetDesc) {
                        mdContent += "### 📊 未发现需要执行的任务\n";
                        isHasAppendNoTargetDesc = true;
                    }
                    mdContent += `>用户ID: \`${userId}\`  ${TaskUtils.formatMap(stat.otherInfo)}未发现可执行的任务\n`;
                }
            });
            mdContent += `**完成时间:** ${new Date().toLocaleString()},累计耗时${((Date.now() - TaskUtils._state.startTime) / 1000).toFixed(2)}秒\n`;
            return mdContent;
        }

        return {
            execute: function (businessLogic) {
                try {
                    TaskUtils._state.queue = config.userIds.slice();

                    while (TaskUtils._state.queue.length) {
                        TaskUtils._state.currentUserId = TaskUtils._state.queue.shift();
                        let userStat = TaskUtils._state.stats[TaskUtils._state.currentUserId];
                        manager.updateChildTaskStatus(TaskUtils._state.currentUserId, String(userStat.otherInfo.get("name") || ""),
                            com.tencent.assistant.model.ChildTaskStatus.RUNNING,
                            userStat.attempts,
                            "任务执行中");

                        try {
                            TaskUtils._launchMulApp(TaskUtils._state.currentUserId, userStat, config);
                            businessLogic(TaskUtils._state.currentUserId, userStat, TaskUtils._getUserConfig(TaskUtils._state.currentUserId));
                            var errorMsg = `✅ 用户${TaskUtils._state.currentUserId} 任务执行结果：${userStat.description}`;
                            console.log(errorMsg);
                            var status = userStat.noTarget ?
                                com.tencent.assistant.model.ChildTaskStatus.NO_TASK :
                                com.tencent.assistant.model.ChildTaskStatus.SUCCESS;
                            manager.updateChildTaskStatus(TaskUtils._state.currentUserId, String(userStat.otherInfo.get("name") || ""),
                                status,
                                userStat.attempts + 1,
                                errorMsg);
                        } catch (e) {
                            TaskUtils._handleTaskError(e, userStat, config, manager);
                        } finally {
                            TaskUtils._cleanupMulProcess();
                        }
                    }
                    manager.onTaskCompleted();
                    // 发送报告到企微机器人
                    TaskUtils.sendToBot(_generateReportContent());
                    engines.myEngine().forceStop();
                } catch (e) {
                    TaskUtils.sendToBot(`❌ 任务执行异常: ${e.message}`);
                    engines.myEngine().forceStop();
                }
            }
        };
    },

    /**
     * 清理多开的进程
     */
    _cleanupMulProcess: function () {
        console.log(`🧹 清理多开进程,当前用户：${TaskUtils._state.currentUserId}`);
        app.startActivity({
            packageName: "com.tencent.mulapp",
            className: "com.tencent.da.AdbCommandActivity",
            extras: {cmd: "killAll"}
        });
        sleep(3000);
    },

    /**
     * 启动多开应用
     * @param {string} userId 用户ID
     * @param {object} userStat 用户状态
     * @param {object} config 配置信息
     */
    _launchMulApp: function (userId, userStat, config) {
        app.startActivity({
            packageName: "com.tencent.mulapp",
            className: "com.tencent.da.AdbCommandActivity",
            extras: {
                cmd: "start",
                userId: userId.toString(),
                packageName: config.packageName,
                activityName: config.activityName
            }
        });

        let checkCount = 0;
        while (checkCount++ < 10) {
            let current = currentActivity();
            console.log(`当前Activity: ${current}`);
            // 检查是否在未登录页面集合中
            if (config.unLoginPages && config.unLoginPages.some(page => current.includes(page))) {
                //没有登录态的不用重试
                userStat.isNeedRetry = false;
                throw new Error("用户未登录 [页面校验]");
            }
            if (config.unLoginTexts) {
                let unLoginInfoResult = coreApi.findAllByTexts(config.unLoginTexts);
                if (unLoginInfoResult && unLoginInfoResult.length > 0) {
                    //没有登录态的不用重试
                    userStat.attempts = config.maxRetries
                    throw new Error("用户未登录 [文本校验]");
                }
            }

            if (config.targetPages && config.targetPages.some(page => current.includes(page))) {
                console.log(`✅ 用户 ${userId} 已成功启动 [页面校验]`);
                return;
            }
            if (config.targetTexts) {
                let successInfoResult = coreApi.findAllByTexts(config.targetTexts);
                if (successInfoResult && successInfoResult.length > 0) {
                    console.log(`✅ 用户 ${userId} 已成功启动 [文本校验]`);
                    return;
                }
            }

            sleep(1000);
        }
        throw new Error("应用启动超时");
    },

    /**
     * 处理任务错误
     * @param {Error} error 错误对象
     * @param {object} userStat 用户状态
     * @param {object} config 配置信息
     * @param {object} manager 任务管理器
     */
    _handleTaskError: function (error, userStat, config, manager) {
        // 错误信息标准化处理
        let errorMessage = (error instanceof Error ? error.message : String(error)).replace(/\n/g, ' ');

        // 获取完整的堆栈信息（兼容非Error对象的情况）
        let fullStack = (error instanceof Error && error.stack)
            ? error.stack
            : `Non-Error Object: ${JSON.stringify(error)}`;

        // 增强的错误日志输出
        console.log([
            `❌ 用户 ${TaskUtils._state.currentUserId} 失败:`,
            `┌ 错误类型: ${error.name || 'UnknownError'}`,
            `├ 错误信息: ${errorMessage}`,
            `└ 堆栈跟踪:`
        ].join('\n'));

        // 格式化输出堆栈信息（保留原始换行格式）
        fullStack.split('\n').forEach((line, index) => {
            console.log(`   ${index === 0 ? '└─' : '   '} ${line}`);
        });

        // 记录用户错误统计（保留原始格式）
        var errorMsg = `>第${userStat.attempts + 1}次: [${error.name || 'Error'}] ${errorMessage}`;
        userStat.errors.push(errorMsg);
        manager.updateChildTaskStatus(TaskUtils._state.currentUserId, String(userStat.otherInfo.get("name") || ""),
            com.tencent.assistant.model.ChildTaskStatus.FAILED,
            userStat.attempts + 1,
            errorMsg);

        // 带指数退避的重试机制
        if (userStat.isNeedRetry && userStat.attempts < config.maxRetries) {
            userStat.attempts++;
            console.log(`↩️ 用户 ${TaskUtils._state.currentUserId},任务失败，加入重试队列`);
            TaskUtils._state.queue.push(TaskUtils._state.currentUserId);
        }
    },

    /**
     * 格式化Map对象为字符串
     * @param {Map} map Map对象
     * @returns {string} 格式化后的字符串
     */
    formatMap: function (map) {
        if (!map || !(map instanceof Map)) {
            return '';
        }
        return Array.from(map.entries())
            .map(([key, value]) => `${key}=${value}`)
            .join(' ');
    }
};

module.exports = TaskUtils; 