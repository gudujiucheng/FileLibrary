// 导入 Tool 类
var tools = require('./api/core_api.js');
const textUtils = require('./utils/text_utils');
var directionType = tools.DirectionType;
const preStr = "暗区突围手游";
const checkPrefixs = ["暗区突围手游", "暗区突", "手游", "区突围"];
const outputFilePath = context.getFilesDir() + "/ai_responses.txt";
let { length, filtered } = getNeedRunQuestion();
if (filtered.length === 0) {
    onCompleted(`${length}个问题已经处理完毕,请点击case_share_wechat_ask_ai_result任务分享结果`);
}
auto.waitFor()
requestScreenCapture();
var retryCount = 0;
while (retryCount++ < 6) {
    //为了避免微信卡死，每次执行前都结束微信进程
    if (retryCount > 1) {
        killApp("com.tencent.mm");
    }
    sleep(7000);
    try {
        let { filtered } = getNeedRunQuestion();
        console.log("待处理问题:", filtered);
        if (filtered.length === 0) {
            break;
        }
        launchWechat();
        sleep(5000);
        checkMainPage();
        clickSearch();
        clickAISearch();
        let index = 0;
        filtered.forEach(question => {
            pasteQuestion(question);
            sleep(1500);
            waitAnswer();
            let isFindReference = scrollToPageBottomAndFindRefrence();
            if (!isFindReference) {
                console.log("没有找到参考资料，尝试继续走流程");
            }
            console.log("-------------向下滑动，找到相关问题------------");
            //展开之后要继续向下滚动一下，找到相关问题
            tools.scrollUntilFindAnyTargetText(["相关问题", "切换模型", "回答于"], {
                max_scroll_times: 7,
                continueOnError: true,
                each_distance: 0.1,
                isFindByNode: false,
                limit_x: [0, 0.4],
                matchMode: textUtils.MatchMode.EQUALS
            });
            sleep(3000);
            //获取节点
            let webNode = className("android.webkit.WebView").findOne();
            if (webNode == null) {
                throw new Error("没有找到WebView节点");
            }
            let allChildren = tools.getAllChildren(webNode);
            let currentTime = new Date().toLocaleString();
            // 创建要写入的内容
            let content = `\n\n=== 问题：${question} ===\n获取时间：[${currentTime}]\n\n`;
            let lastTop = -1;
            allChildren.forEach(node => {
                let text = node.getText() || node.getContentDescription();
                if (text && text.toString().includes("服务繁忙")) {
                    console.log("服务繁忙，退出");
                    let successList = getSuccessQuestions();
                    tools.sendToBot("服务繁忙，退出执行,已处理问题数量：" + successList.size);
                    engines.myEngine().forceStop();

                }
                if (text && text.toString().trim().length != 0) {
                    let rect = new android.graphics.Rect();
                    node.getBoundsInScreen(rect);
                    if (rect.top == lastTop) {
                        content += text
                    } else {
                        content += text + "\n";
                    }
                    lastTop = rect.top;
                }

            });

            content += "\n";
            //更换文字 在滚动一次找到目标
            tools.scrollUntilFindAnyTargetText(["回答于", "相关问题", "切换模型"], {
                max_scroll_times: 7,
                continueOnError: true,
                each_distance: 0.1,
                isFindByNode: false,
                limit_x: [0, 0.8],
                matchMode: textUtils.MatchMode.EQUALS
            });
            sleep(3000);
            //依次点开参考资料（放到获取内容之后，避免影响内容获取）
            let referenceResult = getRefrencesLink();
            content += referenceResult;
            content += "\n";
            saveResult(content);
            const isLast = (index === filtered.length - 1);
            if (!isLast) {
                console.log("不是最后一个问题，尝试返回");
                checkAndReturnToAISearchPage();
            }
            index++;

        });
        let hasSuccessQuestions = getSuccessQuestions();
        let successCount = hasSuccessQuestions.size;
        onCompleted(`所有问题已处理完毕,累计成功处理 ${successCount} 个问题，请点击case_share_wechat_ask_ai_result任务分享结果`);
    } catch (e) {
        console.log("出现异常,继续重试中", e);
    }
}

function checkAndReturnToAISearchPage() {
    let retryCount = 0;
    while (retryCount < 3) {
        let pages = tools.findAnyTargetText(["提出你的问题", "你的问题", "问AI", "问A"], {
            limit_y: [0, 0.5], timeout: 2000, continueOnError: true
        });
        if (pages && pages.length > 0) {
            console.log(`页面正确，无需回退`);
            return;
        }
        console.log(`尝试回退到上一级页面 (第${retryCount + 1}次尝试)`);
        back();
        sleep(2000);
        retryCount++;
    }

    if (retryCount >= 3) {
        console.log(`连续${retryCount}次回退后仍未找到"AI搜索页面特征"，任务中断`);
        throw new Error(`连续${retryCount}次回退后仍未找到"AI搜索页面特征"，任务中断`);
    }
}

function enterAnswerPage() {
    tools.clickAnyTargetText(["问AI", "问A", "问", "AI"], { timeout: 6000, limit_x: [0.6, 1], limit_y: [0, 0.5] });
    let retryCount = 0;
    while (retryCount < 3) {
        let pages = tools.findAnyTargetText(["继续提问", "分析问题", "停止回答", "深度思考中"], {
            timeout: 3000, continueOnError: true
        });
        if (pages && pages.length > 0) {
            console.log(`页面正确，无需重新点击`);
            return;
        }
        console.log(`尝试再次点击ai搜索 (第${retryCount + 1}次尝试)`);
        tools.clickAnyTargetText(["问AI", "问A", "问", "AI"], { timeout: 6000, limit_x: [0.6, 1], limit_y: [0, 0.5] });
        sleep(2000);
        retryCount++;
    }

    if (retryCount >= 3) {
        console.log(`连续${retryCount}次回退后仍未找到"AI搜索页面特征"，任务中断`);
        throw new Error(`连续${retryCount}次回退后仍未找到"AI搜索页面特征"，任务中断`);
    }
}

if (retryCount >= 5) {
    tools.sendToBot(`❌ 问ai 任务执行异常, 重试次数超过${retryCount}次，退出,请稍后继续点击case_wechat_ask_ai任务重试`);
    console.log("重试次数超过5次，退出");
    engines.myEngine().forceStop();
}

function getRefrencesLink() {
    let nodes = tools.findAnyTargetText(["参考来源"], { limit_x: [0, 0.3], continueOnError: true, timeout: 3000 });
    let allTextNodes = null;
    let desc = null;
    if (nodes == null || nodes.length == 0) {
        let { topY, downY, upTarget } = getReferenceLimit();
        if (upTarget == null) {
            console.log("没有找到参考资料节点");
            allTextNodes = [];
        } else {
            desc = upTarget.label;
            allTextNodes = getAllTextsByOCR(topY, downY);
        }
    } else {
        console.log("====》》取第一个 参考来源", nodes[0]);
        allTextNodes = [nodes[0]];
    }

    if (allTextNodes == null || allTextNodes.length == 0) {
        console.log("没有找到参考资料内容节点");
        return "----没有找到参考资料内容节点----";
    }
    let linksResult = clickAllNode(allTextNodes);
    let referenceResult = `======++++参考资料开始(${desc})++++======\n`;
    if (linksResult != null && linksResult.length > 0) {
        linksResult.forEach((it) => {
            referenceResult += it + "\n";
        });
    }
    referenceResult += `======++++参考资料结束(${desc})++++======\n`;
    return referenceResult;
}

//---------------------------------以下为工具函数---------------------------------
function saveResult(content) {
    try {
        console.log("📝 回答内容：", content);
        // 追加写入文件
        files.append(outputFilePath, content);
        console.log(`已保存回答到：${outputFilePath}`);
    } catch (e) {
        console.error("文件写入失败：", e);
    }
}

function killApp(packageName) {
    app.launchSettings(packageName); // 打开应用设置页
    sleep(2000);
    // 查找并点击停止按钮（适配不同系统关键词）
    let result = tools.clickAnyTargetText(["强行停止", "结束运行", "停止"], { limit_y: [0.8, 1], continueOnError: true })
    if (result) {
        tools.clickText("确定", { limit_y: [0.8, 1], continueOnError: true })
    }
    sleep(1000);
}

// 新增文件读取函数（需放置在脚本开头）
function readQuestionsFromFile() {
    const filePath = files.join(engines.myEngine().cwd(), "./config/ai_questions.txt");
    console.log("📂 问题文件路径:", filePath);

    try {
        if (!files.exists(filePath)) {
            console.error("问题文件不存在，将使用内置问题");
            return [];
        }

        const content = files.read(filePath)
            .split("\n")
            .filter(line => {
                // 过滤注释和空行（支持#开头的注释）
                const trimmed = line.trim();
                return trimmed && !trimmed.startsWith("#");
            })
            .map(line => `${preStr}${line.trim()}`);

        console.log("📝 从文件读取到", content.length, "个有效问题");
        return content;
    } catch (e) {
        console.error("文件读取失败:", e);
        return [];
    }
}


function getSuccessQuestions() {
    const processed = new Set();
    try {
        if (files.exists(outputFilePath)) {
            const content = files.read(outputFilePath);
            // 使用正则匹配已处理问题 [2,6](@ref)
            const regex = /^=== 问题：(.*?) ===/gm;
            let match;
            while ((match = regex.exec(content)) !== null) {
                var question = match[1].trim();
                processed.add(question);
                console.log(`已处理过的问题：${question}`);
            }
        }
    } catch (e) {
        console.error("读取历史文件失败，将处理所有问题", e);
    }
    return processed;
}


function getNeedRunQuestion() {
    files.ensureDir(outputFilePath);
    let questions = readQuestionsFromFile();
    let questionsLength = questions.length; // 原始问题数量

    if (questionsLength === 0) {
        let msg = "没有读取到有效问题，请检查配置文件";
        console.log(msg);
        onCompleted(msg);
        return { length: 0, filtered: [] }; // 异常时返回空结构[7](@ref)
    }

    let hasSuccessQuestions = getSuccessQuestions();
    let filteredQuestions = questions.filter(q => !hasSuccessQuestions.has(q));

    // 返回对象包含两个参数
    return {
        length: questionsLength,  // 原问题总数
        filtered: filteredQuestions  // 过滤后问题列表
    };
}


function onCompleted(msg) {
    toast(msg);
    tools.sendToBot(msg);
    engines.myEngine().forceStop();
}

function launchWechat() {
    let intent = new Intent();
    intent.setClassName("com.tencent.mm", "com.tencent.mm.ui.LauncherUI");
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    context.startActivity(intent);
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    sleep(2000)
    // tools.clickText("微信", { limit_x: [0, 0.5], limit_y: [0.5, 1], continueOnError: true, timeout: 3000 });
}

function checkMainPage() {
    let i = 0;
    while (i < 10) {
        var current = currentActivity();
        console.log("当前页面: " + current);
        let target = tools.findAnyTargetText(["通讯", "发现", "通信录"], {
            limit_y: [0.8, 1], continueOnError: true, timeout: 2000,
        })
        if (target != null && target.length > 0) {
            launchSuccess = true;
            console.log("启动微信成功");
            //避免停留在个人主页，导致后续流程找不到搜索入口
            tools.clickAnyTargetText(["通讯", "发现", "通信录"], {
                limit_y: [0.8, 1], continueOnError: true, timeout: 2000,
            })
            return;
        }
        i++;
        sleep(1000);
        back();
    }
    console.log("启动微信失败");
    throw new Error("启动微信失败");
}

function clickSearch() {
    let isSuccess = tools.clickAnyImage(["./img/search.png", "./img/search_black.png"], {
        limit_x: [0.7, 0.9], limit_y: [0, 0.15], continueOnError: true, timeout: 5000
    });
    if (!isSuccess) {
        throw new Error("没有找到微信搜索按钮");
    }
}

function clickAISearch() {
    tools.clickAnyTargetText(["AI搜", "搜", "搜索", "AI", "A"],
        { limit_x: [0.3, 0.65], limit_y: [0.11, 0.9], timeout: 5000, continueOnError: true });
    sleep(5000);
    //增加下一级页面校验容错，避免跳转不了
    let checkResult = tools.findAnyTargetText(["提出你的问题", "出你的", "出你", "提出你", "的问题", "的问"],
        { limit_y: [0, 0.33], timeout: 15000, continueOnError: true, showDetailLog: true });
    if (checkResult == null || checkResult.length == 0) {
        console.log("没有找到提出你的输入框,继续尝试点击AI搜索");
        tools.clickAnyTargetText(["AI搜", "搜", "搜索", "AI", "A"], { limit_x: [0.35, 0.65], limit_y: [0.11, 0.9] });
    }
}

function pasteQuestion(question) {
    tools.clickAnyTargetText(["提出你的问题", "出你的", "出你", "提出你", "的问题"], {
        continueOnError: true,
        timeout: 4000
    });
    tools.inputText(["提出你的问题", "出你的", "出你", "提出你", "的问题"], question, {
        tryPos: [0.3, 0.2],
        continueOnError: true,
    });
    var checkResults = tools.findAnyTargetText(checkPrefixs, { continueOnError: true, timeout: 4000, limit_y: [0, 0.3] });
    console.log("校验是否复制成功", checkResults.length);
    var i = 0;
    while (checkResults.length === 0 && i < 4) {
        console.log("尝试粘贴问题");
        tools.inputText(["提出你的问题", "出你的", "提出你", "的问题"], question, { tryPos: [0.3, 0.2] });
        checkResults = tools.findAnyTargetText(checkPrefixs, { continueOnError: true, timeout: 2000, limit_y: [0, 0.3] });
        if (checkResults.length > 0) {
            break;
        }
        i++;
        sleep(1000);
    }
}

function waitAnswer() {
    enterAnswerPage();
    console.log("等待回答完成...");
    sleep(7000);
    //循环等待直到回答完毕
    let checkTimes = 0;
    while (true) {
        let hasAnswerOverResults = tools.findAnyTargetText(["继续提问", "继续", "提问", "问AI", "问A", "问", "AI"],
            { timeout: 2000, continueOnError: true, isFindByNode: false, limit_y: [0.85, 1] });

        // 如果找到目标文本或超限则退出循环
        if (hasAnswerOverResults.length > 0 || checkTimes > 30) {
            console.log(`检测到回答完成结束，结束条件： 检测次数${checkTimes} 次 ,或找到问答结束关键字`);
            break;
        }
        // 未找到目标文本则继续循环
        checkTimes++;
        sleep(1500);
    }
}

function scrollToPageBottomAndFindRefrence() {
    return tools.scrollUntilFindAnyTargetText(["考资", "参考资料", "篇参考", "参考来源", "参考来", "考来源", "相关问题", "切换模型", "搜更多"], {
        max_scroll_times: 30,
        each_distance: 0.3,
        scroll_start_pos: [0.5, 0.8],
        continueOnError: true,
        isFindByNode: false,
        limit_x: [0, 0.35],
        onScroll: ({ currentScroll, maxScrollTimes }) => {
            console.log(`-----已完成 ${currentScroll} 次滚动（共尝试 ${maxScrollTimes} 次）`);
            var hasRefrence = tools.findAnyTargetText(["考资", "参考资料", "篇参考"],
                { continueOnError: true, timeout: 1000, limit_x: [0, 0.4], isFindByNode: false });
            if (hasRefrence.length > 0) {
                console.log("发现参考资料，尝试展开");
                //网上在滑动滑动，避免被别的按钮遮挡
                tools.scrollUp({ eachDistance: 0.1 });
                sleep(2000);
                tools.clickAnyTargetText(["考资", "参考资料", "篇参考"], { timeout: 3000, limit_x: [0, 0.35], });
            } else {
                console.log("没有找到参考资料，尝试继续滚动");
            }
        }
    });
}

function getTitle() {
    let title = "";
    let node = tools.getNodeByViewId("activity-name", { limit_y: [0, 0.3], timeout: 4000, continueOnError: true });
    if (node) {
        title = node.label;
    } else {
        let results = tools.getAllHasTextNodes({ limit_y: [0.04, 0.2] });
        if (results) {
            results.forEach((it) => {
                title += `${it.label}|`;
            });
        }
    }
    if (title.length < 0) {
        title = "未获取到标题";
    }
    return title;
}

function clickAllNode(nodes) {
    if (nodes == null || nodes.length === 0) {
        console.log(`没有找到参考资料内容节点`);
        return null;
    }
    console.log(`点击参考资料开始，共${nodes.length}篇参考资料`);
    let links = [];
    try {
        nodes.forEach((it, index) => {
            console.log(`点击第 ${index + 1} 个 参考资料"} `, it);
            click(it.centerX, it.centerY);
            sleep(3000);
            let title = getTitle();
            let link = copyLink();
            let result = `标题：${title} 链接：${link}`;
            console.log(result);
            links.push(result);

            if (!returnToAISearchResultPage()) {
                console.log("点击参考资料异常，中断");
                links.push("后续链接获取失败：没有找到问AI按钮，可能是页面跳转失败");
                return links;
            }
        });
    } catch (e) {
        console.log("--------------------->>>>点击参考资料异常", e);
        links.push(`获取链接发生异常${e},中断获取`);
    }
    return links;
}

function returnToAISearchResultPage() {
    let i = 0;
    const maxRetries = 5;
    const targetTexts = ["相关问题", "切换模型", "AI搜索", "继续提问"];

    while (i < maxRetries) {
        let currentPage = tools.findAnyTargetText(targetTexts, {
            timeout: 2000,
            continueOnError: true,
            matchMode: textUtils.MatchMode.EQUALS
        });

        if (currentPage && currentPage.length > 0) {
            console.log("成功返回AI搜索页面");
            return true;
        }

        console.log(`尝试返回上一级页面 (第${i + 1}次)`);
        let result = tools.clickAnyImage(["./img/close_wechat_web.png"], {
            limit_y: [0, 0.1], limit_x: [0, 0.11], continueOnError: true, timeout: 3000
        })
        if (!result) {
            console.log("没有找到关闭按钮，尝试点击返回按钮");
            back();
        } else {
            console.log("点击关闭按钮成功");
        }
        sleep(2000);
        i++;
    }

    console.log(`连续${maxRetries}次尝试后仍无法返回AI搜索页面`);
    return false;
}

function launchWechatDefault() {
    launch("com.tencent.mm");
    sleep(2000)
    // tools.clickText("微信", { limit_x: [0, 0.5], limit_y: [0.5, 1], continueOnError: true, timeout: 3000 });
}

function copyLink() {
    setClip("");
    let clickMoreTimes = 0;
    let floatViews = null;
    while (clickMoreTimes < 3) {
        let clickResult = tools.clickText("更多", {
            limit_x: [0.6, 1], limit_y: [0, 0.1], timeout: 3000, continueOnError: true, isFindByNode: false
        });
        if (!clickResult) {
            console.log("没有找到更多按钮,尝试点击更多按钮图片");
            //尝试点击更多按钮
            clickResult = tools.clickAnyImage(["./img/ic_more.png", "./img/ic_more_mini.png", "./img/ic_more_mini_white.png"], {
                limit_x: [0.6, 1], limit_y: [0, 0.1], timeout: 2000, continueOnError: true
            });
        }
        sleep(1500);
        if (clickResult) {
            floatViews = tools.findAnyTargetText(["浮窗", "稍后听", "保存为图片", "听全文", "全文翻译", "查找页面内容"], {
                timeout: 2000,
                isFindByNode: false,
                continueOnError: true,
                limit_y: [0.7, 1]
            });
            if (floatViews && floatViews.length > 0) {
                console.log("检测到浮窗，点击更多成功");
                break;
            }
        }
        clickMoreTimes++;
    }
    if (clickMoreTimes >= 3 && (floatViews == null || floatViews.length == 0)) {
        console.log("点击更多失败");
        return "获取链接失败：复制失败，没有发现更多按钮（文本、图片、小程序）";
    }
    sleep(3000)
    console.log(`尝试滚动浮窗位置坐标Y:${floatViews[0].relative.y}`);
    tools.scrollUntilFindAnyTargetText(["复制", "链接", '制链', "制", "复"], {
        timeout: 5000,
        continueOnError: true,
        limit_y: [0.7, 1],
        isFindByNode: false,
        direction: directionType.LEFT,
        showDetailLog: true,
        scroll_start_pos: [0.5, parseFloat(floatViews[0].relative.y)]
    });

    sleep(3000);
    var result = tools.clickAnyTargetText(["复制", "链接", '制链', "制",], {
        timeout: 2000, limit_y: [0.7, 1], continueOnError: true, isFindByNode: false,
    });
    if (!result) {
        console.log("没有找到复制链接按钮,终止");
        return "获取链接失败：没有找到复制链接按钮";
    }
    sleep(1000);
    launch("com.tencent.gamehelper.accessibilityservice");
    sleep(3000);
    let clipboardText = getClip();
    if (clipboardText == null || clipboardText == undefined || clipboardText.length == 0) {
        console.log("剪贴板内容为空，尝试重新获取");
        sleep(2000);
        clipboardText = getClip();
    }
    console.log("剪贴板内容：", clipboardText);
    setClip("");
    launchWechatDefault();
    sleep(1000);
    return clipboardText;
}

function getAllTextsByOCR(topY, downY) {
    let allReferences = tools.getAllTextsByOcr({
        limit_y: [(topY / device.height).toFixed(3), (downY / device.height).toFixed(3)], limit_x: [0.1, 0.2],
    });
    allReferences.forEach((it, index) => {
        console.log(`区域文字  ${index + 1} ${it.label} ${it.relative.toString()}  `);
    });
    return allReferences;
}

function getReferenceLimit() {
    let upTarget = tools.findText("考资", { timeout: 1000, limit_x: [0, 0.35], continueOnError: true });
    if (upTarget == null) {
        return { topY: 0, downY: 0, upTarget: null };
    }
    click(upTarget.centerX, upTarget.centerY);
    let downTarget = tools.findText("相关问题", {
        timeout: 2000,
        continueOnError: true,
        limit_y: [upTarget.relative.y, 1],
        limit_x: [0, 0.4],
        matchMode: textUtils.MatchMode.EQUALS
    });
    if (downTarget == null) {
        downTarget = tools.findText("切换模型", { timeout: 2000, limit_x: [0, 0.4] });
    }
    let topY = upTarget.rect.bottom;
    let downY = downTarget.rect.top;
    console.log(`参考资料限制 topY:${topY} downY:${downY}`);
    return { topY, downY, upTarget };
}




