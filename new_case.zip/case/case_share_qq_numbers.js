const internalPath = context.getFilesDir() + "/qq_numbers.txt";
const file = new java.io.File(internalPath);

// 验证文件存在且可读
if (!file.exists() || !file.canRead()) {
    toast("文件不存在, 请先运行QQ号获取脚本：case_qq_get_recommend.js");
    exit();
} else {
    console.log("文件存在", file);
}

// 生成URI
const uri = androidx.core.content.FileProvider.getUriForFile(
    context,
    context.getPackageName() + ".fileprovider",
    file
);

// 授权读取权限
context.grantUriPermission(
    "com.tencent.mm",  // 微信包名
    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
);

const sendIntent = new Intent()
    .setAction(Intent.ACTION_SEND)
    .setType("text/plain")
    .putExtra(Intent.EXTRA_STREAM, uri)
    .addFlags(
        Intent.FLAG_ACTIVITY_NEW_TASK |
        Intent.FLAG_GRANT_READ_URI_PERMISSION |
        Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
    );

// MIUI特殊处理
sendIntent.addFlags(0x00008000);

// 创建选择器
const chooser = Intent.createChooser(sendIntent, "分享QQ号列表");
chooser.addFlags(
    Intent.FLAG_ACTIVITY_CLEAR_TASK | 
    Intent.FLAG_ACTIVITY_NEW_TASK |
    Intent.FLAG_GRANT_READ_URI_PERMISSION |
    Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
);

try {
    context.startActivity(chooser);
} catch (e) {
    console.error("分享失败，重试一次", e);
    context.startActivity(chooser);
} 