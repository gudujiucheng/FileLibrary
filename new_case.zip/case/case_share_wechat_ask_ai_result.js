const internalPath = context.getFilesDir() + "/ai_responses.txt";
const file = new java.io.File(internalPath);

// 验证文件存在且可读
if (!file.exists() || !file.canRead()) {
    toast("文件不存在, 请先运行AI问答脚本：case_wechat_ask_ai.js");
    exit();
} else {
    console.log("文件存在", file);
}

// 生成URI
const uri = androidx.core.content.FileProvider.getUriForFile(
    context,
    context.getPackageName() + ".fileprovider",
    file
);



context.grantUriPermission(
    "com.tencent.mm",  // 这里填微信包名
    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
)

const sendIntent = new Intent()
    .setAction(Intent.ACTION_SEND)
    .setType("text/plain") // 通配符类型更易触发系统级处理[2,6](@ref)
    .putExtra(Intent.EXTRA_STREAM, uri)
    .addFlags(
        Intent.FLAG_ACTIVITY_NEW_TASK |
        Intent.FLAG_GRANT_READ_URI_PERMISSION |
        Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
        Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION // 持久化权限[3](@ref)
    );
// MIUI特殊处理：添加0x00008000标志位
sendIntent.addFlags(0x00008000);
// // 强制显示所有可选项
const chooser = Intent.createChooser(sendIntent, "分享到");
chooser.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK |
    Intent.FLAG_GRANT_READ_URI_PERMISSION |
    Intent.FLAG_GRANT_WRITE_URI_PERMISSION |
    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);

try {
    context.startActivity(chooser);
} catch (e) {

    context.startActivity(chooser);
}