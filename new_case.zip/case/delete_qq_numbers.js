function deleteQQNumbersFile() {
    const outputFilePath = context.getFilesDir() + "/qq_numbers.txt";

    try {
        if (files.exists(outputFilePath)) {
            files.remove(outputFilePath);
            var msg = "🗑️ QQ号文件删除成功";
            console.log(msg);
            toast(msg);
            return true;
        }
        var err = "⚠️ QQ号文件不存在，无需删除";
        console.log(err);
        toast(err);
        return false;
    } catch (e) {
        var exception = "❌ 删除失败: " + e.message;
        console.error("删除失败:", e);
        toast(exception);
        return false;
    }
}

deleteQQNumbersFile(); 