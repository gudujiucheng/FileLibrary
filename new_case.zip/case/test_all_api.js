var core = require('./api/core_api.js');
const tools = require("./api/core_api");
var directionType = tools.DirectionType;
auto.waitFor()
requestScreenCapture();
//拉起企业微信到前台
console.log("正在拉起企业微信...");
app.startActivity({
        packageName: "com.tencent.wework",
        className: "com.tencent.wework.launch.LaunchSplashActivity"
    });
sleep(3000);
console.log("企业微信启动完成");

//先尝试点击今天发布的第一条
top = core.findText("发表到客户的朋友圈")
console.log(top)
results = core.getAllHasTextNodes({ limit_x: [0.2, 1], limit_y: [top.relative.y, 1] })
if (results && results.length > 0) {
    //点击y坐标最小的那个
    console.log("找到节点数量:" + results.length)

    // 按y坐标排序，找到最上方的节点
    results.sort((a, b) => a.centerY - b.centerY);

    // 获取y坐标最小的节点
    let firstNode = results[0];
    console.log("点击坐标：" + firstNode.relative.x + ", " + firstNode.relative.y);
    if (firstNode.relative.y - top.relative.y > 0.1) {
        console.log("首个有文本的内容间距过大，所以最新一条评论可能是图片，尝试直接点击偏移位置");
        click(top.centerX, top.centerY + 0.1 * device.height);
    } else {
        console.log("点击最新一条动态");
        click(firstNode.centerX, firstNode.centerY);
    }
} else {
    console.log("未找到符合条件的节点,尝试点击坐标偏移");
    core.clickText("发表到客户的朋友圈",{offset: [0, 0.07],})
}
core.clickText("评论", {
    limit_x: [0, 0.2],
    limit_y: [0.8, 1],
});
core.inputText("说点什么吧", "测试自动化脚本",{
    limit_x: [0, 0.6],
});

core.clickAnyImage(["./img/send_comment.png"], {
    limit_x: [0.8, 1],
    limit_y: [0.4, 1],
    timeout: 2000
});


