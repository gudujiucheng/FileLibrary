// var tools = require('./api/core_api.js');
// var directionType = tools.DirectionType;
// auto.waitFor()
// requestScreenCapture();
// sleep(3000);

// let clickMoreResult = tools.clickImage("./img/test_img.png", {
//     limit_x: [0.7, 1], limit_y: [0, 0.1],
//     timeout: 5000, continueOnError: true, gray: true,
// });
// console.log("点击更多结果", clickMoreResult);


// let clickMoreResult = tools.clickAnyImage(["./img/test_search.png","./img/test_img.png"], {
//     limit_x: [0.7, 1], limit_y: [0, 0.1],
//     timeout: 5000, continueOnError: true, gray: true,
// });
// console.log("点击更多结果", clickMoreResult);


// back();

//测试文本能力
// tools.clickText("文档",{ isFindByNode: true,})
// tools.clickText("文档",{ isFindByNode: false,})
// result = tools.getAllTextsByOcr()
// console.log("getAllTextsByOcr result",result)    
// resluts = tools.findAnyTargetText(["文档","任务","文件"])
// console.log("findAnyTargetText result",resluts)
// resluts = tools.scrollUntilFindAnyTargetText(["通常每个章节","对象本身"])
// console.log("scrollUntilFindAnyTargetText result",resluts)
// result = tools.clickAnyTargetText(["文档","任务","文件"])
// console.log("clickAnyTargetText result",result)
// tools.inputText("搜索","case",{
//     limit_x: [0, 0.5], limit_y: [0, 0.2],
//     timeout: 5000
// })

console.log("device.width",device.width)
console.log("device.height",device.height)
press(0.5 * device.width, 0.95 * device.height, 2000);