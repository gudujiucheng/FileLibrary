const BaseUtils = require('../utils/base_utils');
const ImageUtils = require('../utils/image_utils');
const TextUtils = require('../utils/text_utils');
const TaskUtils = require('../utils/task_utils.js');

const Tool = {
    // Constants
    DirectionType: BaseUtils.DirectionType,
    MatchMode: TextUtils.MatchMode,
    dpToPx: function (dp) {
        return BaseUtils.dpToPx(dp);
    },
    spToPx: function (sp) {
        return BaseUtils.spToPx(sp);
    },
    getFormattedDate: function (date) {
        return BaseUtils.getFormattedDate(date);
    },
    // Image utilities
    clickImage: function (imagePath, options) {
        return ImageUtils.clickImage(imagePath, options);
    },

    findImage: function (imagePath, options) {
        return ImageUtils.findImage(imagePath, options);
    },

    findImages: function (imagePaths, options) {
        return ImageUtils.findImages(imagePaths, options);
    },

    findAllImgListByCV: function (imagePath, options) {
        return ImageUtils.findAllImgListByCV(imagePath, options);
    },

    // Click any image from multiple paths
    clickAnyImage: function (templatePaths, options) {
        return ImageUtils.clickAnyImage(templatePaths, options);
    },

    // Text utilities
    getAllHasTextNodes: function (options) {
        return TextUtils.getAllHasTextNodes(options);
    },

    getNodeByViewId: function (viewId, options) {
        return BaseUtils.getNodeByViewId(viewId, options);
    },

    clickByViewId: function (viewId, options) {
        return BaseUtils.clickByViewId(viewId, options);
    },

    getAllNodesByViewId: function (viewId, options) {
        return BaseUtils.getAllNodesByViewId(viewId, options);
    },

    getAllTextsByOcr: function (options) {
        return TextUtils.getAllTextsByOcr(options);
    },

    // 显示OCR结果弹窗
    showOcrResultsDialog: function (ocrResults, options) {
        return TextUtils.showOcrResultsDialog(ocrResults, options);
    },

    findText: function (text, options) {
        return TextUtils.findText(text, options);
    },

    findAllByTexts: function (targetTexts, options) {
        return TextUtils.findAllByTexts(targetTexts, options);
    },

    clickText: function (text, options) {
        return TextUtils.clickText(text, options);
    },

    inputText: function (targetClickText, inputText, options) {
        return TextUtils.inputText(targetClickText, inputText, options);
    },

    // New text utilities
    scrollUntilFindAnyTargetText: function (targetTexts, options) {
        return TextUtils.scrollUntilFindAnyTargetText(targetTexts, options);
    },

    findAnyTargetText: function (targetTexts, options) {
        return TextUtils.findAnyTargetText(targetTexts, options);
    },

    clickAnyTargetText: function (targetTexts, options) {
        return TextUtils.clickAnyTargetText(targetTexts, options);
    },

    clickPasteText: function (options) {
        return TextUtils.clickPasteText(options);
    },

    // Scroll utilities
    scroll: function (direction, options) {
        return BaseUtils.scroll(direction, options);
    },

    scrollUp: function (options) {
        return BaseUtils.scrollUp(options);
    },

    scrollDown: function (options) {
        return BaseUtils.scrollDown(options);
    },

    scrollLeft: function (options) {
        return BaseUtils.scrollLeft(options);
    },

    scrollRight: function (options) {
        return BaseUtils.scrollRight(options);
    },

    // Long press method
    longPress: function (x, y, duration, options) {
        return BaseUtils.longPress(x, y, duration, options);
    },

    getAllChildren: function (node) {
        return BaseUtils.getAllChildren(node);
    },
    sendToBot: function (text) {
        return TaskUtils.sendToBot(text);
    },

};

module.exports = Tool; 