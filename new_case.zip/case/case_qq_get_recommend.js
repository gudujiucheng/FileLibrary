// 导入核心类
var taskUtils = require('./utils/task_utils.js');
const core = require('./api/core_api.js');
const textUtils = require('./utils/text_utils.js');

// 定义操作类型常量
const OPERATION_TYPE = {
    NO_OPERATION: 0,    // 无操作
    ADD_SUCCESS: 1,     // 添加成功
    REMOVE_SUCCESS: 2,  // 移除成功
    REMOVE_FAILED: -2,  // 移除失败
    ADD_FAILED: -1      // 添加失败
};

// 定义输出文件路径
const outputFilePath = context.getFilesDir() + "/qq_numbers.txt";

// 保存结果到文件
function saveResult(userId, allResults) {
    try {
        // 使用Map的keys()获取所有QQ号
        const uniqueQQs = Array.from(allResults.keys());

        // 生成文件内容
        let content = `\n\n=== QQ号统计 ===\n获取时间：[${new Date().toLocaleString()}]\n`;
        content += `用户ID: ${userId}\n`;
        content += `--------------------------------\n`;

        // 写入去重后的QQ号，保持原有格式 
        uniqueQQs.forEach((qq, index) => {
            const result = allResults.get(qq);
            content += `${result.result} 昵称：${result.nickName}\n`;
        });

        content += `--------------------------------\n`;
        content += `共找到 ${uniqueQQs.length} 个不重复QQ号\n\n`;

        // 追加写入文件
        files.append(outputFilePath, content);
        console.log(`已追加保存到：${outputFilePath}`);
    } catch (e) {
        console.error("文件写入失败：", e);
    }
}

// 获取当前时间
function getCurrentTime() {
    return new Date().toLocaleString();
}

const qqTask = taskUtils.task({
    packageName: "com.tencent.mobileqq",
    activityName: "com.tencent.mobileqq.activity.SplashActivity",
    targetPages: ["MainActivity"], // 可选，用于校验app是否正常启动
    targetTexts: ["消息"],//可选，用于校验app是否正常启动
    maxRetries: 1//失败重试次数
});

// 处理QQ号（如果命中，则走添加或者不在添加操作）
function handleQQNumber(label, item, options, userStat) {
    // 提取QQ号
    let qqNumber;
    if (label.toString().includes("QQ号：")) {
        // 格式1：QQ号：312929904
        qqNumber = parseInt(label.toString().split("QQ号：")[1]);
    } else {
        // 格式2：312929904
        qqNumber = parseInt(label);
    }

    if (!isNaN(qqNumber)) {
        console.log(`提取到的QQ号: ${qqNumber}`);

        // 检查是否在needAdd列表中
        if (options.needAdd && options.needAdd.includes(qqNumber)) {
            console.log(`QQ号 ${qqNumber} 在needAdd列表中，点击添加`);

            //点击添加好友按钮
            let addResult = core.clickAnyTargetText(["加好友"], {
                limit_y: [0.9, 1], timeout: 2000, continueOnError: true
            });
            if (!addResult) {
                console.log(`QQ号 ${qqNumber} 在needAdd列表中，点击添加失败`);
                return {
                    result: `QQ号：${qqNumber} [点击添加失败]`,
                    type: OPERATION_TYPE.ADD_FAILED
                };
            } else {
                sleep(1000);
                //有问题需要回答，直接返回
                let questionsResult = core.findAnyTargetText(["输入答案", "输入答", "入答案"]);
                if (questionsResult != null && questionsResult.length > 0) {
                    console.log(`QQ号 ${qqNumber} 在needAdd列表中，点击添加失败，因为需要回答问题`);
                    return {
                        result: `QQ号：${qqNumber} [点击添加失败：需要回答问题]`,
                        type: OPERATION_TYPE.ADD_FAILED
                    };
                }
                let sendResult = core.clickAnyTargetText(["发送"], {
                    limit_y: [0.8, 1], timeout: 4000, continueOnError: true
                });
                if (!sendResult) {
                    console.log(`QQ号 ${qqNumber} 在needAdd列表中，点击添加失败，没有找到'发送'按钮`);
                    return {
                        result: `QQ号：${qqNumber} [点击添加失败：未找到'发送'按钮]`,
                        type: OPERATION_TYPE.ADD_FAILED
                    };
                }
                console.log(`QQ号 ${qqNumber} 在needAdd列表中，点击添加成功`);
                return {
                    result: `QQ号：${qqNumber} [已点击添加]`,
                    type: OPERATION_TYPE.ADD_SUCCESS
                };
            }
        }
        // 检查是否在noRecommend列表中
        else if (options.noRecommend && options.noRecommend.includes(qqNumber)) {
            //回到外部页面点击不在推荐
            checkAndReturnToRecommendMainPage(userStat)
            sleep(1000);
            console.log(`QQ号 ${qqNumber} 在noRecommend列表中，准备点击不在推荐`);
            console.log(`滑动锚点 item.relative.y: ${item.relative.y}`);
            let y = item.relative.y;
            // 向左滑动
            core.scrollLeft({
                eachDistance: 0.4, duration: 100, scrollStartPos: [0.5, y]
            });
            sleep(1000);
            // 点击不在推荐
            var clickResult = core.clickAnyTargetText(["不再推荐", "再推荐", "不再推", "不再", "不"], {
                limit_x: [0.5, 1], timeout: 2000, continueOnError: true
            });
            if (!clickResult) {
                console.log(`QQ号 ${qqNumber} 在noRecommend列表中，点击不在推荐失败`);
                return {
                    result: `QQ号：${qqNumber} [点击不在推荐失败]`,
                    type: OPERATION_TYPE.REMOVE_FAILED
                };
            } else {
                console.log(`QQ号 ${qqNumber} 在noRecommend列表中，点击不在推荐成功`);
                return {
                    result: `QQ号：${qqNumber} [已点击不在推荐]`,
                    type: OPERATION_TYPE.REMOVE_SUCCESS
                };
            }
        }
    }
    return {
        result: `QQ号：${qqNumber || '未知'} [无操作]`,
        type: OPERATION_TYPE.NO_OPERATION
    };
}

// 检查并返回推荐好友主页面
function checkAndReturnToRecommendMainPage(userStat) {
    let retryCount = 0;
    let pages = null;
    while (retryCount < 3) {
        pages = core.findAnyTargetText(["可能想认识的人", "想认识的人", "认识的人"], {
            limit_y: [0, 0.15], timeout: 2000, continueOnError: true
        });
        if (pages && pages.length > 0) {
            console.log(`页面正确，无需回退`);
            return true;
        }
        console.log(`尝试回退到上一级页面 (第${retryCount + 1}次尝试)`);
        back();
        sleep(2000);
        retryCount++;
    }

    if (!pages || pages.length === 0) {
        console.log(`连续${retryCount}次回退后仍未找到"可能想认识的人"，任务中断`);
        userStat.success = false;
        userStat.description = `任务中断：无法返回主页面`;
        return false;
    }
    return true;
}

//发说说
qqTask.execute(function (userId, userStat, options) {
    if (!checkMainPage()) {
        return;
    }

    // Example of using options
    console.log("Task options:", options);

    core.clickAnyTargetText(["联系人", "联系", "系人"], { limit_x: [0.5, 0.9], limit_y: [0.9, 1], timeout: 2000 });

    let findSubmitResult = core.findAnyTargetText(["可能想认识的人", "可能想认识", "认识的人"], {
        limit_x: [0, 0.6], limit_y: [0, 0.5], timeout: 2000, continueOnError: true
    });
    if (findSubmitResult && findSubmitResult.length > 0) {

    } else {
        let isHasNewFriend = core.clickAnyTargetText(["新朋友", "新朋"], {
            limit_x: [0, 0.6], limit_y: [0, 0.5], timeout: 2000, continueOnError: true
        });
        if (isHasNewFriend) {
            core.scrollUntilFindAnyTargetText(["你可能认识他们", "你可能", "认识他们"], {
                limit_x: [0, 0.6], max_scroll_times: 15, eachDistance: 0.2,
            });
            sleep(2000);
            let clickResult = core.clickAnyTargetText(["你可能认识他们", "你可能", "认识他们"], {
                limit_x: [0, 0.6], timeout: 2000, continueOnError: true
            });
            if (!clickResult) {
                console.log("没有找到'可能想认识的人-新朋友-你可能认识他们'入口,中断流程");
                userStat.noTarget = true;
                userStat.success = true;
                return;
            }

        } else {
            console.log("没有找到'可能想认识的人-新朋友'入口,中断流程");
            userStat.noTarget = true;
            userStat.success = true;
            return;
        }
    }

    console.log("找到'可能想认识的人'按钮,点击");
    core.clickAnyTargetText(["可能想认识的人", "可能想认识", "认识的人"], {
        limit_x: [0, 0.6], limit_y: [0, 0.5], timeout: 2000
    });
    sleep(2000);
    let allResults = new Map(); // 使用Map存储结果，key为QQ号
    let scrollDistance = 0.9;
    let startY = 0.88;
    let itemRetryCount = new Map(); // 用于记录每个item的重试次数

    // 记录处理结果
    function recordQQResult(qqNumber, nickName, result) {
        // 获取已存在的结果
        let existingResult = allResults.get(qqNumber);
        
        // 如果已存在且不是失败状态，则跳过
        if (existingResult && existingResult.type >= OPERATION_TYPE.NO_OPERATION) {
            return;
        }

        // 准备新的结果对象
        let newResult = {
            qqNumber: qqNumber,
            nickName: nickName,
            result: result.result,
            type: result.type
        };

        // 更新或添加结果
        allResults.set(qqNumber, newResult);
    }

    function processAddResults() {
        console.log("--------------------------------继续查找--------------------------------");
        //获取所有添加按钮，并逐个点击进去
        let nickNames = core.getAllNodesByViewId("nickname", { limit_x: [0, 0.7], timeout: 2000, continueOnError: true });
        if (nickNames.length > 0) {
            // 按y坐标从上到下排序
            nickNames.sort((a, b) => a.relative.y - b.relative.y);
            console.log(`找到'昵称'坐标,逐个点开查找qq号 (共${nickNames.length}个)`);

            //遍历所有的添加按钮
            for (let index = 0; index < nickNames.length; index++) {
                let item = nickNames[index];
                let nickName = item.label;
                console.log(`--------------------------------处理第 ${index + 1}/${nickNames.length} 个添加按钮 昵称: ${nickName} (y坐标: ${item.relative.y})--------------------------------`);


                // 如果昵称已存在，检查是否已处理过（排除失败状态）
                if (nickName) {
                    let existingQQ = Array.from(allResults.values()).find(data =>
                        data.nickName === nickName && data.type >= OPERATION_TYPE.NO_OPERATION
                    );
                    if (existingQQ) {
                        console.log(`昵称 ${nickName} 已成功处理过，跳过`);
                        continue;
                    }
                }

                click(item.centerX, item.centerY);
                sleep(2000);
                let allQQTexts = textUtils.findAllNodesByTexts(["QQ号", "号"], {
                    limit_x: [0.3, 1], limit_y: [0, 0.7], timeout: 3000
                });
                if (allQQTexts.length > 0) {
                    let foundQQ = false;
                    // 首先尝试查找包含"QQ号"的文本
                    for (let qqItem of allQQTexts) {
                        if (qqItem.label.toString().includes("QQ号")) {
                            console.log(`第 ${index + 1} 个按钮找到目标：${qqItem.label}`);
                            let qqNumber = parseInt(qqItem.label.toString().split("QQ号：")[1]);
                            let result = handleQQNumber(qqItem.label, item, options, userStat);
                            recordQQResult(qqNumber, nickName, result);
                            foundQQ = true;
                            if (result.type === OPERATION_TYPE.REMOVE_SUCCESS || result.type === OPERATION_TYPE.ADD_SUCCESS) {
                                console.log("检测到移除推荐成功或者添加成功，坐标发生了变化，重新开始循环");
                                return true;
                            }
                            if (result.type === OPERATION_TYPE.REMOVE_FAILED) {
                                // 获取当前item的重试次数
                                let retryCount = itemRetryCount.get(item.label) || 0;
                                if (retryCount >= 1) {
                                    console.log(`昵称 ${item.label} 已重试过一次，跳过继续处理`);
                                    break;
                                }

                                console.log("检测到移除推荐失败，尝试滚动一下继续尝试");
                                if (item.relative.y > 0.8) {
                                    console.log("检测到移除推荐失败，位置太靠下了，尝试向上滚动");
                                    core.scrollUp({
                                        eachDistance: 0.1, scrollTimes: 3, scrollStartPos: [0.5, 0.8]
                                    });
                                    // 记录重试次数
                                    itemRetryCount.set(item.label, retryCount + 1);
                                    return true;
                                } else if (item.relative.y < 0.2) {
                                    console.log("检测到移除推荐失败，位置太靠上了，尝试向下滚动");
                                    core.scrollDown({
                                        eachDistance: 0.1, scrollTimes: 3, scrollStartPos: [0.5, 0.3]
                                    });
                                    // 记录重试次数
                                    itemRetryCount.set(item.label, retryCount + 1);
                                    return true;
                                }
                            }
                            break;
                        }
                    }

                    // 如果没有找到包含"QQ号"的文本，尝试查找纯数字
                    if (!foundQQ) {
                        for (let qqItem of allQQTexts) {
                            let text = qqItem.label.toString();
                            // 提取纯数字
                            let numbers = text.match(/\d+/g);
                            if (numbers) {
                                for (let num of numbers) {
                                    // 检查是否是6位以上的数字
                                    if (num.length >= 6) {
                                        console.log(`第 ${index + 1} 个按钮找到纯数字目标：${num}`);
                                        let qqNumber = parseInt(num);
                                        let result = handleQQNumber(parseInt(num), item, options, userStat);
                                        recordQQResult(qqNumber, nickName, result);
                                        foundQQ = true;
                                        if (result.type === OPERATION_TYPE.REMOVE_SUCCESS || result.type === OPERATION_TYPE.ADD_SUCCESS) {
                                            console.log("num 检测到移除推荐成功或者添加成功，坐标发生了变化，重新开始循环");
                                            return true;
                                        }
                                        break;
                                    }
                                }
                            }
                            if (foundQQ) break;
                        }
                    }

                    if (!foundQQ) {
                        console.log(`第 ${index + 1} 昵称: ${nickName} 没有找到有效的QQ号`);
                    }
                } else {
                    console.log(`第 ${index + 1} 昵称: ${nickName} 个按钮没有找到目标qq`);
                }
                //每次添加按钮轮询完毕，都要保证回到推荐主页面
                checkAndReturnToRecommendMainPage(userStat)
            }

            //容错：每次大循环保证，回到推荐主页面
            checkAndReturnToRecommendMainPage(userStat)

            // 计算滑动距离
            let firstAdd = nickNames[0];
            let lastAdd = nickNames[nickNames.length - 1];
            // 计算相对滑动距离（最后一个按钮到第一个按钮的距离）
            scrollDistance = (lastAdd.relative.y - firstAdd.relative.y);
            console.log(`--------------------------------计算滑动距离: ${scrollDistance}`);

            // 优化滑动起始位置，避免极值场景
            startY = lastAdd.relative.y;
            if (startY > 0.93) {
                startY = 0.93;
            } else if (startY < 0.6) {
                startY = 0.88;
            }
            console.log(`--------------------------------滑动起始位置: ${startY}`);
        }
        return false;
    }

    while (true) {
        //每次添加按钮轮询完毕，都要保证回到推荐主页面
        checkAndReturnToRecommendMainPage(userStat)
        sleep(1000);
        // 处理当前页面的添加按钮
        let needRestart = processAddResults();

        // 如果需要重新开始（比如因为移除了推荐/添加成功），直接继续下一次循环
        if (needRestart) {
            console.log("检测到移除推荐成功或者添加成功，坐标发生了变化，不执行滚动，直接重新开始循环获取");
            continue;
        }

        // 如果不需要重新开始，说明当前页面处理完成，需要滑动到下一页
        console.log("当前页面处理完成，准备滑动到下一页");

        //执行完任务在检查是否到底，避免最后一页没有扫描
        let findResult = core.findAnyTargetText(["没有更多了", "没有", "更多"], {
            limit_y: [0.9, 1],
            timeout: 2000,
            continueOnError: true
        });
        if (findResult && findResult.length > 0) {
            console.log("已到达底部，结束循环");
            break;
        }

        // 执行滑动
        core.scrollUp({
            eachDistance: scrollDistance,
            scrollStartPos: [0.5, startY],
            max_scroll_times: 1,
            duration: 1500
        });
        // 等待页面稳定
        sleep(2000);
    }

    // 循环结束后，保存所有结果
    if (allResults.size > 0) {
        saveResult(userId, allResults);
        userStat.success = true;
        userStat.description = `共找到 ${allResults.size} 个QQ号`;
    } else {
        userStat.noTarget = true;
        userStat.success = false;
        console.log("没有找到任何QQ号");
    }

});

function checkMainPage() {
    sleep(5000);
    core.clickAnyTargetText(["一键登录", "一键", "重新登录", "新登录"], { timeout: 2000, continueOnError: true });
    sleep(2000);
    let i = 0;
    while (i < 10) {
        var current = currentActivity();
        console.log("当前页面: " + current);
        let target = core.findAnyTargetText(["消息", "联系人", "动态"], {
            limit_y: [0.8, 1], continueOnError: true, timeout: 2000,
        });
        if (target != null && target.length > 0) {
            console.log("启动QQ成功");
            return true;
        }
        i++;
        sleep(3000);
        back();
    }
    console.log("启动QQ失败");
    return false;
}

