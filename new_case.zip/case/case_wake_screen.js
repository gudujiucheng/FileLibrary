console.log("脚本开始运行...");

// 使用实际时间戳来控制延迟
let startTime = new Date().getTime();
let targetTime = startTime + 10 * 1000; // 10秒后执行

console.log("等待10秒...");
// 使用循环检查实际时间，而不是简单的sleep
while (new Date().getTime() < targetTime) {
    // 每100ms检查一次，避免过度消耗CPU
    sleep(100);
}

// 方法1：使用 device.wakeUp()
console.log("正在唤醒屏幕(方法1)...");
device.wakeUp();
sleep(1000);

// 方法2：使用 shell 命令
console.log("正在唤醒屏幕(方法2)...");
shell("input keyevent KEYCODE_POWER", true);
sleep(1000);

// 向上滑动解锁
console.log("正在滑动解锁...");
// 从屏幕底部中间向上滑动
swipe(device.width / 2, device.height * 0.8, device.width / 2, device.height * 0.2, 500);
sleep(1000);

// 输入密码 181014
console.log("正在输入密码...");
let password = "0000";
for (let i = 0; i < password.length; i++) {
    let digit = password[i];
    // 点击数字
    click(digit);
    // 每次点击后稍微等待一下
    sleep(100);
}

console.log("脚本执行完成");