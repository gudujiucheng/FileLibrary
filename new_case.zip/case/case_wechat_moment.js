// 导入核心类 
var taskUtils = require('./utils/task_utils.js');
const core = require('./api/core_api.js');


const wechatTask = taskUtils.task({
    packageName: "com.tencent.wework",
    activityName: "com.tencent.wework.launch.LaunchSplashActivity",
    targetPages: ["WwMainActivity"], // 可选，用于校验app是否正常启动
    targetTexts: ["工作台"],//可选，用于校验app是否正常启动
    unLoginPages: ["LoginWxAuthActivity", "PrivatePolicyDialog"], //可选，用于校验app是否正常启动
    unLoginTexts: ["已阅读并同意", "手机号登录", "微信登录", "隐私保护指引"], //可选，用于校验app是否正常启动
    maxRetries: 1,//失败重试次数
    customReportGenerator: generateCustomReport // 自定义报告生成器
});

//发朋友圈
wechatTask.execute(function (userId, userStat, userConfig, taskConfig) {
    let mineResult = core.clickText("我", {limit_x: [0.8, 1], limit_y: [0.9, 1], continueOnError: true, timeout: 2000});

    function refreshNickName(nickItem) {
        // 安全检查：确保 nickItem 和 nickItem.label 都存在
        if (!nickItem || !nickItem.label) {
            console.log("⚠️ 昵称信息无效，使用默认值");
            let defaultName = `用户${userId}`;
            userStat.otherInfo.set("name", defaultName);
            return;
        }

        let name = String(nickItem.label).trim();
        if (!name || name === '') {
            console.log("⚠️ 昵称为空，使用默认值");
            name = `用户${userId}`;
        }

        console.log("目标昵称：" + name);
        userStat.otherInfo.set("name", name);

        // 安全调用 Java 方法，添加异常处理
        try {
            com.tencent.assistant.manager.DualAppAccountManager.INSTANCE.setCurrentDualUserInfo(userId, name);
            console.log(`✅ 成功更新用户 ${userId} 的昵称信息: ${name}`);
        } catch (error) {
            console.log(`⚠️ 更新用户昵称信息失败: ${error.message}`);
            // 即使更新失败，也不影响主要业务流程
        }
    }

    if (mineResult) {
        let nameResult = core.getAllHasTextNodes({limit_y: [0.2, 0.3]})
        if (nameResult.length === 0) {
            console.log("没有找到昵称文本");
        } else {
            let nickItem = null;
            nameResult.forEach(item => {
                    if (nickItem == null) {
                        nickItem = item;
                    } else {
                        //避免扫描到对外名片文字
                        nickItem = (!item.label.toString().includes('对外名片') && item.centerY > nickItem.centerY) ? item : nickItem;
                    }

                }
            );
            refreshNickName(nickItem);
        }

    } else {
        console.log("没有找到'我'按钮,尝试滑动侧边栏获取用户信息");
        // 业务逻辑步骤
        core.scrollRight({eachDistance: 1, duration: 300, scrollStartPos: [0.1, 0.5]});
        //获取文本 node方式，如果满足不了可结合OCR方式
        let nameResult = core.getAllHasTextNodes({limit_y: [0.06, 0.16], limit_x: [0.1, 0.8]})
        if (nameResult.length === 0) {
            console.log("没有找到昵称文本");
        } else {
            let nickItem = null;
            nameResult.forEach(item => {
                    if (nickItem == null) {
                        nickItem = item;
                    } else {
                        nickItem = item.centerY < nickItem.centerY ? item : nickItem;
                    }

                }
            );
            refreshNickName(nickItem);
        }
        core.scrollLeft({eachDistance: 1, duration: 300, scrollStartPos: [0.9, 0.5]});
    }


    core.clickText("工作台");
    core.clickText("客户朋友圈");
    let findSubmitResult = core.clickText("去发表", {continueOnError: true});
    //针对有个人主页，且没有去发表按钮的情况，进行正常终止（这种属于类型2的企微）
    if (mineResult && !findSubmitResult) {
        console.log("没有找到'去发表'按钮,中断流程");
        userStat.noTarget = true;
        userStat.success = true;
        return;

    }
    let dateStr = core.getFormattedDate();
    // dateStr = "03月14日";
    let result = core.findAllByTexts(dateStr);
    if (result.length > 0) {
        let maxY = 0;
        result.forEach(item => {
            item.relative.y > maxY ? maxY = item.relative.y : null;
        });
        if (maxY <= 0) {
            throw new Error(`${dateStr}日期 异常纵坐标:${maxY}`);
        }
        let submits = core.findAllByTexts("发表", {limit_y: [0, maxY], limit_x: [0.7, 1], continueOnError: true});
        if (submits.length > 0) {
            // 找到Y坐标最小（最上方）的发表按钮
            let topSubmit = submits.reduce((minSubmit, currentSubmit) => {
                return currentSubmit.centerY < minSubmit.centerY ? currentSubmit : minSubmit;
            });

            console.log(`找到 ${submits.length} 个发表按钮，点击最上方的按钮`, topSubmit.relative);
            // click(topSubmit.centerX, topSubmit.centerY);
            sleep(2000);
            back()
            // 判断是否 需要发布评论
            sendComment(taskConfig);
        } else {
            throw new Error("没有找到'发表'按钮");
        }

    } else {
        sleep(2000);
        back()
        // 判断是否 需要发布评论
        sendComment(taskConfig);

        userStat.description += `没有找到${dateStr}节点`;
        console.log(`${userStat.description}`);
        //没有命中目标（不属于失败，比如没有需要发布的朋友圈情况）
        userStat.noTarget = true;
        userStat.success = true;
        return;
    }
    userStat.success = true;
    userStat.description += `\n执行成功,发布了${result.length}条数据`;
    console.log(`${userStat.description}`);
});


// 自定义报告生成器
function generateCustomReport(reportData) {
    const {stats, userIds, startTime, formatMap} = reportData;

    let totalUsers = userIds.length;
    let successCount = Object.values(stats).filter(s => s.success).length;
    let noTaskCount = Object.values(stats).filter(s => s.noTarget).length;
    let failedCount = totalUsers - successCount;

    // 计算耗时
    let totalSeconds = Math.floor((Date.now() - startTime) / 1000);
    let minutes = Math.floor(totalSeconds / 60);
    let seconds = totalSeconds % 60;
    let timeStr = minutes > 0 ? `${minutes}分${seconds}秒` : `${seconds}秒`;

    // 格式化开始时间
    let startTimeStr = new Date(startTime).toLocaleString('zh-CN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
    });

    let mdContent = `自动发朋友圈任务已完成，共执行了 <font color="info">${totalUsers}</font> 个企微。`;
    mdContent += `发表成功 <font color="comment">${successCount - noTaskCount}</font> 个，今天没有需要发朋友圈的 <font color="comment">${noTaskCount}</font> 个，发表失败 <font color="red">${failedCount}</font> 个。`;
    mdContent += `执行开始时间：<font color="comment">${startTimeStr}</font>，执行耗时 <font color="comment">${timeStr}</font>。`;

    // 如果有失败的用户，添加失败详情
    if (failedCount > 0) {
        mdContent += `\n\n**<font color="comment">失败用户详情：</font>**\n`;
        Object.keys(stats).forEach(userId => {
            let stat = stats[userId];
            if (!stat.success) {
                let userName = stat.otherInfo.get("name") || "未知用户";
                mdContent += `- ${userName} (ID: ${userId})：\n`;

                // 显示所有失败原因
                if (stat.errors && stat.errors.length > 0) {
                    stat.errors.forEach((error, index) => {
                        mdContent += `  ${error}\n`;
                    });
                } else {
                    mdContent += `  未知错误\n`;
                }
            }
        });
    }

    return mdContent;
}

function sendComment(taskConfig) {
    if (taskConfig && taskConfig.comment && taskConfig.comment.length > 0) {

        try {
            //先尝试点击今天发布的第一条
            top = core.findText("发表到客户的朋友圈")
            console.log(top)
            results = core.getAllHasTextNodes({limit_x: [0.2, 1], limit_y: [top.relative.y, 1]})
            if (results && results.length > 0) {
                //点击y坐标最小的那个
                console.log("找到节点数量:" + results.length)

                // 按y坐标排序，找到最上方的节点
                results.sort((a, b) => a.centerY - b.centerY);

                // 获取y坐标最小的节点
                let firstNode = results[0];
                console.log("点击坐标：" + firstNode.relative.x + ", " + firstNode.relative.y);
                if (firstNode.relative.y - top.relative.y > 0.1) {
                    console.log("首个有文本的内容间距过大，所以最新一条评论可能是图片，尝试直接点击偏移位置");
                    click(top.centerX, top.centerY + 0.1 * device.height);
                } else {
                    console.log("点击最新一条动态");
                    click(firstNode.centerX, firstNode.centerY);
                }
            } else {
                console.log("未找到符合条件的节点,尝试点击坐标偏移");
                core.clickText("发表到客户的朋友圈", {offset: [0, 0.07],})
            }
            core.clickText("评论", {
                limit_x: [0, 0.2],
                limit_y: [0.8, 1],
            });
            core.inputText("说点什么吧", taskConfig.comment, {
                limit_x: [0, 0.6],
            });

            // core.clickAnyImage(["./img/send_comment.png"], {
            //     limit_x: [0.8, 1],
            //     limit_y: [0.4, 1],
            //     timeout: 2000
            // });
            userStat.description += `\n评论发布成功: ${taskConfig.comment}`;
        } catch (e) {
            let errorMsg = `发布评论失败: ${e.message}`;
            console.log(errorMsg);
            userStat.description += errorMsg;
        }


    }
}

