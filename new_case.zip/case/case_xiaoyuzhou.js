// 导入核心API工具（如有需要可替换为实际项目的core_api.js）
var core = require('./api/core_api.js');

// 小宇宙频道分类配置
const CATEGORY_LIST = [
  '商业',
  '自我成长',
  '人文',
  '社会',
  '职业探索',
  '兴趣生活',
  '故事奇谈',
  '趣味闲谈',
  '文旅',
  '阅读',
  '治愈陪伴',
  '科技',
  '艺术',
  '饮食',
  '体育运动',
  '动漫游戏',
  '影视娱乐',
  '医疗健康',
];

CATEGORY_1 = [
  '商业',
  '自我成长',
  // '人文',
];

CATEGORY_2 = [
  '社会',
  '职业探索',
  // '兴趣生活',
];

CATEGORY_3 = [
  '人文',
  '兴趣生活',
];

// 小宇宙App包名
const XIAOYUZHOU_PACKAGE = 'app.podcast.cosmos';

// 日志目录
const logDirPath = files.join(context.cacheDir, "logs");

// 全局统计字典
let globalStats = {
  startTime: Date.now(),
  categories: {} // { [categoryName]: { startTime, duration, channels: { [channelName]: { startTime, duration, postCount } } } }
};

function getCategoryByDeviceId(deviceId){
  if(deviceId == '8f0ba1157eddffd4'){
    return CATEGORY_1;
  }else if(deviceId == '57d5d672227594c5'){
    return CATEGORY_2;
  }else if(deviceId == '000000000000002'){
    return CATEGORY_3;
  }
  return [];
}

// --- 报告生成 ---

// 格式化时间显示
function formatDuration(seconds) {
  if (seconds < 60) {
    return `${seconds}秒`;
  } else if (seconds < 3600) {
    let minutes = Math.floor(seconds / 60);
    let remainingSeconds = seconds % 60;
    return `${minutes}分${remainingSeconds.toString().padStart(2, '0')}秒`;
  } else {
    let hours = Math.floor(seconds / 3600);
    let minutes = Math.floor((seconds % 3600) / 60);
    let remainingSeconds = seconds % 60;
    return `${hours}时${minutes.toString().padStart(2, '0')}分${remainingSeconds.toString().padStart(2, '0')}秒`;
  }
}

function generateAndSendReport() {
  let totalDuration = Math.floor((Date.now() - globalStats.startTime) / 1000);
  let msg = `## 📖 [XYZ]全部爬取完成报告\n\n`;
  msg += `**开始时间:** ${new Date(globalStats.startTime).toLocaleString()}\n`;
  msg += `**总耗时:** ${formatDuration(totalDuration)}\n\n`;

  let totalChannels = 0, totalPosts = 0;
  for (let cat in globalStats.categories) {
    const catObj = globalStats.categories[cat];
    const channelNames = Object.keys(catObj.channels);
    let catPosts = 0;
    msg += `### 🗂️ 分类: **${cat}**\n`;
    msg += `- 耗时: \`${formatDuration(catObj.duration)}\`\n`;
    msg += `- 频道数: \`${channelNames.length}\`\n`;
    msg += `- 需要购买频道数: \`${catObj.buySkipCount}\`\n`;
    msg += `- 频道明细:\n`;
    for (let ch of channelNames) {
      const chObj = catObj.channels[ch];
      msg += `  - **${ch}**\n`;
      msg += `    - 帖子数: \`${chObj.postCount}\`\n`;
      msg += `    - 跳过帖子数: \`${chObj.skipCount}\`\n`;
      msg += `    - 需要购买: \`${chObj.buySkipCount}\`\n`;
      msg += `    - 标题为空: \`${chObj.emptyTitleCount}\`\n`;
      msg += `    - 频道耗时: \`${formatDuration(chObj.duration)}\`\n`;
      catPosts += chObj.postCount;
    }
    msg += `- 分类帖子总数: \`${catPosts}\`\n\n`;
    totalChannels += channelNames.length;
    totalPosts += catPosts;
  }
  msg += `---\n`;
  msg += `**全局频道总数:** \`${totalChannels}\`\n`;
  msg += `**全局帖子总数:** \`${totalPosts}\`\n`;
  msg += `**报告生成时间:** ${new Date().toLocaleString()}\n`;

  core.sendToBot(msg);
}

function sendCategoryStatMsg(categoryName) {
  const catObj = globalStats.categories[categoryName];
  if (!catObj) return;
  const channelNames = Object.keys(catObj.channels);
  let catPosts = 0;
  let msg = `## 🗂️ [XYZ]分类爬取完成报告\n`;
  msg += `- 分类: **${categoryName}**\n`;
  msg += `- 开始时间: \`${new Date(catObj.startTime).toLocaleString()}\`\n`;
  msg += `- 耗时: \`${formatDuration(catObj.duration)}\`\n`;
  msg += `- 频道数: \`${channelNames.length}\`\n`;
  msg += `- 需要购买频道数: \`${catObj.buySkipCount}\`\n`;
  msg += `- 频道明细:\n`;
  for (let ch of channelNames) {
    const chObj = catObj.channels[ch];
    msg += `  - **${ch}**\n`;
    msg += `    - 帖子数: \`${chObj.postCount}\`\n`;
    msg += `    - 跳过帖子数: \`${chObj.skipCount}\`\n`;
    msg += `    - 需要购买: \`${chObj.buySkipCount}\`\n`;
    msg += `    - 标题为空: \`${chObj.emptyTitleCount}\`\n`;
    msg += `    - 频道耗时: \`${formatDuration(chObj.duration)}\`\n`;
    catPosts += chObj.postCount;
  }
  msg += `- 分类帖子总数: \`${catPosts}\`\n`;
  core.sendToBot(msg);
  insertReportHistory(categoryName, '', 0, new Date().toISOString(), msg);
}

// 发送频道统计消息
function sendChannelStatMsg(categoryName, channelName) {
  let channelStat = globalStats.categories[categoryName].channels[channelName];
  let duration = channelStat.duration;
  let postCount = channelStat.postCount;
  let historyPostCount = channelStat.historyPostCount || 0;
  let skipCount = channelStat.skipCount || 0;
  let totalProcessed = postCount + historyPostCount + skipCount;
  let emptyTitleCount = channelStat.emptyTitleCount || 0;
  let buySkipCount = channelStat.buySkipCount || 0;
  let otherSkipCount = skipCount - emptyTitleCount - buySkipCount;

  let postsCount = getTotalPostCountFromDb();
  
  let content = `## 📊 [XYZ]频道爬取完成报告\n\n` +
    `🏷️ **频道信息**\n` +
    `• 分类：${categoryName}\n` +
    `• 频道：${channelName}\n\n` +
    `📈 **统计详情**\n` +
    `• 历史已爬取：${historyPostCount} 条\n` +
    `• 本次新增：${postCount} 条\n` +
    `• 本次跳过：${skipCount} 条\n` +
    `• 帖子总数：${totalProcessed} 条\n` +
    `📋 **跳过原因统计**\n` +
    `• 标题为空：${emptyTitleCount} 条\n` +
    `• 需要购买：${buySkipCount} 条\n` +
    `• 其他原因：${otherSkipCount} 条\n\n` +
    `⏱️ **耗时**：${formatDuration(duration)}\n` +
    `📚 **已爬取帖子数**：${postsCount} 条\n`;
  
    core.sendToBot(content);
    insertReportHistory(categoryName, channelName, 1, new Date().toISOString(), content);
}

// --- 日志工具 ---

// 日志写入到沙盒logs目录，文件名为YYYYMMDD.log
function getLogFilePath() {
  let date = new Date();
  let year = date.getFullYear().toString();
  let month = (date.getMonth() + 1).toString().padStart(2, '0');
  let day = date.getDate().toString().padStart(2, '0');
  return files.join(logDirPath, `${year}${month}${day}.log`);
}

function appendToLog(level, args) {
  try {
    const logPath = getLogFilePath();
    files.ensureDir(logDirPath);
    const timestamp = new Date().toLocaleString('sv');
    const message = Array.prototype.slice.call(args).map(String).join(' ');
    const logEntry = `[${timestamp}] [${level}] ${message}\n`;
    files.append(logPath, logEntry);
  } catch (e) {
    // 避免日志写入失败死循环
    console.error('写入日志文件失败: ', e);
  }
}

// 日志工具
function logInfo() {
    console.log.apply(console, arguments);
    appendToLog('INFO', arguments);
  }
  function logError() {
    console.error.apply(console, arguments);
    appendToLog('ERROR', arguments);
  }


// --- 初始化函数 ---

/**
 * @description 执行脚本的所有初始化操作，包括创建目录。
 */
function initializeScript() {
    logInfo("--- 开始初始化脚本 ---");

    // 1. 确保所有需要的目录都存在
    ensureDirExists(logDirPath);
    
    // 2. 初始化数据库
    initializeDatabase();

    logInfo("--- 初始化完成 ---");
}

/**
 * @description 创建一个目录，如果它不存在的话。
 * @param {string} path - 要创建的目录路径。
 */
function ensureDirExists(path) {
    try {
        let dir = new java.io.File(path);
        if (!dir.exists()) {
            let success = dir.mkdirs();
            if (success) {
                // 首次创建目录时，使用console.log避免循环调用日志
                console.log(`目录创建成功: ${path}`);
            } else {
                console.error(`目录创建失败: ${path}`);
            }
        }
    } catch (e) {
        console.error(`创建目录出错: ${path}`, e);
    }
}

// 数据库初始化及结构
var db = null;

/**
 * 初始化数据库，表结构：
 * category_name TEXT, channel_name TEXT, channel_link TEXT, is_finished INTEGER, last_post_title TEXT, finished_time TEXT
 */
function initializeDatabase() {
  if (db) return;
  try {
    // 数据库存储在 context.cacheDir + '/xiaoyuzhou_v2.db'
    const dbPath = files.join(context.cacheDir, 'xiaoyuzhou_v2.db');
    db = sqlite.open(dbPath);
    db.execSQL(
      'CREATE TABLE IF NOT EXISTS channel_status (' +
      'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
      'category_name TEXT, ' +
      'channel_name TEXT, ' +
      'channel_link TEXT, ' +
      'is_finished INTEGER, ' +
      'last_post_title TEXT, ' +
      'finished_time TEXT, ' +
      'post_count INTEGER DEFAULT 0, ' +
      'ext TEXT, ' +
      'UNIQUE(category_name, channel_name))'
    );
    // 新增帖子历史表
    db.execSQL(
      'CREATE TABLE IF NOT EXISTS post_history (' +
      'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
      'category_name TEXT, ' +
      'channel_name TEXT, ' +
      'post_title TEXT, ' +
      'post_url TEXT, ' +
      'create_time TEXT, ' +
      'ext TEXT, ' +
      'UNIQUE(category_name, channel_name, post_title))'
    );
    // 新增报告历史表
    db.execSQL(
      'CREATE TABLE IF NOT EXISTS report_history (' +
      'id INTEGER PRIMARY KEY AUTOINCREMENT, ' +
      'category_name TEXT, ' +
      'channel_name TEXT, ' +
      'report_type INTEGER, ' +
      'report_time TEXT, ' +
      'report_content TEXT)'
    );
    logInfo('数据库初始化完成。');
  } catch (e) {
    logError('数据库初始化失败:', e);
  }
}

// 新增：插入帖子历史
function insertPostHistory(categoryName, channelName, postTitle, postUrl, ext) {
  try {
    db.execSQL(
      'INSERT INTO post_history (category_name, channel_name, post_title, post_url, create_time, ext) VALUES (?, ?, ?, ?, ?, ?)',
      [categoryName, channelName, postTitle, postUrl || '', new Date().toISOString(), ext || '']
    );
  } catch (e) {
    logError('插入帖子历史失败:', e);
  }
}

// 判断帖子是否已存在于数据库post_history表
function isPostInDb(categoryName, channelName, postTitle) {
  try {
    let cursor = db.rawQuery(
      'SELECT 1 FROM post_history WHERE category_name = ? AND channel_name = ? AND post_title = ? LIMIT 1',
      [categoryName, channelName, postTitle]
    );
    let exists = cursor.moveToFirst();
    cursor.close();
    return exists;
  } catch (e) {
    logError('查询帖子是否存在失败:', e);
    return false;
  }
}

// 数据库操作函数
function upsertChannelBaseInfo(categoryName, channelName, channelLink, ext) {
  try {
    db.execSQL(
      'INSERT OR IGNORE INTO channel_status (category_name, channel_name, channel_link, is_finished, ext) VALUES (?, ?, ?, 0, ?)',
      [categoryName, channelName, channelLink, ext]
    );
    db.execSQL(
      'UPDATE channel_status SET channel_link = ?, ext = ? WHERE category_name = ? AND channel_name = ?',
      [channelLink, ext, categoryName, channelName]
    );
    logInfo(`已写入频道基本信息: ${categoryName} - ${channelName}`);
  } catch (e) {
    logError('写入频道基本信息失败:', e);
  }
}

function updateChannelLastPost(categoryName, channelName, lastPostTitle) {
  try {
    db.execSQL(
      'UPDATE channel_status SET last_post_title = ? WHERE category_name = ? AND channel_name = ?',
      [lastPostTitle, categoryName, channelName]
    );
    logInfo(`已更新频道最后帖子: ${categoryName} - ${channelName} - ${lastPostTitle}`);
  } catch (e) {
    logError('更新频道最后帖子失败:', e);
  }
}

function markChannelFinished(categoryName, channelName, isFinished) {
  try {
    const finishedTime = new Date().toISOString();
    db.execSQL(
      'UPDATE channel_status SET is_finished = ?, finished_time = ? WHERE category_name = ? AND channel_name = ?',
      [isFinished, finishedTime, categoryName, channelName]
    );
    logInfo(`已标记频道爬取完毕: ${categoryName} - ${channelName}`);
  } catch (e) {
    logError('标记频道爬取完毕失败:', e);
  }
}

// 判断频道是否已完成且完成时间为今日
function shouldSkipChannel(categoryName, channelName) {
  try {
    let cursor = db.rawQuery(
      'SELECT is_finished, finished_time FROM channel_status WHERE category_name = ? AND channel_name = ?',
      [categoryName, channelName]
    );
    if (cursor.moveToFirst()) {
      let isFinished = cursor.getInt(0);
      let finishedTime = cursor.getString(1);
      logInfo(`频道 ${categoryName} - ${channelName} 完成状态: ${isFinished}, 完成时间: ${finishedTime}`);
      cursor.close();
      if (isFinished === 1 && finishedTime) {
        // 获取今日日期字符串（YYYY-MM-DD）
        let today = new Date();
        let todayStr = today.getFullYear() + '-' + (today.getMonth() + 1).toString().padStart(2, '0') + '-' + today.getDate().toString().padStart(2, '0');
        logInfo(`今日日期: ${todayStr}`);
        return finishedTime.startsWith(todayStr);
      }
    } else {
      cursor.close();
    }
  } catch (e) {
    logError('查询频道完成状态失败:', e);
  }
  return false;
}

// 读取数据库中频道的last_post_title和is_finished
function getLastPostStatus(categoryName, channelName) {
  let lastPostTitle = '';
  let isFinished = false;
  try {
    let cursor = db.rawQuery(
      'SELECT last_post_title, is_finished FROM channel_status WHERE category_name = ? AND channel_name = ?',
      [categoryName, channelName]
    );
    if (cursor.moveToFirst()) {
      lastPostTitle = cursor.getString(0) || '';
      isFinished = cursor.getInt(1) === 1;
    }
    cursor.close();
  } catch (e) {
    logError('查询频道last_post_title/is_finished失败:', e);
  }
  return { isFinished, lastPostTitle };
}

// 根据分类和频道名称，从db中统计已经爬取的帖子数量
function getPostCountFromDb(categoryName, channelName) {
  try {
    let cursor = db.rawQuery(
      'SELECT COUNT(*) FROM post_history WHERE category_name = ? AND channel_name = ?',
      [categoryName, channelName]
    );
    let count = 0;
    if (cursor.moveToFirst()) {
      count = cursor.getInt(0);
    }
    cursor.close();
    return count;
  } catch (e) {
    logError('查询频道帖子数失败:', e);
    return 0;
  }
}

// 获取所有帖子总数
function getTotalPostCountFromDb() {
  try {
    if (!db) {
      logError('数据库未初始化');
      return 0;
    }
    
    let cursor = db.query('post_history', ['COUNT(*)'], null, null, null, null, null);
    let count = 0;
    if (cursor.moveToFirst()) {
      count = cursor.getInt(0);
    }
    cursor.close();
    return count;
  } catch (e) {
    logError('查询所有帖子总数失败:', e);
    return 0;
  }
}

// 新增：插入报告历史
function insertReportHistory(categoryName, channelName, reportType, reportTime, reportContent) {
  try {
    db.execSQL(
      'INSERT INTO report_history (category_name, channel_name, report_type, report_time, report_content) VALUES (?, ?, ?, ?, ?)',
      [categoryName, channelName, reportType, reportTime, reportContent]
    );
    logInfo(`已插入报告历史: ${categoryName} - ${channelName} - 类型: ${reportType}`);
  } catch (e) {
    logError('插入报告历史失败:', e);
  }
}

// 历史数据迁移方法：从旧数据库迁移到新数据库
function migrateOldDatabaseToV2() {
  logInfo('开始历史数据迁移...');
  const oldDbPath = files.join(context.cacheDir, 'xiaoyuzhou.db');
  const newDbPath = files.join(context.cacheDir, 'xiaoyuzhou_v2.db');
  if (!files.exists(oldDbPath)) {
    logError('未找到旧数据库文件:', oldDbPath);
    return;
  }
  const oldDb = sqlite.open(oldDbPath);
  const newDb = sqlite.open(newDbPath);
  newDb.execSQL('DELETE FROM channel_status');
  newDb.execSQL('DELETE FROM post_history');

  // 1. 迁移 channel_status
  logInfo('开始迁移 channel_status 表...');
  try {
    let count = 0;
    let cursor = oldDb.query('channel_status', null, null, null, null, null, null);
    while (cursor.moveToNext()) {
      let category_name = cursor.getString(cursor.getColumnIndex('category_name'));
      let channel_name = cursor.getString(cursor.getColumnIndex('channel_name'));
      let channel_link = cursor.getString(cursor.getColumnIndex('channel_link'));
      let is_finished = cursor.getColumnIndex('is_finished') >= 0 ? cursor.getInt(cursor.getColumnIndex('is_finished')) : 0;
      let last_post_title = cursor.getColumnIndex('last_post_title') >= 0 ? cursor.getString(cursor.getColumnIndex('last_post_title')) : '';
      let finished_time = cursor.getColumnIndex('finished_time') >= 0 ? cursor.getString(cursor.getColumnIndex('finished_time')) : '';
      let post_count = cursor.getColumnIndex('post_count') >= 0 ? cursor.getInt(cursor.getColumnIndex('post_count')) : 0;
      let ext = '';
      newDb.execSQL(
        'INSERT OR REPLACE INTO channel_status (category_name, channel_name, channel_link, is_finished, last_post_title, finished_time, post_count, ext) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [category_name, channel_name, channel_link, is_finished, last_post_title, finished_time, post_count, ext]
      );
      count++;
    }
    cursor.close();
    logInfo(`channel_status表迁移完成，共迁移 ${count} 条记录。`);
  } catch (e) {
    logError('迁移channel_status表失败:', e);
  }

  // 2. 迁移 post_history
  logInfo('开始迁移 post_history 表...');
  try {
    let postUrlCache = {};
    let count = 0;
    let postCursor = oldDb.query('post_history', null, null, null, null, null, null);
    while (postCursor.moveToNext()) {
      let post_category_name = postCursor.getString(postCursor.getColumnIndex('category_name'));
      let post_channel_name = postCursor.getString(postCursor.getColumnIndex('channel_name'));
      let post_title = postCursor.getString(postCursor.getColumnIndex('post_title'));
      let post_create_time = postCursor.getString(postCursor.getColumnIndex('create_time'));
      let post_url = '';
      // 优化：同一频道只读取一次json，缓存title-url映射
      let cacheKey = post_category_name + '||' + post_channel_name;
      if (!postUrlCache[cacheKey]) {
        postUrlCache[cacheKey] = {};
        logInfo(`建立缓存: ${post_category_name} / ${post_channel_name}`);
        try {
          let safeChannelName = sanitizeFileName(post_channel_name);
          let dirPath = files.join(context.cacheDir, 'files', post_category_name, safeChannelName);
          if (files.exists(dirPath)) {
            let fileList = files.listDir(dirPath).filter(f => f.endsWith('.json'));
            for (let file of fileList) {
              let filePath = files.join(dirPath, file);
              let json;
              try {
                json = JSON.parse(files.read(filePath));
              } catch (e) { logError(`解析JSON失败: ${filePath}`); continue; }
              if (Array.isArray(json.posts)) {
                for (let post of json.posts) {
                  if (post.title && post.url) {
                    postUrlCache[cacheKey][post.title] = post.url;
                  }
                }
              }
            }
          } else {
            logInfo(`目录不存在: ${dirPath}`);
          }
        } catch (e) { logError('缓存建立异常:', e); }
      }
      post_url = postUrlCache[cacheKey][post_title] || '';
      if (!post_url) {
        logInfo(`未找到帖子链接: ${post_category_name} / ${post_channel_name} / ${post_title}`);
      }
      let post_ext = '';
      newDb.execSQL(
        'INSERT OR REPLACE INTO post_history (category_name, channel_name, post_title, post_url, create_time, ext) VALUES (?, ?, ?, ?, ?, ?)',
        [post_category_name, post_channel_name, post_title, post_url, post_create_time, post_ext]
      );
      count++;
    }
    postCursor.close();
    logInfo(`post_history表迁移完成，共迁移 ${count} 条记录。`);
  } catch (e) {
    logError('迁移post_history表失败:', e);
  }
  oldDb.close();
  newDb.close();
  logInfo('历史数据迁移全部完成。');
}

// 生成UUID（基于频道名称）
function uuidFromString(str) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = ((hash << 5) - hash) + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash).toString(16);
}

// 频道名称去除特殊字符
function sanitizeFileName(name) {
  return name.replace(/[^a-zA-Z0-9\u4e00-\u9fa5]/g, '');
}


// --- 抓取流程 ---

// 启动小宇宙App
function launchXiaoyuzhou() {
  logInfo('准备启动小宇宙App...');
  launch(XIAOYUZHOU_PACKAGE);
  sleep(3000); // 启动后多等待1秒
}

// 点击左侧分类按钮进入分类页面
function enterCategoryPage() {
  logInfo('尝试查找并点击左侧分类按钮...');
  sleep(2000); // 等待页面加载
  // 假设左侧分类按钮有固定的文本或描述（如“分类”），可根据实际情况调整
  // 优先尝试通过文本查找
  let found = core.clickText('分类', { limit_x: [0, 0.3], timeout: 5000 });
  if (found) {
    logInfo('已点击“分类”按钮，进入分类页面。');
    sleep(2500); // 进入分类页面后多等待
    return true;
  }
  // 若未找到，可尝试通过控件描述、viewId等方式补充
  logError('未找到“分类”按钮，请检查UI元素或调整查找方式。');
  return false;
}

// 检查是否已进入小宇宙首页
function isOnHomePage() {
  let foundTitle = core.findAnyTargetText(['发现'], { timeout: 2000, limit_y: [0, 0.2], continueOnError: true });
  let foundTab = core.findAnyTargetText(['发现'], { timeout: 2000, limit_y: [0.9, 1], continueOnError: true });
  if ((foundTitle && foundTitle.length > 0) || (foundTab && foundTab.length > 0)) {
    logInfo('检测到已进入小宇宙首页。');
    return true;
  }
  logInfo('未检测到首页元素，当前不在首页。');
  return false;
}

// 等待进入首页，最多重试maxRetry次
function waitForHomePage(maxRetry) {
  let retry = 0;
  while (retry < maxRetry) {
    if (isOnHomePage()) {
      return true;
    }
    logInfo('等待进入首页...');
    sleep(2000);
    retry++;
  }
  return isOnHomePage();
}

/**
 * 展开全部分类菜单并点击指定分类
 * @param {string} categoryName - 要查找的分类名称
 * @returns {boolean} 是否成功找到并点击
 */
function scrollAndSelectCategory(categoryName) {
  logInfo('准备展开全部分类菜单...');
  // 1. 按坐标点击顶部右侧向下箭头，限制为limit_x 0.925-1.0，limit_y 0.1-0.12
  let x = device.width * 0.925; // 取中间值
  let y = device.height * 0.11;
  click(x, y);
  sleep(2000);
  // 2. 在弹出的全部分类菜单中查找并点击分类
  logInfo('查找全部分类菜单中的分类:', categoryName);
  let ok = core.clickAnyTargetText([categoryName], {isFindByNode:false, timeout:5000});
  if (ok) {
    logInfo('已点击分类:', categoryName);
    return true;
  } else {
    logError('找不到分类:', categoryName);
    return false;
  }
}

/**
 * 爬取当前分类下所有频道，依次进入频道详情页并复制频道链接。
 * 支持自动下滑，直到连续3次滑动无新增频道为止。
 */
function fetchChannelsInCategory(categoryName) {
  const startTime = Date.now();
  if (!globalStats.categories[categoryName]) globalStats.categories[categoryName] = { startTime: Date.now(), channels: {} };
  logInfo(`开始爬取分类${categoryName}下的频道...`);
  let channelMap = {};
  let maxNoNew = 3;
  let totalPosts = 0;
  let channelCount = 0;
  let buySkipCount = 0;
  let lastTitlesArr = []; 
  while (true) {
    sleep(1800);

    let channelNodes = core.getAllNodesByViewId('tvPodTitle');
    // 新增：过滤掉有购买按钮的频道
    // channelNodes = channelNodes.filter(function(node) {
    //   if (node.label.toString().indexOf('陈丹青') === -1) {
    //     logInfo('过滤掉非陈丹青的频道:', node.label);
    //     return false;
    //   }
    //   return true;
    // });

    // 按y坐标从小到大排序
    channelNodes.sort((a, b) => a.centerY - b.centerY);

    // 判断本轮频道标题列表与前两轮是否一致
    lastTitlesArr.push(JSON.stringify(channelNodes.map(x => x.label)));
    if (lastTitlesArr.length > maxNoNew) lastTitlesArr.shift();
    let allSame = lastTitlesArr.length === maxNoNew && lastTitlesArr[0] === lastTitlesArr[1] && lastTitlesArr[1] === lastTitlesArr[2];
    if (allSame) {
      logInfo(`连续 ${maxNoNew} 次获取到的频道信息一致，终止抓取`);
      break;
    }

    // 2. 去重，保存频道名和节点
    for (let i = 0; i < channelNodes.length; i++) {
      let node = channelNodes[i];
      let name = node.label ? node.label.toString().trim() : '';
      if (name && !channelMap[name] && node.relative.y <= 0.9) {
        channelMap[name] = node;
      }
    }
    let channelNames = Object.keys(channelMap);
    logInfo('当前已发现频道数:', channelNames.length);
    // 3. 判断是否有新增频道
   
    // 4. 处理本轮新发现的频道
    let toProcess = [];
    for (let i = 0; i < channelNames.length; i++) {
      let name = channelNames[i];
      let node = channelMap[name];
      if (!node._processed) {
        toProcess.push({ name, node });
        node._processed = true;
      }
    }
    if (toProcess.length === 0) {
      // 没有新频道可处理，直接滑动
      logInfo('本轮无新频道可处理，准备滑动...');
    } else {
      logInfo('待处理频道列表:', toProcess.map(x => x.name).join('、'));
      for (let i = 0; i < toProcess.length; i++) {
        sleep(1000);  
        let name = toProcess[i].name;
        let node = toProcess[i].node;

        // 检查是否需要购买
        let buyNodes = core.getAllNodesByViewId('tvBuy');
        let hasBuy = false;
        for (let j = 0; j < buyNodes.length; j++) {
          let buyNode = buyNodes[j];
          // 判断buyNode是否在当前频道标题右侧（x更大，y接近）
          if (Math.abs(buyNode.relative.y - node.relative.y) < 0.045) {
            hasBuy = true;
            break;
          }
        }
        if (hasBuy) {
          logInfo(`频道《${name}》需要购买，已跳过。`);
          upsertChannelBaseInfo(categoryName, name, '', '需要购买');
          buySkipCount++;
          continue;
        }
        
        logInfo(`准备进入频道: ${name}`);
        // 点击频道节点
        try {
          //如果 node.centerY 大于0.91，则向上滚动一点
          click(node.centerX, node.centerY);
        } catch (e) {
          logError(`点击频道节点失败: ${name}`, e);
          continue;
        }

        logInfo(`进入频道: ${name}`);
        if(checkChannelFinished(categoryName, name).finished){
          logInfo(`频道 ${name} 已爬取完毕，跳过爬取。`);
          // 返回频道列表页
          back();
          continue;
        }

        // 兼容节点帖子总数获取失败的情况
        // if(shouldSkipChannel(categoryName, name)){
        //   logInfo(`频道 ${name} 今日已完成，跳过爬取。`);
        //   // 返回频道列表页
        //   back();
        //   sleep(1000);
        //   continue;
        // }

        // 获取频道详情
        let channelDetailOk = fetchChannelDetail(categoryName, name);
        if(!channelDetailOk){
          logError(`频道 ${name} 获取详情失败，跳过爬取。`);
          back();
          continue;
        }
        // 统计频道帖子数
        let thisChannelPosts = fetchPostsInChannel(categoryName, name);
        totalPosts += thisChannelPosts;
        channelCount++;
        // 返回频道列表页
        back();
        // sleep(1000);
      }
    }
    // 5. 向下滑动一屏
    logInfo('准备向下滑动一屏，继续抓取...');
    let startX = device.width / 2;
    let startY = device.height * 0.7;
    let endY = device.height * 0.2;
    swipe(startX, startY, startX, endY, 500);
    // sleep(1800);
  }
  const duration = ((Date.now() - startTime) / 1000).toFixed(2);
  globalStats.categories[categoryName].duration = duration;
  globalStats.categories[categoryName].buySkipCount = buySkipCount;
  sendCategoryStatMsg(categoryName);
  logInfo(`分类 ${categoryName} 所有频道处理完毕。`);
}

/**
 * 优化：爬取当前频道下所有帖子的链接，自动去重和下滑，直到连续3次滑动无新增帖子后结束
 */
function fetchPostsInChannel(categoryName, channelName) {
  const startTime = Date.now();
  if (!globalStats.categories[categoryName]) globalStats.categories[categoryName] = { startTime: Date.now(), channels: {} };
  globalStats.categories[categoryName].channels[channelName] = { startTime, postCount: 0, duration: 0 };
  logInfo(`开始爬取分类 ${categoryName} 频道 ${channelName} 下的帖子链接...`);
  // sleep(1200);

  let channelFinished = checkChannelFinished(categoryName, channelName);
  if(channelFinished.finished){
    logInfo(`频道 ${channelName} 已爬取完毕，跳过爬取。`);
    return 0;
  }
  let totalCount = channelFinished.totalCount;
  let historyPostCount = getPostCountFromDb(categoryName, channelName);
  logInfo(`频道 ${channelName} 已爬取帖子数: ${historyPostCount}，总数: ${totalCount}`);
  // sleep(1000);

  let postMap = {};
  let maxNoNew = 3;
  let lastPostTitle = '';
  let markHasNew = false; // 标记是否有新增帖子
  let postsList = [];
  let postCount = 0;
  let skipCount = 0;
  let emptyTitleCount = 0;
  let buySkipCount = 0;
  let lastTitlesArr = [];
  while (true) {
    let processCount = postCount + skipCount;
    logInfo(`processCount: ${processCount}, historyPostCount: ${historyPostCount}, totalCount: ${totalCount}`);
    if(processCount + historyPostCount >= totalCount && totalCount > 0){
      logInfo(`频道 ${channelName} 已爬取帖子数已达到总数，跳过爬取。count: ${postCount + historyPostCount}, totalCount: ${totalCount}`);
      break;
    }
    postsList = [];
    let postNodes = core.getAllNodesByViewId('stvTitle', { timeout: 2000, continueOnError: true });
    if (!postNodes || postNodes.length === 0) {
      logError('未找到任何帖子标题节点');
      break;
    }

    // 按y坐标从小到大排序
    postNodes.sort((a, b) => a.centerY - b.centerY);

    // 判断本轮帖子标题列表与前两轮是否一致
    lastTitlesArr.push(JSON.stringify(postNodes.map(x => x.label)));
    if (lastTitlesArr.length > maxNoNew) lastTitlesArr.shift();
    let allSame = lastTitlesArr.length === maxNoNew && lastTitlesArr[0] === lastTitlesArr[1] && lastTitlesArr[1] === lastTitlesArr[2];
    if (allSame) {
      logInfo(`连续 ${maxNoNew} 次获取到的帖子信息一致，终止抓取`);
      break;
    }

    // 去重，保存帖子标题和节点
    for (let i = 0; i < postNodes.length; i++) {
      let node = postNodes[i];
      let title = node.label ? node.label.toString().trim() : '';
      if(title.length == 0){
        logError(`帖子《${title}》标题为空，跳过。`);
        skipCount++;
        emptyTitleCount++;
        continue;
      }
      if (isPostInDb(categoryName, channelName, title)) {
        logInfo(`帖子《${title}》已存在，跳过。`);
        continue;
      }
      if (node.relative.y > 0.9) {
        logInfo(`帖子《${title}》在底部，先跳过。`);
        continue;
      }

      if (title && !postMap[title]) {
        postMap[title] = node;
      }
    }

    let postTitles = Object.keys(postMap);
    logInfo('当前已发现帖子数:', postTitles.length);
    // 处理本轮新发现的帖子
    let toProcess = [];
    for (let i = 0; i < postTitles.length; i++) {
      let title = postTitles[i];
      let node = postMap[title];
      if (!node._processed) {
        toProcess.push({ title, node });
        node._processed = true;
      }
    }

    if (toProcess.length === 0) {
      logInfo(`本轮无新帖子可处理，准备滑动...`);
    } else {
      logInfo('待处理帖子列表:', toProcess.map(x => x.title).join('、'));
      if (!markHasNew) {
        markHasNew = true;
        markChannelFinished(categoryName, channelName, 0);
      } 
      for (let i = 0; i < toProcess.length; i++) {
        // sleep(1000);
        let title = toProcess[i].title;
        let postNode = toProcess[i].node;
        // 检查标题右侧是否有“购买”按钮，若有则跳过
         // 获取所有购买按钮节点
         let buyNodes = core.getAllNodesByViewId('tvBuy');
         let hasBuy = false;
         for (let j = 0; j < buyNodes.length; j++) {
           let buyNode = buyNodes[j];
           // 判断buyNode是否在当前频道标题右侧（x更大，y接近）
           if (Math.abs(buyNode.relative.y - postNode.relative.y) < 0.045) {
             hasBuy = true;
             break;
           }
         }
         if (hasBuy) {
           logInfo(`帖子《${title}》需要购买，已跳过。`);
           skipCount++;
           buySkipCount++;
           insertPostHistory(categoryName, channelName, title, '', '需要购买');
           continue;
         }
        
        logInfo(`处理帖子: ${title}`);
        // 查找与标题节点y坐标最接近的ivMore按钮
        let moreNodes = core.getAllNodesByViewId('ivMore', { timeout: 2000, continueOnError: true });
        if (!moreNodes || moreNodes.length === 0) {
          logError('未找到更多按钮');
          skipCount++;
          continue;
        }
        // 选取y坐标最接近的那个
        let minDiff = 99999, bestNode = null;
        for (let j = 0; j < moreNodes.length; j++) {
          let diff = Math.abs(moreNodes[j].centerY - postNode.centerY);
          if (diff < minDiff) {
            minDiff = diff;
            bestNode = moreNodes[j];
          }
        }
        if (!bestNode) {
          logError('未找到合适的更多按钮');
          skipCount++;
          continue;
        }
        // 点击更多按钮
        click(bestNode.centerX, bestNode.centerY);
        sleep(1000);
        // 点击弹窗中的“分享”按钮
        let shareOk = core.clickText('分享', { timeout: 2000, limit_y: [0.82, 1.0], continueOnError: true });
        if (!shareOk) {
          logError('未找到“分享”按钮');
          back();
          sleep(800);
          skipCount++;
          continue;
        }
        sleep(1000);
        // 点击分享窗中的“复制链接”
        let copyOk = core.clickText('复制链接', { timeout: 2000, limit_y: [0.85, 1.0], continueOnError: true });
        let postUrl = '';
        if (!copyOk) {
          logError('未找到“复制链接”按钮');
          back();
          sleep(800);
          skipCount++;
          continue;
        }
        postUrl = getClip();
        // sleep(800);
        // 获取剪切板内容
        logInfo(`帖子《${title}》链接: ${postUrl}`);
        if (!postUrl || postUrl.length == 0) {
          logError(`帖子《${title}》复制链接为空`);
          skipCount++;
          continue;
        }
        // 记录最后一个帖子标题
        lastPostTitle = title;
        // 收集帖子信息
        postsList.push({ title: title, url: postUrl });
        // 插入帖子
        insertPostHistory(categoryName, channelName, title, postUrl, '');
        postCount++;
        sleep(1000);
      }
    }

    // 每处理完一页就写一次数据库
    if (lastPostTitle) {
      updateChannelLastPost(categoryName, channelName, lastPostTitle);
    }

    // 向下滑动一屏
    logInfo('准备向下滑动一屏，继续抓取...');
    let startX = device.width / 2;
    let startY = device.height * 0.7;
    let endY = device.height * 0.2;
    swipe(startX, startY, startX, endY, 500);
    sleep(1800);
  }
  // 爬取完毕，写入完成状态
  markChannelFinished(categoryName, channelName, 1);

  const duration = ((Date.now() - startTime) / 1000).toFixed(2);
  globalStats.categories[categoryName].channels[channelName].postCount = postCount;
  globalStats.categories[categoryName].channels[channelName].duration = duration;
  globalStats.categories[categoryName].channels[channelName].skipCount = skipCount;
  globalStats.categories[categoryName].channels[channelName].historyPostCount = historyPostCount;
  globalStats.categories[categoryName].channels[channelName].emptyTitleCount = emptyTitleCount;
  globalStats.categories[categoryName].channels[channelName].buySkipCount = buySkipCount;
  sendChannelStatMsg(categoryName, channelName);
  logInfo(`分类 ${categoryName} 频道 ${channelName} 帖子链接爬取完毕。`);
  return postCount;
}

function checkChannelFinished(categoryName, channelName) {
  let totalCount = 0;
  let countNode = core.getNodeByViewId('tvEpiCount');
  if(!countNode){
    logError('未找到帖子数量节点');
  }else{
    let count = countNode.label ? countNode.label.toString().trim().replace('期', '') : '';
    totalCount = parseInt(count);
    logInfo(`频道 ${channelName} 帖子总数 tvEpiCount: ${count}`);
  }

  let dbPostCount = getPostCountFromDb(categoryName, channelName);
  logInfo(`频道 ${channelName} 已爬取帖子数: ${dbPostCount}`);
  let finished = (dbPostCount >= totalCount && totalCount > 0);

  return { finished, totalCount };
}

// 修改fetchChannelDetail，写入频道基本信息
function fetchChannelDetail(categoryName, channelName) {
  // 获取频道描述
  // let node = core.getNodeByViewId('tvDescription');
  // if (!node) {
  //   logError(`未找到“描述”文本: ${channelName}`);
  //   sleep(500);
  // }
  // logInfo(`频道 ${channelName} 描述: ${node.label.toString().trim()}`);

  // 获取频道作者
  // node = core.getNodeByViewId('tvAuthorship');
  // let authorShip = '';
  // if (!node) {
  //   logError(`未找到“作者”文本: ${channelName}`);
  //   sleep(500);
  // } else if(node.label != null) {
  //   authorShip = node.label.toString().trim();
  // }
  // logInfo(`频道 ${channelName} 作者: ${authorShip}`);

  let shareOk = core.clickByViewId('ivShare', { timeout: 2000, continueOnError: true });
  if (!shareOk) {
    logError(`未找到分享按钮: ${channelName}`);
    return false;
  }
  sleep(1000);

  // 点击“复制链接”
  let copyOk = core.clickText('复制链接', { timeout: 2000, continueOnError: true });
  let channelLink = '';
  if (!copyOk) {
    logError(`未找到“复制链接”按钮: ${channelName}`);
    return false;
  } else {
    channelLink = getClip();
  }
  logInfo(`频道 ${channelName} 链接: ${channelLink}`);
  if(!channelLink || channelLink.length == 0){
    logError(`链接为空: ${channelName}`);
  }
  // 写入数据库
  upsertChannelBaseInfo(categoryName, channelName, channelLink, '');
  return true;
}

// 开始抓取
function startFetchWithCategories(categoryList) {
  for (let i = 0; i < categoryList.length; i++) {
    let categoryName = categoryList[i];
    logInfo(`开始抓取分类${categoryName}...`);
    let ok = scrollAndSelectCategory(categoryName);
    if (!ok) {
      logError(`进入分类${categoryName}页面失败，跳过。`);
      continue;
    }
    sleep(2000);
    fetchChannelsInCategory(categoryName);
    logInfo(`抓取分类${categoryName}完成。`);
  }
}

// 主流程
function main() {
  globalStats.startTime = Date.now();
  try {
    // 获取设备信息
    let deviceId = device.getAndroidId();
    let categoryList = getCategoryByDeviceId(deviceId);
    logInfo(`设备ID: ${deviceId}，分类: ${categoryList}`);
    if(categoryList.length == 0){
      logError('未找到分类，脚本终止。');
      core.sendToBot("[XYZ]未找到分类，脚本终止。[deviceId:" + deviceId + "]");
      return;
    }

    initializeScript();
    sleep(1000); // 启动前等待
    // migrateOldDatabaseToV2();
    
    launchXiaoyuzhou();
    sleep(1000); // 启动后再等待
    if (!waitForHomePage(20)) {
      logError('多次检测未进入小宇宙首页，脚本终止。');
      return;
    }
    let ok = enterCategoryPage();
    if (!ok) {
      logError('进入分类页面失败，脚本终止。');
      return;
    }

    // 开始抓取
    startFetchWithCategories(categoryList);
    generateAndSendReport();
  } catch (e) {
    logError('脚本运行异常:', e);
    core.sendToBot("小宇宙：" + e.toString());
  } finally {
    // 确保数据库连接被关闭
    if (db) {
      try {
        db.close();
        logInfo("数据库连接已关闭");
      } catch (e) {
        logError("关闭数据库连接时出错：", e);
      }
    }
  }
}

// 执行主流程
main();
